typedef struct AAssetManager AAssetManager;
