#!/usr/bin/env python3
"""Compile unchanged original AOSP resource-selection algorithms to standalone Wasm."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, zipfile

repo = Path(__file__).resolve().parent.parent
root = repo / 'framework-aosp/native-config'
build = root / 'build'
for folder in ['androidfw', 'android', 'sys']:
    (build / folder).mkdir(parents=True, exist_ok=True)
sources = json.loads((root / 'upstream-sources.json').read_text())
for source in sources:
    data = (root / source['file']).read_bytes()
    if hashlib.sha256(data).hexdigest() != source['sha256']:
        raise RuntimeError('Modified original source: ' + source['file'])

def original(name):
    return (root / 'upstream' / name).read_text()

header = original('ResourceTypes.h')
start = header.index('struct ResTable_config\n')
end = header.index('\n};', start) + 3
struct = header[start:end]
(build / 'Config.h').write_text('''#pragma once
#include <cstdint>
#include <cstring>
#include <cstddef>
#include <android/configuration.h>
#include <androidfw/LocaleData.h>
namespace android { class String8;
''' + struct + '\n}\n')
source = original('ResourceTypes.cpp')
start = source.index('inline int ResTable_config::getImportanceScoreOfLocale()')
end = source.index('void ResTable_config::appendDirLocale', start)
selection = source[start:end]
wrapper = '''
static android::ResTable_config configs[3]{};
extern "C" {
unsigned config_size(){ return sizeof(android::ResTable_config); }
unsigned char* config_buffer(){ return reinterpret_cast<unsigned char*>(configs); }
void config_prepare(){
    for(auto& config: configs) config.size = sizeof(config);
    if(configs[2].locale && !configs[2].localeScript[0]) {
        configs[2].computeScript();
        configs[2].localeScriptWasComputed = true;
    }
}
int config_match(){ return configs[0].match(configs[2]); }
int config_better(){ return configs[0].isBetterThan(configs[1], &configs[2]); }
}
'''
(build / 'Config.cpp').write_text('''#include <utility>
#include "Config.h"
#define ALOGI(...) ((void)0)
namespace android {
static constexpr bool kDebugTableSuperNoisy = false;
''' + selection + '\n}\n' + wrapper)
for filename, target in [('configuration.h', 'android/configuration.h'), ('LocaleData.h', 'androidfw/LocaleData.h'), ('LocaleData.cpp', 'LocaleData.cpp'), ('LocaleDataTables.cpp', 'LocaleDataTables.cpp')]:
    shutil.copyfile(root / 'upstream' / filename, build / target)
# Declaration-only dependencies for unused NDK APIs; no replacement algorithms.
(build / 'android/asset_manager.h').write_text('typedef struct AAssetManager AAssetManager;\n')
(build / 'sys/cdefs.h').write_text('#pragma once\n')
compiler = sys.argv[1] if len(sys.argv) > 1 else os.environ.get('EMXX', str(repo / 'work/emsdk/upstream/emscripten/em++'))
version = subprocess.check_output([compiler, '--version'], text=True).splitlines()[0]
if '3.1.74' not in version:
    raise RuntimeError('Pinned Emscripten 3.1.74 required; found: ' + version)
flags = ['-I' + str(build), '-std=c++17', '-O3', '-flto', '--no-entry', '-sSTANDALONE_WASM=1', '-sFILESYSTEM=0', '-sEXPORTED_FUNCTIONS=_config_size,_config_buffer,_config_prepare,_config_match,_config_better', '-sINITIAL_MEMORY=4194304', '-sSTACK_SIZE=65536']
subprocess.run([compiler, str(build / 'Config.cpp'), str(build / 'LocaleData.cpp'), *flags, '-o', str(root / 'resource-config.wasm')], check=True)
data = (root / 'resource-config.wasm').read_bytes()
provenance = dict(schemaVersion=1, artifact='resource-config.wasm', sourceTag='android-13.0.0_r1', bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), compiler=version, flags=flags[1:], imports=[], memoryBytes=4194304, scope='Resource configuration match/isBetterThan and original locale data; not an Android OS.', algorithmPatches=[], excerpts=[dict(file='ResourceTypes.h', text='complete ResTable_config declaration', sha256=hashlib.sha256(struct.encode()).hexdigest()), dict(file='ResourceTypes.cpp', text='getImportanceScoreOfLocale through match inclusive', sha256=hashlib.sha256(selection.encode()).hexdigest())], compiledWholeSources=['LocaleData.cpp', 'LocaleDataTables.cpp'], adaptations=['Standalone memory/export wrapper', 'Unused String8/AAssetManager declarations only', 'Disabled upstream diagnostic logging branch'], sourceFiles=sources, correspondingSource='source-bundle.zip')
(root / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
with zipfile.ZipFile(root / 'source-bundle.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(root.rglob('*')):
        if file.is_file() and 'build' not in file.relative_to(root).parts and file.name not in ['source-bundle.zip', 'resource-config.wasm']:
            archive.write(file, file.relative_to(root))
    archive.write(Path(__file__), 'scripts/build-aosp-resource-config.py')
    for name in ['Config.h', 'Config.cpp', 'android/asset_manager.h', 'sys/cdefs.h']:
        archive.write(build / name, 'generated/' + name)
print(f'Original AOSP resource selector: {len(data)} bytes; SHA256 {provenance["sha256"]}')
