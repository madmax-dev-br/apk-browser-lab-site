#!/usr/bin/env python3
"""Build original Android13 Path.cpp approximation functions as bounded standalone Wasm."""
import hashlib,json,os,pathlib,subprocess,sys,zipfile
repo=pathlib.Path(__file__).resolve().parents[1]
root=repo/'framework-aosp/native-path-approx';build=root/'build';build.mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def excerpt(text,start):
 p=text.index(start);begin=text.index('{',p);depth=1;end=begin+1
 while depth:
  depth+= (text[end]=='{')-(text[end]=='}');end+=1
 return text[p:end]
path=(root/'upstream/Path.cpp').read_text();point=(root/'upstream/SkPoint.cpp').read_text();header=(root/'upstream/SkPoint.h').read_text()
functions=path[path.index('    typedef SkPoint (*bezierCalculation)'):path.index('    static void createVerbSegments')]
length=excerpt(point,'SkScalar SkPoint::Length(');distance=excerpt(header,'    static SkScalar Distance(')
# The original math and subdivision decisions remain unchanged. Guards abort the API
# rather than return fabricated samples if refinement exceeds this web VM's bounds.
compiled=functions.replace('                if (needsSubdivision) {','                if (++workCount > 200000) { failure=1; return; }\n                if (needsSubdivision && (midT == iter->first || midT == next->first || tToPoint.size() >= 65536)) { failure=2; return; }\n                if (needsSubdivision) {')
code=r'''#include <vector>
#include <map>
#include <cmath>
#include <cstdint>
using SkScalar=float;
static inline bool SkScalarIsFinite(float v){return std::isfinite(v);}
static inline float sk_float_sqrt(float v){return std::sqrt(v);}
static inline float sk_double_to_float(double v){return static_cast<float>(v);}
struct SkPoint {
 float fX,fY;
 static SkPoint Make(float x,float y){return {x,y};}
 float x()const{return fX;} float y()const{return fY;}
 bool operator==(const SkPoint& other)const{return fX==other.fX&&fY==other.fY;}
 static SkScalar Length(SkScalar dx,SkScalar dy);
'''+distance+'\n};\n'+length+r'''
static int failure=0,workCount=0;
'''+compiled+r'''
static float input[65536],output[300000];
extern "C" uintptr_t path_input(){return reinterpret_cast<uintptr_t>(input);}
extern "C" uintptr_t path_output(){return reinterpret_cast<uintptr_t>(output);}
extern "C" int path_approximate(int count,float acceptableError){
 if(count<0||count>65536)return -1;
 failure=workCount=0;
 std::vector<SkPoint> segmentPoints;
 std::vector<float> lengths;
 float errorSquared=acceptableError*acceptableError;
 SkPoint current=SkPoint::Make(0,0),start=current;
 int at=0;
 while(at<count){
  int verb=static_cast<int>(input[at++]);
  const int values=verb==0||verb==1?2:verb==2?4:verb==4?6:verb==5?0:-1;
  if(values<0||at+values>count)return verb==3?-3:-2;
  SkPoint points[4];points[0]=current;
  for(int i=0;i<values/2;i++)points[i+1]=SkPoint::Make(input[at+i*2],input[at+i*2+1]);
  if(verb==0){current=start=points[1];addMove(segmentPoints,lengths,current);}
  else if(verb==1){current=points[1];addLine(segmentPoints,lengths,current);}
  else if(verb==2){current=points[2];addBezier(points,quadraticBezierCalculation,segmentPoints,lengths,errorSquared,false);}
  else if(verb==4){current=points[3];addBezier(points,cubicBezierCalculation,segmentPoints,lengths,errorSquared,true);}
  else if(verb==5){current=start;addLine(segmentPoints,lengths,current);}
  at+=values;
  if(failure)return -10-failure;
  if(segmentPoints.size()>100000)return -4;
 }
 // Original Path.cpp normalization; JNI arrays are replaced only by fixed transport buffers.
 if(segmentPoints.empty())addMove(segmentPoints,lengths,SkPoint());
 float totalLength=lengths.back();
 if(totalLength==0){segmentPoints.push_back(segmentPoints.back());lengths.push_back(1);totalLength=1;}
 size_t numPoints=segmentPoints.size();
 if(numPoints>100000)return -4;
 int approximationIndex=0;
 for(size_t i=0;i<numPoints;i++){
  const SkPoint& point=segmentPoints[i];
  output[approximationIndex++]=lengths[i]/totalLength;
  output[approximationIndex++]=point.x();
  output[approximationIndex++]=point.y();
 }
 return approximationIndex;
}
'''
(build/'PathApprox.cpp').write_text(code)
compiler=sys.argv[1] if len(sys.argv)>1 else os.environ.get('EMXX',str(repo/'work/emsdk/upstream/emscripten/em++'))
version=subprocess.check_output([compiler,'--version'],text=True).splitlines()[0]
if '3.1.74' not in version:raise RuntimeError('Pinned Emscripten3.1.74 required')
flags=['-std=c++17','-O2','-ffp-contract=off','-fno-fast-math','-fno-exceptions','--no-entry','-sSTANDALONE_WASM=1','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS=_path_input,_path_output,_path_approximate','-sINITIAL_MEMORY=16777216','-sSTACK_SIZE=131072','-sALLOW_MEMORY_GROWTH=0']
subprocess.run([compiler,str(build/'PathApprox.cpp'),*flags,'-o',str(root/'path-approx.wasm')],check=True)
base='https://android.googlesource.com/platform/'
sources=[]
for file,project,path in [('Path.cpp','frameworks/base','libs/hwui/jni/Path.cpp'),('SkPoint.cpp','external/skia','src/core/SkPoint.cpp'),('SkPoint.h','external/skia','include/core/SkPoint.h')]:
 data=(root/'upstream'/file).read_bytes();sources.append(dict(file=file,project=project,tag='android-13.0.0_r1',path=path,url=base+project+'/+/android-13.0.0_r1/'+path+'?format=TEXT',sha256=sha(data),bytes=len(data)))
data=(root/'path-approx.wasm').read_bytes()
metadata=dict(schemaVersion=1,source='original-AOSP-Path-approximation-C++/Skia-point-math',tag='android-13.0.0_r1',artifact='path-approx.wasm',bytes=len(data),sha256=sha(data),compiler=version,flags=flags,memoryBytes=16777216,limits=dict(inputFloats=65536,outputFloats=300000,points=100000,subdivisionWork=200000),sourceFiles=sources,excerpts=[dict(file='Path.cpp',text='bezierCalculation through addBezier inclusive',sha256=sha(functions.encode())),dict(file='SkPoint.cpp',text='SkPoint::Length full body',sha256=sha(length.encode())),dict(file='SkPoint.h',text='SkPoint::Distance full body',sha256=sha(distance.encode()))],adaptations=['JNI/SkPath pointer replaced with CanvasKit SkPath command transport and bounded output buffer','SkPoint data adapter preserves original Length/Distance math','Unchanged subdivision math plus explicit work/stagnation safety abort guards','Conic conversion is unsupported and rejected explicitly; no surrogate curve is returned'],correspondingSource='source-bundle.zip')
(root/'provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
(root/'NOTICE').write_text('Path approximation: original Android13 Path.cpp (Copyright 2006 Android Open Source Project, Apache 2.0); Skia SkPoint helpers (Copyright 2011 Google Inc., BSD 3-Clause). Emscripten 3.1.74 libc++/stdlib. Complete sources, function hashes and safety adaptations are listed in provenance.json. Conic conversion is not implemented.\n')
with zipfile.ZipFile(root/'source-bundle.zip','w',zipfile.ZIP_DEFLATED)as archive:
 for file in sorted(root.rglob('*')):
  if file.is_file() and file.name not in ['source-bundle.zip','path-approx.wasm'] and 'build' not in file.relative_to(root).parts:archive.write(file,file.relative_to(root))
 archive.write(__file__,'build-aosp-path-approx.py');archive.write(build/'PathApprox.cpp','standalone/PathApprox.cpp')
print(json.dumps(dict(bytes=len(data),sha256=metadata['sha256'])))
