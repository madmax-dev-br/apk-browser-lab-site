#include <vector>
#include <map>
#include <cmath>
#include <cstdint>
using SkScalar=float;
static inline bool SkScalarIsFinite(float v){return std::isfinite(v);}
static inline float sk_float_sqrt(float v){return std::sqrt(v);}
static inline float sk_double_to_float(double v){return static_cast<float>(v);}
struct SkPoint {
 float fX,fY;
 static SkPoint Make(float x,float y){return {x,y};}
 float x()const{return fX;} float y()const{return fY;}
 bool operator==(const SkPoint& other)const{return fX==other.fX&&fY==other.fY;}
 static SkScalar Length(SkScalar dx,SkScalar dy);
    static SkScalar Distance(const SkPoint& a, const SkPoint& b) {
        return Length(a.fX - b.fX, a.fY - b.fY);
    }
};
SkScalar SkPoint::Length(SkScalar dx, SkScalar dy) {
    float mag2 = dx * dx + dy * dy;
    if (SkScalarIsFinite(mag2)) {
        return sk_float_sqrt(mag2);
    } else {
        double xx = dx;
        double yy = dy;
        return sk_double_to_float(sqrt(xx * xx + yy * yy));
    }
}
static int failure=0,workCount=0;
    typedef SkPoint (*bezierCalculation)(float t, const SkPoint* points);

    static void addMove(std::vector<SkPoint>& segmentPoints, std::vector<float>& lengths,
            const SkPoint& point) {
        float length = 0;
        if (!lengths.empty()) {
            length = lengths.back();
        }
        segmentPoints.push_back(point);
        lengths.push_back(length);
    }

    static void addLine(std::vector<SkPoint>& segmentPoints, std::vector<float>& lengths,
            const SkPoint& toPoint) {
        if (segmentPoints.empty()) {
            segmentPoints.push_back(SkPoint::Make(0, 0));
            lengths.push_back(0);
        } else if (segmentPoints.back() == toPoint) {
            return; // Empty line
        }
        float length = lengths.back() + SkPoint::Distance(segmentPoints.back(), toPoint);
        segmentPoints.push_back(toPoint);
        lengths.push_back(length);
    }

    static float cubicCoordinateCalculation(float t, float p0, float p1, float p2, float p3) {
        float oneMinusT = 1 - t;
        float oneMinusTSquared = oneMinusT * oneMinusT;
        float oneMinusTCubed = oneMinusTSquared * oneMinusT;
        float tSquared = t * t;
        float tCubed = tSquared * t;
        return (oneMinusTCubed * p0) + (3 * oneMinusTSquared * t * p1)
                + (3 * oneMinusT * tSquared * p2) + (tCubed * p3);
    }

    static SkPoint cubicBezierCalculation(float t, const SkPoint* points) {
        float x = cubicCoordinateCalculation(t, points[0].x(), points[1].x(),
            points[2].x(), points[3].x());
        float y = cubicCoordinateCalculation(t, points[0].y(), points[1].y(),
            points[2].y(), points[3].y());
        return SkPoint::Make(x, y);
    }

    static float quadraticCoordinateCalculation(float t, float p0, float p1, float p2) {
        float oneMinusT = 1 - t;
        return oneMinusT * ((oneMinusT * p0) + (t * p1)) + t * ((oneMinusT * p1) + (t * p2));
    }

    static SkPoint quadraticBezierCalculation(float t, const SkPoint* points) {
        float x = quadraticCoordinateCalculation(t, points[0].x(), points[1].x(), points[2].x());
        float y = quadraticCoordinateCalculation(t, points[0].y(), points[1].y(), points[2].y());
        return SkPoint::Make(x, y);
    }

    // Subdivide a section of the Bezier curve, set the mid-point and the mid-t value.
    // Returns true if further subdivision is necessary as defined by errorSquared.
    static bool subdividePoints(const SkPoint* points, bezierCalculation bezierFunction,
            float t0, const SkPoint &p0, float t1, const SkPoint &p1,
            float& midT, SkPoint &midPoint, float errorSquared) {
        midT = (t1 + t0) / 2;
        float midX = (p1.x() + p0.x()) / 2;
        float midY = (p1.y() + p0.y()) / 2;

        midPoint = (*bezierFunction)(midT, points);
        float xError = midPoint.x() - midX;
        float yError = midPoint.y() - midY;
        float midErrorSquared = (xError * xError) + (yError * yError);
        return midErrorSquared > errorSquared;
    }

    // Divides Bezier curves until linear interpolation is very close to accurate, using
    // errorSquared as a metric. Cubic Bezier curves can have an inflection point that improperly
    // short-circuit subdivision. If you imagine an S shape, the top and bottom points being the
    // starting and end points, linear interpolation would mark the center where the curve places
    // the point. It is clearly not the case that we can linearly interpolate at that point.
    // doubleCheckDivision forces a second examination between subdivisions to ensure that linear
    // interpolation works.
    static void addBezier(const SkPoint* points,
            bezierCalculation bezierFunction, std::vector<SkPoint>& segmentPoints,
            std::vector<float>& lengths, float errorSquared, bool doubleCheckDivision) {
        typedef std::map<float, SkPoint> PointMap;
        PointMap tToPoint;

        tToPoint[0] = (*bezierFunction)(0, points);
        tToPoint[1] = (*bezierFunction)(1, points);

        PointMap::iterator iter = tToPoint.begin();
        PointMap::iterator next = iter;
        ++next;
        while (next != tToPoint.end()) {
            bool needsSubdivision = true;
            SkPoint midPoint;
            do {
                float midT;
                needsSubdivision = subdividePoints(points, bezierFunction, iter->first,
                    iter->second, next->first, next->second, midT, midPoint, errorSquared);
                if (!needsSubdivision && doubleCheckDivision) {
                    SkPoint quarterPoint;
                    float quarterT;
                    needsSubdivision = subdividePoints(points, bezierFunction, iter->first,
                        iter->second, midT, midPoint, quarterT, quarterPoint, errorSquared);
                    if (++workCount > 200000) { failure=1; return; }
                if (needsSubdivision && (midT == iter->first || midT == next->first || tToPoint.size() >= 65536)) { failure=2; return; }
                if (needsSubdivision) {
                        // Found an inflection point. No need to double-check.
                        doubleCheckDivision = false;
                    }
                }
                if (++workCount > 200000) { failure=1; return; }
                if (needsSubdivision && (midT == iter->first || midT == next->first || tToPoint.size() >= 65536)) { failure=2; return; }
                if (needsSubdivision) {
                    next = tToPoint.insert(iter, PointMap::value_type(midT, midPoint));
                }
            } while (needsSubdivision);
            iter = next;
            next++;
        }

        // Now that each division can use linear interpolation with less than the allowed error
        for (iter = tToPoint.begin(); iter != tToPoint.end(); ++iter) {
            addLine(segmentPoints, lengths, iter->second);
        }
    }


static float input[65536],output[300000];
extern "C" uintptr_t path_input(){return reinterpret_cast<uintptr_t>(input);}
extern "C" uintptr_t path_output(){return reinterpret_cast<uintptr_t>(output);}
extern "C" int path_approximate(int count,float acceptableError){
 if(count<0||count>65536)return -1;
 failure=workCount=0;
 std::vector<SkPoint> segmentPoints;
 std::vector<float> lengths;
 float errorSquared=acceptableError*acceptableError;
 SkPoint current=SkPoint::Make(0,0),start=current;
 int at=0;
 while(at<count){
  int verb=static_cast<int>(input[at++]);
  const int values=verb==0||verb==1?2:verb==2?4:verb==4?6:verb==5?0:-1;
  if(values<0||at+values>count)return verb==3?-3:-2;
  SkPoint points[4];points[0]=current;
  for(int i=0;i<values/2;i++)points[i+1]=SkPoint::Make(input[at+i*2],input[at+i*2+1]);
  if(verb==0){current=start=points[1];addMove(segmentPoints,lengths,current);}
  else if(verb==1){current=points[1];addLine(segmentPoints,lengths,current);}
  else if(verb==2){current=points[2];addBezier(points,quadraticBezierCalculation,segmentPoints,lengths,errorSquared,false);}
  else if(verb==4){current=points[3];addBezier(points,cubicBezierCalculation,segmentPoints,lengths,errorSquared,true);}
  else if(verb==5){current=start;addLine(segmentPoints,lengths,current);}
  at+=values;
  if(failure)return -10-failure;
  if(segmentPoints.size()>100000)return -4;
 }
 // Original Path.cpp normalization; JNI arrays are replaced only by fixed transport buffers.
 if(segmentPoints.empty())addMove(segmentPoints,lengths,SkPoint());
 float totalLength=lengths.back();
 if(totalLength==0){segmentPoints.push_back(segmentPoints.back());lengths.push_back(1);totalLength=1;}
 size_t numPoints=segmentPoints.size();
 if(numPoints>100000)return -4;
 int approximationIndex=0;
 for(size_t i=0;i<numPoints;i++){
  const SkPoint& point=segmentPoints[i];
  output[approximationIndex++]=lengths[i]/totalLength;
  output[approximationIndex++]=point.x();
  output[approximationIndex++]=point.y();
 }
 return approximationIndex;
}
