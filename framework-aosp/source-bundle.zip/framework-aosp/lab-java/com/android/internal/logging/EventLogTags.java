/* The Java the platform's logtags generator (java-event-log-tags.py) emits for frameworks/base/core/java/com/android/internal/logging/EventLogTags.logtags
 * (only the tag AtomicFile's commit logger uses): "2752 commit_sys_config_file (name|3),(time|2|3)". */
package com.android.internal.logging;

/** @hide */
public class EventLogTags {
    private EventLogTags() { }  // don't instantiate

    /** 2752 commit_sys_config_file (name|3),(time|2|3) */
    public static final int COMMIT_SYS_CONFIG_FILE = 2752;

    public static void writeCommitSysConfigFile(String name, long time) {
        android.util.EventLog.writeEvent(COMMIT_SYS_CONFIG_FILE, name, time);
    }
}
