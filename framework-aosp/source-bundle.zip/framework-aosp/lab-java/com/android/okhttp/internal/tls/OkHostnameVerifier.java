package com.android.okhttp.internal.tls;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/**
 * HttpsURLConnection's default HostnameVerifier is looked up by this name (HttpsURLConnection.NoPreloadHolder). On the web device the browser performs the TLS handshake and
 * the host name check against the certificate before fetch resolves, so by the time a response exists the default check has already passed; the verifier therefore accepts.
 * Verifiers an app installs itself are still consulted by BridgeHttpsURLConnection.
 */
public final class OkHostnameVerifier implements HostnameVerifier {
    public static final OkHostnameVerifier INSTANCE = new OkHostnameVerifier();
    private OkHostnameVerifier() {}
    @Override public boolean verify(String host, SSLSession session) { return true; }
}
