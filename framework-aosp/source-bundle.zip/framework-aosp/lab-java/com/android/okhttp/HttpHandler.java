package com.android.okhttp;

import dev.apkweb.net.BridgeHttpURLConnection;
import java.io.IOException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

/**
 * The "http" URLStreamHandler java.net.URL resolves to on Android (URL.createBuiltinHandler loads com.android.okhttp.HttpHandler by name). On the web device the
 * connection it returns is the fetch-backed BridgeHttpURLConnection; the OkHttp 2 engine of libcore is not part of the framework build.
 */
public class HttpHandler extends URLStreamHandler {
    @Override protected URLConnection openConnection(URL url) throws IOException { return new BridgeHttpURLConnection(url, null); }
    @Override protected URLConnection openConnection(URL url, Proxy proxy) throws IOException {
        if (url == null || proxy == null) throw new IllegalArgumentException("url == null || proxy == null");
        return new BridgeHttpURLConnection(url, proxy);
    }
    @Override protected int getDefaultPort() { return 80; }
    @Override protected boolean equals(URL a, URL b) { return a.toString().equals(b.toString()); }
    @Override protected int hashCode(URL url) { return url.toString().hashCode(); }
    @Override protected boolean hostsEqual(URL a, URL b) { return a.getHost() == null ? b.getHost() == null : a.getHost().equalsIgnoreCase(b.getHost()); }
}
