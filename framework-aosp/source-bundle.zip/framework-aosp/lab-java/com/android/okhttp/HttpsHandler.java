package com.android.okhttp;

import dev.apkweb.net.BridgeHttpsURLConnection;
import dev.apkweb.net.BridgeSSLSocketFactory;
import java.io.IOException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import javax.net.ssl.HttpsURLConnection;

/** The "https" URLStreamHandler java.net.URL resolves to on Android (com.android.okhttp.HttpsHandler); here the connection is fetch-backed, see {@link HttpHandler}. */
public class HttpsHandler extends HttpHandler {
    static {
        // HttpsURLConnection's constructor asks for the default SSLSocketFactory, which needs a JSSE provider. The web device has none (the browser owns TLS), so until an app installs
        // its own factory the default one is the explicit refusal below.
        HttpsURLConnection.setDefaultSSLSocketFactory(new BridgeSSLSocketFactory());
    }
    @Override protected URLConnection openConnection(URL url) throws IOException { return new BridgeHttpsURLConnection(url, null); }
    @Override protected URLConnection openConnection(URL url, Proxy proxy) throws IOException {
        if (url == null || proxy == null) throw new IllegalArgumentException("url == null || proxy == null");
        return new BridgeHttpsURLConnection(url, proxy);
    }
    @Override protected int getDefaultPort() { return 443; }
}
