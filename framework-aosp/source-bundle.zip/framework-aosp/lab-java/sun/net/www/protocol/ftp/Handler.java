package sun.net.www.protocol.ftp;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

/** URL.createBuiltinHandler names this class for "ftp". The web device has no FTP transport (the browser cannot open one), so opening a connection fails explicitly. */
public class Handler extends URLStreamHandler {
    @Override protected URLConnection openConnection(URL url) throws IOException {
        throw new IOException("ftp: URLs are not supported on the web device (no FTP transport in the browser): " + url);
    }
    @Override protected int getDefaultPort() { return 21; }
}
