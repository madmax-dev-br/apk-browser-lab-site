package sun.net.www.protocol.jar;

import dev.apkweb.net.ApkEntries;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.util.jar.JarFile;

/**
 * The "jar" URLStreamHandler (URL.createBuiltinHandler loads sun.net.www.protocol.jar.Handler by name). The web device only has one archive worth naming, the installed
 * APK, so a jar:file:<path>!/<entry> URL opens that entry's bytes from the package; java.util.jar.JarFile caching is not involved. Nested jar URLs are not supported.
 */
public class Handler extends URLStreamHandler {
    @Override protected URLConnection openConnection(URL url) throws IOException { return new ApkJarURLConnection(url); }

    @Override protected void parseURL(URL url, String spec, int start, int limit) {
        String file = spec.substring(start, limit), ref = null;
        int hash = file.indexOf('#');
        if (hash >= 0) { ref = file.substring(hash + 1); file = file.substring(0, hash); }
        if (file.indexOf("!/") < 0 && url.getFile() != null && url.getFile().indexOf("!/") >= 0) {
            // relative spec inside the jar: keep the archive part of the context
            String context = url.getFile(); String archive = context.substring(0, context.indexOf("!/") + 1);
            file = archive + (file.startsWith("/") ? file : "/" + file);
        }
        setURL(url, "jar", "", -1, file, ref);
    }

    private static final class ApkJarURLConnection extends JarURLConnection {
        private InputStream stream;
        ApkJarURLConnection(URL url) throws MalformedURLException { super(url); }
        @Override public void connect() throws IOException {
            if (connected) return;
            String entry = getEntryName();
            if (entry == null) throw new IOException("jar: URLs without an entry are not supported on the web device");
            String archive = getJarFileURL().getFile();
            stream = ApkEntries.open(archive, entry);
            connected = true;
        }
        @Override public InputStream getInputStream() throws IOException { connect(); return stream; }
        @Override public JarFile getJarFile() throws IOException { throw new IOException("java.util.jar.JarFile is not available for jar: URLs on the web device; use getInputStream()"); }
    }
}
