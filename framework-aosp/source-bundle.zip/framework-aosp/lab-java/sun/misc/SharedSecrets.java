package sun.misc;

/**
 * Lab-authored subset of libcore's sun.misc.SharedSecrets (ojluni): the registry through which java.io.FileDescriptor hands libcore code in other packages
 * (sun.nio.ch) access to its package-private descriptor field. The original registry also carries accessors for the jar, zip, AWT, serialization, HTTP cookie
 * and network packages, none of which are part of this framework build; they are deliberately absent so a use fails at link time instead of returning null.
 */
public class SharedSecrets {
    private static JavaIOFileDescriptorAccess javaIOFileDescriptorAccess;

    public static void setJavaIOFileDescriptorAccess(JavaIOFileDescriptorAccess jiofda) {
        javaIOFileDescriptorAccess = jiofda;
    }

    public static JavaIOFileDescriptorAccess getJavaIOFileDescriptorAccess() {
        if (javaIOFileDescriptorAccess == null) {
            Object initialize = java.io.FileDescriptor.in; // class initialization registers the access object (original: Unsafe.ensureClassInitialized)
        }
        return javaIOFileDescriptorAccess;
    }
}
