package dev.apkweb.os;

import java.time.Clock;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;

/** SystemClock.currentNetworkTimeClock(): the clock of android.os.SystemClock over the time detector's latest NTP time. The virtual device has no network time source, so, as in AOSP SystemClock with no cached NtpTrustedTime result, every read throws DateTimeException("Missing NTP fix"). */
public final class NetworkTimeClock extends Clock {
    private final ZoneId zone;
    public NetworkTimeClock() { this(ZoneOffset.UTC); }
    private NetworkTimeClock(ZoneId zone) { this.zone = zone; }
    @Override public ZoneId getZone() { return zone; }
    @Override public Clock withZone(ZoneId zone) { return new NetworkTimeClock(zone); }
    @Override public long millis() { throw new DateTimeException("Missing NTP fix"); }
    @Override public Instant instant() { return Instant.ofEpochMilli(millis()); }
}
