package dev.apkweb.os;

import android.os.Bundle;
import android.os.PersistableBundle;
import java.util.Objects;
import java.util.Set;

/**
 * Bundle.kindofEquals (hidden, used by the original android.location.Location.equals-like comparisons): two bundles are equal when they hold the same keys with equal values,
 * nested Bundles compared by content and arrays by element. scripts/prepare-javatime-sources.py rewrites the hidden call site to this helper (documented transform).
 */
public final class BundleHidden {
    private BundleHidden() {}

    public static boolean kindofEquals(Bundle a, Bundle b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a.size() != b.size()) return false;
        Set<String> keys = a.keySet();
        for (String key : keys) {
            if (!b.containsKey(key)) return false;
            Object x = a.get(key), y = b.get(key);
            if (x instanceof Bundle && y instanceof Bundle) {
                if (!kindofEquals((Bundle) x, (Bundle) y)) return false;
            } else if (!Objects.deepEquals(x, y)) {
                return false;
            }
        }
        return true;
    }

    /**
     * new PersistableBundle(Bundle) (hidden): a copy holding only the types a PersistableBundle can persist (BaseBundle.isValidType): primitives and their arrays, String, String[],
     * and nested PersistableBundles; any other value is the same IllegalArgumentException the original constructor raises.
     */
    public static PersistableBundle persistable(Bundle source) {
        PersistableBundle result = new PersistableBundle();
        for (String key : source.keySet()) {
            Object value = source.get(key);
            if (value == null) result.putString(key, null);
            else if (value instanceof Boolean) result.putBoolean(key, (Boolean) value);
            else if (value instanceof Integer) result.putInt(key, (Integer) value);
            else if (value instanceof Long) result.putLong(key, (Long) value);
            else if (value instanceof Double) result.putDouble(key, (Double) value);
            else if (value instanceof String) result.putString(key, (String) value);
            else if (value instanceof boolean[]) result.putBooleanArray(key, (boolean[]) value);
            else if (value instanceof int[]) result.putIntArray(key, (int[]) value);
            else if (value instanceof long[]) result.putLongArray(key, (long[]) value);
            else if (value instanceof double[]) result.putDoubleArray(key, (double[]) value);
            else if (value instanceof String[]) result.putStringArray(key, (String[]) value);
            else if (value instanceof PersistableBundle) result.putPersistableBundle(key, (PersistableBundle) value);
            else throw new IllegalArgumentException("Bad value in PersistableBundle key=" + key + " value=" + value);
        }
        return result;
    }
}
