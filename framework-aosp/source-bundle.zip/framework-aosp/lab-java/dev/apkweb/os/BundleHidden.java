package dev.apkweb.os;

import android.os.Bundle;
import java.util.Objects;
import java.util.Set;

/**
 * Bundle.kindofEquals (hidden, used by the original android.location.Location.equals-like comparisons): two bundles are equal when they hold the same keys with equal values,
 * nested Bundles compared by content and arrays by element. scripts/prepare-javatime-sources.py rewrites the hidden call site to this helper (documented transform).
 */
public final class BundleHidden {
    private BundleHidden() {}

    public static boolean kindofEquals(Bundle a, Bundle b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a.size() != b.size()) return false;
        Set<String> keys = a.keySet();
        for (String key : keys) {
            if (!b.containsKey(key)) return false;
            Object x = a.get(key), y = b.get(key);
            if (x instanceof Bundle && y instanceof Bundle) {
                if (!kindofEquals((Bundle) x, (Bundle) y)) return false;
            } else if (!Objects.deepEquals(x, y)) {
                return false;
            }
        }
        return true;
    }
}
