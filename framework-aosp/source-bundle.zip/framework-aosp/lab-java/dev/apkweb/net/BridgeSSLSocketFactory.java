package dev.apkweb.net;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import javax.net.ssl.SSLSocketFactory;

/** The default SSLSocketFactory of the web device: TLS happens inside the browser's fetch, so there are no TLS sockets to hand out and asking for one fails explicitly. */
public final class BridgeSSLSocketFactory extends SSLSocketFactory {
    private static SocketException unavailable() { return new SocketException("TLS sockets are not available on the web device: HTTPS goes through HttpsURLConnection (browser fetch); a TLS stack for raw SSLSockets is not part of this build"); }
    @Override public String[] getDefaultCipherSuites() { return new String[0]; }
    @Override public String[] getSupportedCipherSuites() { return new String[0]; }
    @Override public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException { throw unavailable(); }
    @Override public Socket createSocket(String host, int port) throws IOException { throw unavailable(); }
    @Override public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException { throw unavailable(); }
    @Override public Socket createSocket(InetAddress host, int port) throws IOException { throw unavailable(); }
    @Override public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException { throw unavailable(); }
}
