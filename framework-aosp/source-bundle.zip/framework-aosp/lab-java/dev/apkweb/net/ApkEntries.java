package dev.apkweb.net;

import java.io.IOException;
import java.io.InputStream;

/** Entries of the installed package (the APK a jar:file:...base.apk!/entry URL names). A native of the web device. */
public final class ApkEntries {
    private ApkEntries() {}
    public static native InputStream open(String archive, String entry) throws IOException;
}
