package dev.apkweb.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.util.List;
import java.util.Map;

/** java.net.HttpURLConnection for http: URLs on the web device; the work is in {@link BridgeHttpEngine}. */
public final class BridgeHttpURLConnection extends HttpURLConnection implements BridgeHttpEngine.BridgeAccess {
    private final BridgeHttpEngine engine;
    private final Proxy proxy;

    public BridgeHttpURLConnection(URL url, Proxy proxy) { super(url); this.proxy = proxy; this.engine = new BridgeHttpEngine(this, url); }

    @Override public long fixedLength() { return fixedContentLengthLong >= 0 ? fixedContentLengthLong : fixedContentLength; }
    @Override public URL getURL() { return engine.url(); }
    @Override public void connect() throws IOException { engine.connect(); connected = true; }
    @Override public void disconnect() { engine.disconnect(); }
    @Override public boolean usingProxy() { return proxy != null && proxy.type() != Proxy.Type.DIRECT; }
    @Override public void setRequestProperty(String field, String newValue) { engine.setRequestProperty(field, newValue); }
    @Override public void addRequestProperty(String field, String value) { engine.addRequestProperty(field, value); }
    @Override public String getRequestProperty(String field) { return engine.getRequestProperty(field); }
    @Override public Map<String, List<String>> getRequestProperties() { return engine.getRequestProperties(); }
    @Override public OutputStream getOutputStream() throws IOException { OutputStream out = engine.getOutputStream(); connected = true; return out; }
    @Override public InputStream getInputStream() throws IOException { InputStream in = engine.getInputStream(); connected = true; return in; }
    @Override public InputStream getErrorStream() { return engine.getErrorStream(); }
    @Override public int getResponseCode() throws IOException { int code = engine.getResponseCode(); connected = true; return code; }
    @Override public String getResponseMessage() throws IOException { return engine.getResponseMessage(); }
    @Override public String getHeaderField(String name) { return engine.getHeaderField(name); }
    @Override public String getHeaderField(int position) { return engine.getHeaderField(position); }
    @Override public String getHeaderFieldKey(int position) { return engine.getHeaderFieldKey(position); }
    @Override public Map<String, List<String>> getHeaderFields() { return engine.getHeaderFields(); }
}
