package dev.apkweb.net;

import java.security.Principal;
import java.security.cert.Certificate;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSessionContext;

/** What the page knows about the TLS session of a completed fetch: the peer host and port. Everything else is not exposed to JavaScript and says so. */
final class BridgeSSLSession implements SSLSession {
    private final String host; private final int port;
    BridgeSSLSession(String host, int port) { this.host = host; this.port = port; }
    private static UnsupportedOperationException hidden(String what) { return new UnsupportedOperationException(what + " is not exposed by the browser's fetch"); }
    @Override public byte[] getId() { return new byte[0]; }
    @Override public SSLSessionContext getSessionContext() { return null; }
    @Override public long getCreationTime() { throw hidden("getCreationTime"); }
    @Override public long getLastAccessedTime() { throw hidden("getLastAccessedTime"); }
    @Override public void invalidate() {}
    @Override public boolean isValid() { return true; }
    @Override public void putValue(String name, Object value) { throw hidden("putValue"); }
    @Override public Object getValue(String name) { return null; }
    @Override public void removeValue(String name) {}
    @Override public String[] getValueNames() { return new String[0]; }
    @Override public Certificate[] getPeerCertificates() throws SSLPeerUnverifiedException { throw new SSLPeerUnverifiedException("peer certificates are not exposed by the browser's fetch"); }
    @Override public Certificate[] getLocalCertificates() { return null; }
    @SuppressWarnings("deprecation")
    @Override public javax.security.cert.X509Certificate[] getPeerCertificateChain() throws SSLPeerUnverifiedException { throw new SSLPeerUnverifiedException("peer certificates are not exposed by the browser's fetch"); }
    @Override public Principal getPeerPrincipal() throws SSLPeerUnverifiedException { throw new SSLPeerUnverifiedException("the peer principal is not exposed by the browser's fetch"); }
    @Override public Principal getLocalPrincipal() { return null; }
    @Override public String getCipherSuite() { throw hidden("getCipherSuite"); }
    @Override public String getProtocol() { throw hidden("getProtocol"); }
    @Override public String getPeerHost() { return host; }
    @Override public int getPeerPort() { return port; }
    @Override public int getPacketBufferSize() { throw hidden("getPacketBufferSize"); }
    @Override public int getApplicationBufferSize() { throw hidden("getApplicationBufferSize"); }
}
