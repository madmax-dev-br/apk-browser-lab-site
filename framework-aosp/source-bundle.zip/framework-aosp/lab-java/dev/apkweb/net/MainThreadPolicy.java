package dev.apkweb.net;

import android.os.NetworkOnMainThreadException;
import dalvik.system.BlockGuard;

/**
 * What ActivityThread.handleBindApplication does for apps targeting API 11 or later: StrictMode.enableDeathOnNetwork() installs a policy on the main thread whose
 * onNetwork() throws NetworkOnMainThreadException (libcore's BlockGuardOs and the network bridge call it before resolving or connecting). Installed by the platform
 * when the application is bound; other threads keep BlockGuard's LAX_POLICY.
 */
public final class MainThreadPolicy implements BlockGuard.Policy {
    public static void install() { BlockGuard.setThreadPolicy(new MainThreadPolicy()); }
    @Override public void onWriteToDisk() {}
    @Override public void onReadFromDisk() {}
    @Override public void onNetwork() { throw new NetworkOnMainThreadException(); }
    @Override public void onUnbufferedIO() {}
    @Override public void onExplicitGc() {}
    @Override public int getPolicyMask() { return 0x0200; }   // StrictMode.DETECT_NETWORK
}
