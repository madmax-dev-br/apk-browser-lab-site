package dev.apkweb.net;

import dalvik.system.BlockGuard;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ProtocolException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * The HTTP/1.1 client behaviour of java.net.HttpURLConnection on Android (the observable behaviour of libcore's OkHttp-backed implementation: exception types and
 * messages, redirect rules, FileNotFoundException for 4xx/5xx, request body buffering, CookieHandler integration) on top of NetBridge. The transport itself is the
 * browser's fetch. Shared by BridgeHttpURLConnection and BridgeHttpsURLConnection.
 */
public final class BridgeHttpEngine {
    private static final int MAX_FOLLOW_UPS = 20;
    static final Comparator<String> FIELD_NAME_COMPARATOR = new Comparator<String>() {
        @Override public int compare(String a, String b) {
            if (a == b) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            return a.compareToIgnoreCase(b);
        }
    };

    private final HttpURLConnection owner;
    private URL url;
    private final ArrayList<String> requestNames = new ArrayList<String>(), requestValues = new ArrayList<String>();
    private boolean connected, executed;
    private IOException failure;
    private RequestBody requestBody;
    private int handle = -1;
    private final ArrayList<String> responseNames = new ArrayList<String>(), responseValues = new ArrayList<String>();
    private int responseCode = -1;
    private String responseMessage;
    private InputStream responseStream;
    private boolean disconnected;

    public BridgeHttpEngine(HttpURLConnection owner, URL url) { this.owner = owner; this.url = url; }

    public URL url() { return url; }

    // ---- request properties ------------------------------------------------------------------------------------------------------------------
    public void setRequestProperty(String field, String newValue) {
        if (connected) throw new IllegalStateException("Cannot set request property after connection is made");
        if (field == null) throw new NullPointerException("field == null");
        if (newValue == null) return;                       // OkHttp logs "Ignoring header ... because its value was null." and drops it
        for (int i = requestNames.size() - 1; i >= 0; i--) if (requestNames.get(i).equalsIgnoreCase(field)) { requestNames.remove(i); requestValues.remove(i); }
        requestNames.add(field); requestValues.add(newValue);
    }
    public void addRequestProperty(String field, String value) {
        if (connected) throw new IllegalStateException("Cannot add request property after connection is made");
        if (field == null) throw new NullPointerException("field == null");
        if (value == null) return;
        requestNames.add(field); requestValues.add(value);
    }
    public String getRequestProperty(String field) {
        if (field == null) return null;
        for (int i = requestNames.size() - 1; i >= 0; i--) if (requestNames.get(i).equalsIgnoreCase(field)) return requestValues.get(i);
        return null;
    }
    public Map<String, List<String>> getRequestProperties() {
        if (connected) throw new IllegalStateException("Cannot access request header fields after connection is set");
        return toMultimap(requestNames, requestValues, false);
    }

    private static Map<String, List<String>> toMultimap(List<String> names, List<String> values, boolean statusLine) {
        TreeMap<String, List<String>> result = new TreeMap<String, List<String>>(FIELD_NAME_COMPARATOR);
        for (int i = statusLine ? 0 : 0; i < names.size(); i++) {
            String name = names.get(i);
            if (name == null && !statusLine) continue;
            List<String> list = result.get(name);
            if (list == null) { list = new ArrayList<String>(2); result.put(name, list); }
            list.add(values.get(i));
        }
        for (Map.Entry<String, List<String>> entry : result.entrySet()) entry.setValue(Collections.unmodifiableList(entry.getValue()));
        return Collections.unmodifiableMap(result);
    }

    // ---- connection ---------------------------------------------------------------------------------------------------------------------------
    public void connect() throws IOException {
        if (connected) return;
        if (disconnected) throw new IOException("disconnected");
        String host = url.getHost();
        if (host == null || host.isEmpty()) throw new java.net.UnknownHostException(url.toString());
        if (url.getProtocol().equals("http") && !NetBridge.cleartextPermitted(host)) throw new IOException("Cleartext HTTP traffic to " + host + " not permitted");
        // Like libcore's BlockGuardOs: resolving and connecting a socket on a thread whose policy forbids it (the main thread) raises NetworkOnMainThreadException.
        BlockGuard.getThreadPolicy().onNetwork();
        InetAddress.getAllByName(host);                    // android_getaddrinfo: UnknownHostException when the network is off or the host is not permitted
        connected = true;
    }

    public OutputStream getOutputStream() throws IOException {
        if (!owner.getDoOutput()) throw new ProtocolException("method does not support a request body: " + owner.getRequestMethod());
        if (executed) throw new ProtocolException("cannot write request body after response has been read");
        if (requestBody == null) {
            long fixed = ((BridgeAccess) owner).fixedLength();
            requestBody = new RequestBody(fixed);
            connect();
        }
        return requestBody;
    }

    /** Implemented by the two connection classes so the engine can read the protected streaming-mode fields of HttpURLConnection. */
    public interface BridgeAccess { long fixedLength(); }

    private final class RequestBody extends OutputStream {
        private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        private final long limit;
        private boolean closed;
        RequestBody(long limit) { this.limit = limit; }
        @Override public void write(int b) throws IOException { write(new byte[] { (byte) b }, 0, 1); }
        @Override public void write(byte[] bytes, int offset, int count) throws IOException {
            if (closed) throw new IOException("stream closed");
            if (offset < 0 || count < 0 || offset > bytes.length - count) throw new ArrayIndexOutOfBoundsException();
            if (limit >= 0 && buffer.size() + count > limit) throw new ProtocolException("expected " + (limit - buffer.size()) + " bytes but received " + count);
            buffer.write(bytes, offset, count);
        }
        @Override public void close() throws IOException {
            if (closed) return;
            closed = true;
            if (limit >= 0 && buffer.size() < limit) throw new ProtocolException("unexpected end of stream");
        }
        byte[] bytes() { return buffer.toByteArray(); }
        boolean bounded() { return limit >= 0; }
    }

    // ---- execution ---------------------------------------------------------------------------------------------------------------------------
    private boolean permitsBody(String method) { return !(method.equals("GET") || method.equals("HEAD")); }

    private String[] buildHeaders(String method, boolean hasBody, ArrayList<String> names, ArrayList<String> values) throws IOException {
        ArrayList<String> out = new ArrayList<String>();
        boolean hasUserAgent = false, hasContentType = false;
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            if (name.equalsIgnoreCase("User-Agent")) hasUserAgent = true;
            if (name.equalsIgnoreCase("Content-Type")) hasContentType = true;
            out.add(name); out.add(values.get(i));
        }
        if (!hasUserAgent) { out.add("User-Agent"); out.add(userAgent()); }
        if (hasBody && !hasContentType) { out.add("Content-Type"); out.add("application/x-www-form-urlencoded"); }
        CookieHandler cookies = CookieHandler.getDefault();
        if (cookies != null) {
            URI uri = toUri(url);
            if (uri != null) {
                Map<String, List<String>> found = cookies.get(uri, toMultimap(names, values, false));
                if (found != null) for (Map.Entry<String, List<String>> entry : found.entrySet()) {
                    String key = entry.getKey();
                    if (("Cookie".equalsIgnoreCase(key) || "Cookie2".equalsIgnoreCase(key)) && entry.getValue() != null && !entry.getValue().isEmpty()) {
                        StringBuilder joined = new StringBuilder();
                        for (int i = 0; i < entry.getValue().size(); i++) { if (i > 0) joined.append("; "); joined.append(entry.getValue().get(i)); }
                        out.add(key); out.add(joined.toString());
                    }
                }
            }
        }
        return out.toArray(new String[0]);
    }

    private static String userAgent() {
        String agent = System.getProperty("http.agent");
        return agent != null ? agent : "Dalvik/2.1.0 (Linux; U; Android 13)";
    }

    private static URI toUri(URL u) {
        try { return new URI(u.getProtocol(), u.getUserInfo(), u.getHost(), u.getPort(), u.getPath(), u.getQuery(), null); }
        catch (Exception e) { return null; }
    }

    private static boolean isRedirect(int code) { return code == 300 || code == 301 || code == 302 || code == 303 || code == 307 || code == 308; }

    private void execute() throws IOException {
        if (failure != null) throw failure;
        if (executed) return;
        connect();
        executed = true;
        try { run(); }
        catch (IOException e) { failure = e; throw e; }
    }

    private void run() throws IOException {
        String method = owner.getRequestMethod();
        if (requestBody != null && !requestBody.closed && requestBody.bounded()) throw new ProtocolException("unexpected end of stream");
        if (owner.getDoOutput() && method.equals("GET")) method = "POST";   // asking for a request body stream implies POST (OkHttp's HttpURLConnectionImpl)
        byte[] body = requestBody != null ? requestBody.bytes() : null;
        if (body != null && !permitsBody(method)) throw new ProtocolException("method does not support a request body: " + method);
        ArrayList<String> names = new ArrayList<String>(requestNames), values = new ArrayList<String>(requestValues);
        boolean follow = owner.getInstanceFollowRedirects();
        for (int hops = 0; ; hops++) {
            String[] headers = buildHeaders(method, body != null, names, values);
            int connectTimeout = owner.getConnectTimeout(), readTimeout = owner.getReadTimeout();
            handle = NetBridge.reserve();
            if (disconnected) { NetBridge.close(handle); handle = -1; throw new java.net.SocketException("Socket closed"); }
            handle = NetBridge.open(handle, method, stripFragment(url), headers, body, follow ? 1 : 0, connectTimeout, readTimeout);
            String[] head = NetBridge.head(handle);
            responseNames.clear(); responseValues.clear();
            String version = head[0];
            responseCode = Integer.parseInt(head[1]); responseMessage = head[2];
            String finalUrl = head[3];
            if (finalUrl != null && !finalUrl.equals(stripFragment(url))) url = new URL(finalUrl);
            responseNames.add(null); responseValues.add(version + " " + responseCode + " " + responseMessage);
            for (int i = 4; i + 1 < head.length; i += 2) { responseNames.add(head[i]); responseValues.add(head[i + 1]); }
            CookieHandler cookies = CookieHandler.getDefault();
            if (cookies != null) {
                URI uri = toUri(url);
                if (uri != null) cookies.put(uri, toMultimap(responseNames, responseValues, false));
            }
            if (follow && isRedirect(responseCode)) {
                String location = getHeaderField("Location");
                URL next = null;
                if (location != null) { try { next = new URL(url, location); } catch (java.net.MalformedURLException e) { next = null; } }
                boolean supported = next != null && (next.getProtocol().equals("http") || next.getProtocol().equals("https"));
                boolean methodOk = true, becomesGet = false;
                if (responseCode == 307 || responseCode == 308) methodOk = method.equals("GET") || method.equals("HEAD");
                else if (permitsBody(method)) becomesGet = true;
                if (supported && methodOk) {
                    if (hops + 1 > MAX_FOLLOW_UPS) { NetBridge.close(handle); handle = -1; throw new ProtocolException("Too many follow-up requests: " + (hops + 1)); }
                    NetBridge.close(handle); handle = -1;
                    boolean sameHost = next.getHost().equalsIgnoreCase(url.getHost()) && next.getPort() == url.getPort() && next.getProtocol().equals(url.getProtocol());
                    if (becomesGet) { method = "GET"; body = null; removeAll(names, values, "Content-Type"); removeAll(names, values, "Content-Length"); removeAll(names, values, "Transfer-Encoding"); }
                    if (!sameHost) removeAll(names, values, "Authorization");
                    removeAll(names, values, "Host");
                    url = next;
                    continue;
                }
            }
            break;
        }
        if (method.equals("HEAD") || responseCode == 204 || responseCode == 304 || (responseCode >= 100 && responseCode < 200)) { NetBridge.close(handle); responseStream = new EmptyStream(); handle = -1; }
        else responseStream = new BodyStream(handle, owner.getReadTimeout());
    }

    private static void removeAll(ArrayList<String> names, ArrayList<String> values, String field) {
        for (int i = names.size() - 1; i >= 0; i--) if (names.get(i).equalsIgnoreCase(field)) { names.remove(i); values.remove(i); }
    }

    private static String stripFragment(URL u) {
        String text = u.toExternalForm();
        int hash = text.indexOf('#');
        return hash < 0 ? text : text.substring(0, hash);
    }

    private static final class EmptyStream extends InputStream {
        @Override public int read() { return -1; }
        @Override public int read(byte[] b, int off, int len) { return len == 0 ? 0 : -1; }
    }

    private static final class BodyStream extends InputStream {
        private final int handle, readTimeout;
        private boolean closed, eof;
        BodyStream(int handle, int readTimeout) { this.handle = handle; this.readTimeout = readTimeout; }
        @Override public int read() throws IOException { byte[] one = new byte[1]; int n = read(one, 0, 1); return n < 0 ? -1 : one[0] & 0xff; }
        @Override public int read(byte[] buffer, int offset, int count) throws IOException {
            if (offset < 0 || count < 0 || offset > buffer.length - count) throw new ArrayIndexOutOfBoundsException();
            if (closed) throw new IOException("stream closed");
            if (count == 0) return 0;
            if (eof) return -1;
            int n = NetBridge.read(handle, buffer, offset, count, readTimeout);
            if (n < 0) { eof = true; NetBridge.close(handle); return -1; }
            return n;
        }
        @Override public int available() throws IOException { if (closed) throw new IOException("stream closed"); return eof ? 0 : NetBridge.available(handle); }
        @Override public void close() { if (!closed) { closed = true; NetBridge.close(handle); } }
    }

    // ---- response ----------------------------------------------------------------------------------------------------------------------------
    public InputStream getInputStream() throws IOException {
        if (!owner.getDoInput()) throw new ProtocolException("This protocol does not support input");
        execute();
        if (responseCode >= 400) throw new FileNotFoundException(url.toString());
        return responseStream;
    }
    public InputStream getErrorStream() {
        try { execute(); } catch (IOException e) { return null; }
        return responseCode >= 400 ? responseStream : null;
    }
    public int getResponseCode() throws IOException { execute(); return responseCode; }
    public String getResponseMessage() throws IOException { execute(); return responseMessage; }

    private void executeQuietly() { try { execute(); } catch (IOException ignored) { } }
    public String getHeaderField(String name) {
        executeQuietly();
        if (responseCode < 0) return null;
        if (name == null) return responseValues.get(0);
        for (int i = responseNames.size() - 1; i >= 1; i--) if (name.equalsIgnoreCase(responseNames.get(i))) return responseValues.get(i);
        return null;
    }
    public String getHeaderField(int position) {
        executeQuietly();
        return responseCode >= 0 && position >= 0 && position < responseValues.size() ? responseValues.get(position) : null;
    }
    public String getHeaderFieldKey(int position) {
        executeQuietly();
        return responseCode >= 0 && position >= 0 && position < responseNames.size() ? responseNames.get(position) : null;
    }
    public Map<String, List<String>> getHeaderFields() {
        executeQuietly();
        if (responseCode < 0) return Collections.<String, List<String>>emptyMap();
        return toMultimap(responseNames, responseValues, true);
    }

    public void disconnect() {
        disconnected = true;
        if (handle >= 0) { NetBridge.close(handle); handle = -1; }
        if (responseStream != null && !(responseStream instanceof EmptyStream)) { try { responseStream.close(); } catch (Exception ignored) { } }
    }
}
