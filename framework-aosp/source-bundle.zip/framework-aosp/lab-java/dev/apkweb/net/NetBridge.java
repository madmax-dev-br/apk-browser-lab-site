package dev.apkweb.net;

import java.io.IOException;

/**
 * Lab-authored boundary between the original java.net classes and the browser's fetch (src/network-native.js). Every method is a native of the web device:
 * a call that waits for the network parks the calling Java thread in the scheduler (it never blocks the page) and resumes with the bytes or the right exception.
 * Name resolution is NOT done here: InetAddress goes through libcore.io.Linux.android_getaddrinfo like on Android, and the device network policy answers it.
 */
public final class NetBridge {
    private NetBridge() {}

    /**
     * Sends one HTTP request. `headers` holds name,value pairs in order; `body` may be null. `redirect` is 0 (return 3xx responses to the caller) or 1 (let the
     * transport follow them). Returns the ticket's handle once the response head has arrived; throws the exception an Android device would throw (ConnectException when the
     * network is off or the host is not permitted, SocketTimeoutException, SSLException, ...).
     */
    public static native int open(int ticket, String method, String url, String[] headers, byte[] body, int redirect, int connectTimeoutMs, int readTimeoutMs) throws IOException;

    /** Reserves the handle of an exchange before it starts, so that close() from another thread can abort a request that is still waiting for its response head. */
    public static native int reserve();

    /** The response head: [protocolVersion, status, reason, finalUrl, name1, value1, name2, value2, ...]. */
    public static native String[] head(int handle);

    /** Reads response body bytes (parks until some are available); -1 at the end of the body. */
    public static native int read(int handle, byte[] buffer, int offset, int length, int readTimeoutMs) throws IOException;

    /** Bytes of the response body already received and not yet read. */
    public static native int available(int handle);

    /**
     * The app's cleartext policy for `host` (android.security.NetworkSecurityPolicy): android:usesCleartextTraffic when the manifest sets it, otherwise permitted only for apps
     * targeting API 27 or lower. A network_security_config XML is not interpreted yet.
     */
    public static native boolean cleartextPermitted(String host);

    /** Aborts the exchange and releases the handle. */
    public static native void close(int handle);
}
