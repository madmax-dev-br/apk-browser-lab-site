package dev.apkweb.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Proxy;
import java.net.URL;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;

/**
 * javax.net.ssl.HttpsURLConnection over fetch. The browser performs the handshake and certificate validation; a failure there surfaces as SSLHandshakeException. A
 * HostnameVerifier installed by the app is called with the peer host after the response head arrived and can still reject the connection, but cannot override the browser's
 * certificate validation. Certificates, cipher suite and protocol of the session are not exposed to JavaScript and the getters that need them fail explicitly.
 */
public final class BridgeHttpsURLConnection extends HttpsURLConnection implements BridgeHttpEngine.BridgeAccess {
    private final BridgeHttpEngine engine;
    private final Proxy proxy;
    private boolean verified;

    public BridgeHttpsURLConnection(URL url, Proxy proxy) { super(url); this.proxy = proxy; this.engine = new BridgeHttpEngine(this, url); }

    private void verify() throws IOException {
        if (verified) return;
        HostnameVerifier verifier = getHostnameVerifier();
        if (verifier != null && !verifier.getClass().getName().equals("com.android.okhttp.internal.tls.OkHostnameVerifier")) {
            URL u = engine.url(); int port = u.getPort() != -1 ? u.getPort() : 443;
            if (!verifier.verify(u.getHost(), new BridgeSSLSession(u.getHost(), port))) throw new SSLPeerUnverifiedException("Hostname " + u.getHost() + " not verified");
        }
        verified = true;
    }

    @Override public long fixedLength() { return fixedContentLengthLong >= 0 ? fixedContentLengthLong : fixedContentLength; }
    @Override public URL getURL() { return engine.url(); }
    @Override public void connect() throws IOException { engine.connect(); connected = true; }
    @Override public void disconnect() { engine.disconnect(); }
    @Override public boolean usingProxy() { return proxy != null && proxy.type() != Proxy.Type.DIRECT; }
    @Override public void setRequestProperty(String field, String newValue) { engine.setRequestProperty(field, newValue); }
    @Override public void addRequestProperty(String field, String value) { engine.addRequestProperty(field, value); }
    @Override public String getRequestProperty(String field) { return engine.getRequestProperty(field); }
    @Override public Map<String, List<String>> getRequestProperties() { return engine.getRequestProperties(); }
    @Override public OutputStream getOutputStream() throws IOException { OutputStream out = engine.getOutputStream(); connected = true; return out; }
    @Override public InputStream getInputStream() throws IOException { InputStream in = engine.getInputStream(); connected = true; verify(); return in; }
    @Override public InputStream getErrorStream() { return engine.getErrorStream(); }
    @Override public int getResponseCode() throws IOException { int code = engine.getResponseCode(); connected = true; verify(); return code; }
    @Override public String getResponseMessage() throws IOException { return engine.getResponseMessage(); }
    @Override public String getHeaderField(String name) { return engine.getHeaderField(name); }
    @Override public String getHeaderField(int position) { return engine.getHeaderField(position); }
    @Override public String getHeaderFieldKey(int position) { return engine.getHeaderFieldKey(position); }
    @Override public Map<String, List<String>> getHeaderFields() { return engine.getHeaderFields(); }

    @Override public String getCipherSuite() { throw new UnsupportedOperationException("the cipher suite is not exposed by the browser's fetch"); }
    @Override public Certificate[] getLocalCertificates() { return null; }
    @Override public Certificate[] getServerCertificates() throws SSLPeerUnverifiedException { throw new SSLPeerUnverifiedException("server certificates are not exposed by the browser's fetch"); }
    @Override public Principal getPeerPrincipal() throws SSLPeerUnverifiedException { throw new SSLPeerUnverifiedException("the peer principal is not exposed by the browser's fetch"); }
    @Override public Principal getLocalPrincipal() { return null; }
}
