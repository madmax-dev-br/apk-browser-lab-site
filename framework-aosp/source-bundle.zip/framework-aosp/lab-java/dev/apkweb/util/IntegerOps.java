package dev.apkweb.util;

/** Lab-authored java.lang.Integer statics, see BoxOps. */
public final class IntegerOps {
    private IntegerOps() {}

    public static Integer valueOf(String s) throws NumberFormatException { return Integer.valueOf(Integer.parseInt(s, 10)); }
    public static Integer valueOf(String s, int radix) throws NumberFormatException { return Integer.valueOf(Integer.parseInt(s, radix)); }

    public static int parseInt(CharSequence s, int beginIndex, int endIndex, int radix) throws NumberFormatException {
        return Integer.parseInt(BoxOps.slice(s, beginIndex, endIndex), radix);
    }

    public static int parseUnsignedInt(String s, int radix) throws NumberFormatException {
        if (s == null) throw new NumberFormatException("null");
        int len = s.length();
        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar == '-') throw new NumberFormatException(String.format("Illegal leading minus sign on unsigned string %s.", s));
            if (len <= 5 || (radix == 10 && len <= 9)) return Integer.parseInt(s, radix);
            long ell = Long.parseLong(s, radix);
            if ((ell & 0xffff_ffff_0000_0000L) == 0) return (int) ell;
            throw new NumberFormatException(String.format("String value %s exceeds range of unsigned int.", s));
        }
        throw new NumberFormatException("For input string: \"" + s + "\"" + (radix == 10 ? "" : " under radix " + radix));
    }

    public static int parseUnsignedInt(CharSequence s, int beginIndex, int endIndex, int radix) throws NumberFormatException {
        return parseUnsignedInt(BoxOps.slice(s, beginIndex, endIndex), radix);
    }
}
