package dev.apkweb.util;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.*;

/**
 * Lab-authored AtomicReferenceOps: the java.util.concurrent.atomic.AtomicReference methods (android-13.0.0_r1 / JDK 11 semantics) the VM's host class does not provide natively. The host class has the atomic
 * primitives get/set/compareAndSet; everything here is built from them with the same retry loops as the JDK, so a green-thread switch between the read and the write only costs a retry.
 * The memory-order variants (Plain, Opaque, Acquire, Release, weak*) are all the volatile operation: the VM is single-processor.
 */
public final class AtomicReferenceOps {
    private AtomicReferenceOps() {}
    public static <V> V updateAndGet(AtomicReference<V> a, UnaryOperator<V> f)
    {
        for (;;) {
            V p = a.get();
            V n = f.apply(p);
            if (a.compareAndSet(p, n)) return n;
        }
    }
    public static <V> V getAndUpdate(AtomicReference<V> a, UnaryOperator<V> f)
    {
        for (;;) {
            V p = a.get();
            V n = f.apply(p);
            if (a.compareAndSet(p, n)) return p;
        }
    }
    public static <V> V accumulateAndGet(AtomicReference<V> a, V x, BinaryOperator<V> f)
    {
        for (;;) {
            V p = a.get();
            V n = f.apply(p, x);
            if (a.compareAndSet(p, n)) return n;
        }
    }
    public static <V> V getAndAccumulate(AtomicReference<V> a, V x, BinaryOperator<V> f)
    {
        for (;;) {
            V p = a.get();
            V n = f.apply(p, x);
            if (a.compareAndSet(p, n)) return p;
        }
    }
    public static <V> V compareAndExchange(AtomicReference<V> a, V expected, V newValue)
    {
        for (;;) {
            V witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static <V> V compareAndExchangeAcquire(AtomicReference<V> a, V expected, V newValue)
    {
        for (;;) {
            V witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static <V> V compareAndExchangeRelease(AtomicReference<V> a, V expected, V newValue)
    {
        for (;;) {
            V witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static <V> V getAcquire(AtomicReference<V> a)
    {
        return a.get();
    }
    public static <V> V getOpaque(AtomicReference<V> a)
    {
        return a.get();
    }
    public static <V> V getPlain(AtomicReference<V> a)
    {
        return a.get();
    }
    public static <V> void setOpaque(AtomicReference<V> a, V newValue)
    {
        a.set(newValue);
    }
    public static <V> void setPlain(AtomicReference<V> a, V newValue)
    {
        a.set(newValue);
    }
    public static <V> void setRelease(AtomicReference<V> a, V newValue)
    {
        a.set(newValue);
    }
    public static <V> boolean weakCompareAndSetAcquire(AtomicReference<V> a, V expected, V newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static <V> boolean weakCompareAndSetPlain(AtomicReference<V> a, V expected, V newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static <V> boolean weakCompareAndSetRelease(AtomicReference<V> a, V expected, V newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static <V> boolean weakCompareAndSetVolatile(AtomicReference<V> a, V expected, V newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
}
