package dev.apkweb.util;

import java.util.Locale;

/** DateFormat.getIcuDateFormatSymbols(locale).getAmPmStrings() (hidden ICU-backed API): the lab has no ICU locale data, so the AM/PM markers are the English ones for every locale. */
public final class DateSymbolsHidden {
    private DateSymbolsHidden() { }
    public static String[] amPmStrings(Locale locale) { return new String[] {"AM", "PM"}; }
}
