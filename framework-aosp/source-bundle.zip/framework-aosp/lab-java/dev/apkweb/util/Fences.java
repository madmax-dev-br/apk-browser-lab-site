package dev.apkweb.util;

/** java.lang.invoke.VarHandle's static fences for the original ConcurrentSkipListMap. Green threads switch only at interpreter safepoints over one sequentially consistent heap, so there is no reordering to fence: the three calls are intentionally empty. */
public final class Fences {
    private Fences() {}
    public static void acquire() {}
    public static void release() {}
    public static void full() {}
}
