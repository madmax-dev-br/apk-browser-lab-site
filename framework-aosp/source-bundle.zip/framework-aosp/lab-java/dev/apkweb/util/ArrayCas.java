package dev.apkweb.util;

/** Element access with compare-and-set for the VarHandle array views the original java.util.concurrent.Exchanger uses (MethodHandles.arrayElementVarHandle). A compare-and-set is atomic because it holds the array's monitor. */
public final class ArrayCas {
    private ArrayCas() {}
    public static Object getAcquire(Object[] array, int index) { synchronized (array) { return array[index]; } }
    public static boolean compareAndSet(Object[] array, int index, Object expected, Object update) {
        synchronized (array) { if (array[index] != expected) return false; array[index] = update; return true; }
    }
}
