package dev.apkweb.util;

/** The secondary random seed ThreadLocalRandom.nextSecondarySeed() (package-private in the JDK) gives ConcurrentSkipListMap for its level choice: the same xorshift step (Marsaglia 13/17/5) over a seed that starts from a fixed non-zero value, so skip-list shapes are reproducible on the virtual device. Never returns 0, like the JDK method. */
public final class SecondarySeed {
    private static int seed = 0x9e3779b9;
    private SecondarySeed() {}
    public static synchronized int next() {
        int r = seed;
        r ^= r << 13;
        r ^= r >>> 17;
        r ^= r << 5;
        if (r == 0) r = 1;
        return seed = r;
    }
}
