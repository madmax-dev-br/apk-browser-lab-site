package dev.apkweb.util;

import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.function.*;

/**
 * Lab-authored AtomicReferenceArrayOps: the java.util.concurrent.atomic.AtomicReferenceArray methods (android-13.0.0_r1 / JDK 11 semantics) the VM's host class does not provide
 * natively, built from its get/set/compareAndSet with the JDK's retry loops. The memory-order variants (Plain, Opaque, Acquire, Release, weak*) are the volatile operation: the VM is
 * single-processor.
 */
public final class AtomicReferenceArrayOps {
    private AtomicReferenceArrayOps() {}

    public static <E> E updateAndGet(AtomicReferenceArray<E> a, int i, UnaryOperator<E> f)
    {
        for (;;) {
            E p = a.get(i);
            E n = f.apply(p);
            if (a.compareAndSet(i, p, n)) return n;
        }
    }

    public static <E> E getAndUpdate(AtomicReferenceArray<E> a, int i, UnaryOperator<E> f)
    {
        for (;;) {
            E p = a.get(i);
            E n = f.apply(p);
            if (a.compareAndSet(i, p, n)) return p;
        }
    }

    public static <E> E accumulateAndGet(AtomicReferenceArray<E> a, int i, E x, BinaryOperator<E> f)
    {
        for (;;) {
            E p = a.get(i);
            E n = f.apply(p, x);
            if (a.compareAndSet(i, p, n)) return n;
        }
    }

    public static <E> E getAndAccumulate(AtomicReferenceArray<E> a, int i, E x, BinaryOperator<E> f)
    {
        for (;;) {
            E p = a.get(i);
            E n = f.apply(p, x);
            if (a.compareAndSet(i, p, n)) return p;
        }
    }

    public static <E> E compareAndExchange(AtomicReferenceArray<E> a, int i, E expected, E newValue)
    {
        for (;;) {
            E witness = a.get(i);
            if (witness != expected) return witness;
            if (a.compareAndSet(i, expected, newValue)) return expected;
        }
    }

    public static <E> E compareAndExchangeAcquire(AtomicReferenceArray<E> a, int i, E expected, E newValue)
    {
        for (;;) {
            E witness = a.get(i);
            if (witness != expected) return witness;
            if (a.compareAndSet(i, expected, newValue)) return expected;
        }
    }

    public static <E> E compareAndExchangeRelease(AtomicReferenceArray<E> a, int i, E expected, E newValue)
    {
        for (;;) {
            E witness = a.get(i);
            if (witness != expected) return witness;
            if (a.compareAndSet(i, expected, newValue)) return expected;
        }
    }

    public static <E> E getAcquire(AtomicReferenceArray<E> a, int i)
    {
        return a.get(i);
    }

    public static <E> E getOpaque(AtomicReferenceArray<E> a, int i)
    {
        return a.get(i);
    }

    public static <E> E getPlain(AtomicReferenceArray<E> a, int i)
    {
        return a.get(i);
    }

    public static <E> void setOpaque(AtomicReferenceArray<E> a, int i, E newValue)
    {
        a.set(i, newValue);
    }

    public static <E> void setPlain(AtomicReferenceArray<E> a, int i, E newValue)
    {
        a.set(i, newValue);
    }

    public static <E> void setRelease(AtomicReferenceArray<E> a, int i, E newValue)
    {
        a.set(i, newValue);
    }

    public static <E> boolean weakCompareAndSetAcquire(AtomicReferenceArray<E> a, int i, E expected, E newValue)
    {
        return a.compareAndSet(i, expected, newValue);
    }

    public static <E> boolean weakCompareAndSetPlain(AtomicReferenceArray<E> a, int i, E expected, E newValue)
    {
        return a.compareAndSet(i, expected, newValue);
    }

    public static <E> boolean weakCompareAndSetRelease(AtomicReferenceArray<E> a, int i, E expected, E newValue)
    {
        return a.compareAndSet(i, expected, newValue);
    }

    public static <E> boolean weakCompareAndSetVolatile(AtomicReferenceArray<E> a, int i, E expected, E newValue)
    {
        return a.compareAndSet(i, expected, newValue);
    }

}
