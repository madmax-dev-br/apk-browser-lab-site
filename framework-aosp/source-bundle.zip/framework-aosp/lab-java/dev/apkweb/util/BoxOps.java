package dev.apkweb.util;

/**
 * Lab-authored statics of java.lang.Integer / Long / Boolean (android-13.0.0_r1 / JDK 11 semantics) the VM's host boxes do not provide natively. Each class has its own helper
 * type (IntegerOps, LongOps, BooleanOps) so the VM can route per owner; this file holds the shared range-checked CharSequence parsing.
 */
final class BoxOps {
    private BoxOps() {}

    static String slice(CharSequence s, int beginIndex, int endIndex) {
        if (s == null) throw new NullPointerException("s == null");
        if (beginIndex < 0 || beginIndex > endIndex || endIndex > s.length()) throw new IndexOutOfBoundsException();
        return s.subSequence(beginIndex, endIndex).toString();
    }
}
