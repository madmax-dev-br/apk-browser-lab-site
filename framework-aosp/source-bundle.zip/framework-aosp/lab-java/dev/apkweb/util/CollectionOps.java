package dev.apkweb.util;

import java.lang.reflect.Array;
import java.util.AbstractList;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.RandomAccess;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Lab-authored methods of java.util.ArrayDeque, ConcurrentLinkedQueue, LinkedBlockingQueue and CopyOnWriteArrayList (android-13.0.0_r1 / JDK 11 semantics) that the VM's host
 * collections lack: the bulk operations AbstractCollection would give them, plus the class-specific ones. Each is written over the collection's own public API; the VM routes the
 * receiver's call here (LAB_HELPERS in src/apk-runtime.js). No static state: helper methods run without class initialisation.
 */
public final class CollectionOps {
    private CollectionOps() {}

    // ---- AbstractCollection behaviour shared by the four types ---------------------------------------------------------------------------------------------------
    private static boolean containsAllImpl(Collection<?> self, Collection<?> c) {
        for (Object e : c) if (!self.contains(e)) return false;
        return true;
    }

    private static boolean removeAllImpl(Collection<?> self, Collection<?> c) {
        Objects.requireNonNull(c);
        boolean modified = false;
        Iterator<?> it = self.iterator();
        while (it.hasNext()) if (c.contains(it.next())) { it.remove(); modified = true; }
        return modified;
    }

    private static boolean retainAllImpl(Collection<?> self, Collection<?> c) {
        Objects.requireNonNull(c);
        boolean modified = false;
        Iterator<?> it = self.iterator();
        while (it.hasNext()) if (!c.contains(it.next())) { it.remove(); modified = true; }
        return modified;
    }

    @SuppressWarnings("unchecked")
    private static <T> T[] toArrayImpl(Collection<?> self, T[] a) {
        Object[] elements = self.toArray();
        int size = elements.length;
        if (a.length < size) a = (T[]) Array.newInstance(a.getClass().getComponentType(), size);
        System.arraycopy(elements, 0, a, 0, size);
        if (a.length > size) a[size] = null;
        return a;
    }

    private static <E> boolean addAllImpl(Collection<E> self, Collection<? extends E> c, boolean nullsFirst) {
        Objects.requireNonNull(c);
        if (c == self) throw new IllegalArgumentException();
        Object[] elements = c.toArray();
        if (nullsFirst) for (Object e : elements) Objects.requireNonNull(e);
        boolean modified = false;
        for (Object e : elements) {
            @SuppressWarnings("unchecked") E element = (E) e;
            if (self.add(element)) modified = true;
        }
        return modified;
    }

    public static boolean containsAll(ArrayDeque<?> self, Collection<?> c) { return containsAllImpl(self, c); }
    public static boolean removeAll(ArrayDeque<?> self, Collection<?> c) { return removeAllImpl(self, c); }
    public static boolean retainAll(ArrayDeque<?> self, Collection<?> c) { return retainAllImpl(self, c); }
    public static <T> T[] toArray(ArrayDeque<?> self, T[] a) { return toArrayImpl(self, a); }

    public static boolean containsAll(ConcurrentLinkedQueue<?> self, Collection<?> c) { return containsAllImpl(self, c); }
    public static boolean removeAll(ConcurrentLinkedQueue<?> self, Collection<?> c) { return removeAllImpl(self, c); }
    public static boolean retainAll(ConcurrentLinkedQueue<?> self, Collection<?> c) { return retainAllImpl(self, c); }
    public static <T> T[] toArray(ConcurrentLinkedQueue<?> self, T[] a) { return toArrayImpl(self, a); }

    public static boolean containsAll(LinkedBlockingQueue<?> self, Collection<?> c) { return containsAllImpl(self, c); }
    public static boolean removeAll(LinkedBlockingQueue<?> self, Collection<?> c) { return removeAllImpl(self, c); }
    public static boolean retainAll(LinkedBlockingQueue<?> self, Collection<?> c) { return retainAllImpl(self, c); }
    public static <T> T[] toArray(LinkedBlockingQueue<?> self, T[] a) { return toArrayImpl(self, a); }

    public static boolean containsAll(CopyOnWriteArrayList<?> self, Collection<?> c) { return containsAllImpl(self, c); }
    public static boolean removeAll(CopyOnWriteArrayList<?> self, Collection<?> c) { return removeAllImpl(self, c); }
    public static <T> T[] toArray(CopyOnWriteArrayList<?> self, T[] a) { return toArrayImpl(self, a); }

    public static <E> boolean addAll(ConcurrentLinkedQueue<E> self, Collection<? extends E> c) { return addAllImpl(self, c, true); }
    public static <E> boolean addAll(LinkedBlockingQueue<E> self, Collection<? extends E> c) { return addAllImpl(self, c, false); }

    private static String toStringImpl(Collection<?> self) {
        Iterator<?> it = self.iterator();
        if (!it.hasNext()) return "[]";
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (;;) {
            Object e = it.next();
            sb.append(e == self ? "(this Collection)" : e);
            if (!it.hasNext()) return sb.append(']').toString();
            sb.append(',').append(' ');
        }
    }

    public static String toString(ArrayDeque<?> self) { return toStringImpl(self); }
    public static String toString(ConcurrentLinkedQueue<?> self) { return toStringImpl(self); }
    public static String toString(LinkedBlockingQueue<?> self) { return toStringImpl(self); }

    public static String toString(CopyOnWriteArrayList<?> self) { return toStringImpl(self); }

    public static boolean equals(CopyOnWriteArrayList<?> self, Object o) {
        if (o == self) return true;
        if (!(o instanceof List)) return false;
        Iterator<?> mine = self.iterator(), theirs = ((List<?>) o).iterator();
        while (mine.hasNext() && theirs.hasNext()) if (!Objects.equals(mine.next(), theirs.next())) return false;
        return !(mine.hasNext() || theirs.hasNext());
    }

    public static int hashCode(CopyOnWriteArrayList<?> self) {
        int hashCode = 1;
        for (Object e : self) hashCode = 31 * hashCode + (e == null ? 0 : e.hashCode());
        return hashCode;
    }

    // ---- HashSet / LinkedHashSet ------------------------------------------------------------------------------------------------------------------------------------
    public static <E> Object clone(HashSet<E> self) { return new HashSet<E>(self); }

    public static <E> Object clone(LinkedHashSet<E> self) { return new LinkedHashSet<E>(self); }

    // ---- ArrayDeque -----------------------------------------------------------------------------------------------------------------------------------------------
    public static <E> ArrayDeque<E> clone(ArrayDeque<E> self) { return new ArrayDeque<E>(self); }

    public static <E> Iterator<E> descendingIterator(ArrayDeque<E> self) { return new DescendingIterator<E>(self); }

    private static final class DescendingIterator<E> implements Iterator<E> {
        private final ArrayDeque<E> deque;
        private final Object[] snapshot;
        private int next;
        private int last = -1;
        DescendingIterator(ArrayDeque<E> deque) { this.deque = deque; this.snapshot = deque.toArray(); this.next = snapshot.length - 1; }
        public boolean hasNext() { return next >= 0; }
        @SuppressWarnings("unchecked")
        public E next() {
            if (next < 0) throw new NoSuchElementException();
            last = next--;
            return (E) snapshot[last];
        }
        public void remove() {
            if (last < 0) throw new IllegalStateException();
            deque.removeLastOccurrence(snapshot[last]);
            last = -1;
        }
    }

    // ---- CopyOnWriteArrayList -------------------------------------------------------------------------------------------------------------------------------------
    public static <E> boolean addIfAbsent(CopyOnWriteArrayList<E> self, E e) {
        synchronized (self) {
            if (self.contains(e)) return false;
            self.add(e);
            return true;
        }
    }

    public static <E> int addAllAbsent(CopyOnWriteArrayList<E> self, Collection<? extends E> c) {
        Object[] elements = c.toArray();
        int added = 0;
        synchronized (self) {
            for (Object e : elements) {
                @SuppressWarnings("unchecked") E element = (E) e;
                if (!self.contains(element)) { self.add(element); added++; }
            }
        }
        return added;
    }

    public static <E> int indexOf(CopyOnWriteArrayList<E> self, E e, int index) {
        Object[] elements = self.toArray();
        for (int i = index; i < elements.length; i++) if (Objects.equals(e, elements[i])) return i;
        return -1;
    }

    public static <E> int lastIndexOf(CopyOnWriteArrayList<E> self, Object o) {
        Object[] elements = self.toArray();
        for (int i = elements.length - 1; i >= 0; i--) if (Objects.equals(o, elements[i])) return i;
        return -1;
    }

    public static <E> int lastIndexOf(CopyOnWriteArrayList<E> self, E e, int index) {
        Object[] elements = self.toArray();
        if (index >= elements.length) throw new IndexOutOfBoundsException(index + " >= " + elements.length);
        for (int i = index; i >= 0; i--) if (Objects.equals(e, elements[i])) return i;
        return -1;
    }

    public static <E> boolean retainAll(CopyOnWriteArrayList<E> self, Collection<?> c) {
        Objects.requireNonNull(c);
        boolean modified = false;
        synchronized (self) {
            for (int i = self.size() - 1; i >= 0; i--) if (!c.contains(self.get(i))) { self.remove(i); modified = true; }
        }
        return modified;
    }

    public static <E> ListIterator<E> listIterator(CopyOnWriteArrayList<E> self) { return new SnapshotIterator<E>(self.toArray(), 0); }

    public static <E> ListIterator<E> listIterator(CopyOnWriteArrayList<E> self, int index) {
        Object[] elements = self.toArray();
        if (index < 0 || index > elements.length) throw new IndexOutOfBoundsException("Index: " + index);
        return new SnapshotIterator<E>(elements, index);
    }

    /** The iterator of a CopyOnWriteArrayList: a snapshot that never throws ConcurrentModificationException and does not support mutation. */
    private static final class SnapshotIterator<E> implements ListIterator<E> {
        private final Object[] snapshot;
        private int cursor;
        SnapshotIterator(Object[] snapshot, int cursor) { this.snapshot = snapshot; this.cursor = cursor; }
        public boolean hasNext() { return cursor < snapshot.length; }
        public boolean hasPrevious() { return cursor > 0; }
        @SuppressWarnings("unchecked")
        public E next() {
            if (!hasNext()) throw new NoSuchElementException();
            return (E) snapshot[cursor++];
        }
        @SuppressWarnings("unchecked")
        public E previous() {
            if (!hasPrevious()) throw new NoSuchElementException();
            return (E) snapshot[--cursor];
        }
        public int nextIndex() { return cursor; }
        public int previousIndex() { return cursor - 1; }
        public void remove() { throw new UnsupportedOperationException(); }
        public void set(E e) { throw new UnsupportedOperationException(); }
        public void add(E e) { throw new UnsupportedOperationException(); }
    }

    public static <E> List<E> subList(CopyOnWriteArrayList<E> self, int fromIndex, int toIndex) {
        synchronized (self) {
            int len = self.size();
            if (fromIndex < 0 || toIndex > len || fromIndex > toIndex) throw new IndexOutOfBoundsException();
            return new SubList<E>(self, fromIndex, toIndex - fromIndex);
        }
    }

    /** A live view over a range of a CopyOnWriteArrayList; each access takes the list's lock. */
    private static final class SubList<E> extends AbstractList<E> implements RandomAccess {
        private final CopyOnWriteArrayList<E> list;
        private final int offset;
        private int size;
        SubList(CopyOnWriteArrayList<E> list, int offset, int size) { this.list = list; this.offset = offset; this.size = size; }
        private void checkIndex(int index, int size) { if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size); }
        public E set(int index, E element) { synchronized (list) { checkIndex(index, size); return list.set(offset + index, element); } }
        public E get(int index) { synchronized (list) { checkIndex(index, size); return list.get(offset + index); } }
        public int size() { synchronized (list) { return size; } }
        public void add(int index, E element) {
            synchronized (list) {
                if (index < 0 || index > size) throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
                list.add(offset + index, element);
                size++;
            }
        }
        public E remove(int index) {
            synchronized (list) {
                checkIndex(index, size);
                E result = list.remove(offset + index);
                size--;
                return result;
            }
        }
        public void clear() {
            synchronized (list) {
                for (int i = size - 1; i >= 0; i--) list.remove(offset + i);
                size = 0;
            }
        }
        public Iterator<E> iterator() { synchronized (list) { return listIterator(0); } }
        public ListIterator<E> listIterator(int index) {
            synchronized (list) {
                if (index < 0 || index > size) throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
                Object[] range = new Object[size];
                for (int i = 0; i < size; i++) range[i] = list.get(offset + i);
                return new SnapshotIterator<E>(range, index);
            }
        }
        public List<E> subList(int fromIndex, int toIndex) {
            synchronized (list) {
                if (fromIndex < 0 || toIndex > size || fromIndex > toIndex) throw new IndexOutOfBoundsException();
                return new SubList<E>(list, offset + fromIndex, toIndex - fromIndex);
            }
        }
    }
}
