package dev.apkweb.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.DoubleBinaryOperator;
import java.util.function.Function;
import java.util.function.IntBinaryOperator;
import java.util.function.LongBinaryOperator;
import java.util.function.ToDoubleBiFunction;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntBiFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongBiFunction;
import java.util.function.ToLongFunction;

/**
 * The parallel bulk operations of java.util.concurrent.ConcurrentHashMap (forEach/search/reduce with a parallelismThreshold, on mappings, keys, values and entries). The original
 * ConcurrentHashMap (framework.dex) runs every other method; these build ForkJoin CountedCompleter tasks and the VM has no ForkJoinPool, so the VM routes them here (LAB_HELPERS in
 * src/apk-runtime.js). Each walks the original map's weakly consistent entry iterator sequentially: the threshold only permits parallelism, it never requires it, and the results
 * are the ones the API specifies (the order in which a parallel run applies the functions is unspecified). No static state: helper methods run without class initialisation.
 */
public final class ChmBulkOps {
    private ChmBulkOps() {}

    // ---- bulk operations (sequential): entries ------------------------------------------------------------------------------------------------------------------
    public static <K, V> void forEach(ConcurrentHashMap<K, V> map, long threshold, BiConsumer<? super K, ? super V> action) {
        if (action == null) throw new NullPointerException();
        for (Map.Entry<K, V> entry : map.entrySet()) action.accept(entry.getKey(), entry.getValue());
    }

    public static <K, V, U> void forEach(ConcurrentHashMap<K, V> map, long threshold, BiFunction<? super K, ? super V, ? extends U> transformer, Consumer<? super U> action) {
        if (transformer == null || action == null) throw new NullPointerException();
        for (Map.Entry<K, V> entry : map.entrySet()) { U u = transformer.apply(entry.getKey(), entry.getValue()); if (u != null) action.accept(u); }
    }

    public static <K, V, U> U search(ConcurrentHashMap<K, V> map, long threshold, BiFunction<? super K, ? super V, ? extends U> searchFunction) {
        if (searchFunction == null) throw new NullPointerException();
        for (Map.Entry<K, V> entry : map.entrySet()) { U u = searchFunction.apply(entry.getKey(), entry.getValue()); if (u != null) return u; }
        return null;
    }

    public static <K, V, U> U reduce(ConcurrentHashMap<K, V> map, long threshold, BiFunction<? super K, ? super V, ? extends U> transformer, BiFunction<? super U, ? super U, ? extends U> reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        U result = null;
        for (Map.Entry<K, V> entry : map.entrySet()) {
            U u = transformer.apply(entry.getKey(), entry.getValue());
            if (u != null) result = result == null ? u : reducer.apply(result, u);
        }
        return result;
    }

    public static <K, V> double reduceToDouble(ConcurrentHashMap<K, V> map, long threshold, ToDoubleBiFunction<? super K, ? super V> transformer, double basis, DoubleBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        double result = basis;
        for (Map.Entry<K, V> entry : map.entrySet()) result = reducer.applyAsDouble(result, transformer.applyAsDouble(entry.getKey(), entry.getValue()));
        return result;
    }

    public static <K, V> long reduceToLong(ConcurrentHashMap<K, V> map, long threshold, ToLongBiFunction<? super K, ? super V> transformer, long basis, LongBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        long result = basis;
        for (Map.Entry<K, V> entry : map.entrySet()) result = reducer.applyAsLong(result, transformer.applyAsLong(entry.getKey(), entry.getValue()));
        return result;
    }

    public static <K, V> int reduceToInt(ConcurrentHashMap<K, V> map, long threshold, ToIntBiFunction<? super K, ? super V> transformer, int basis, IntBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        int result = basis;
        for (Map.Entry<K, V> entry : map.entrySet()) result = reducer.applyAsInt(result, transformer.applyAsInt(entry.getKey(), entry.getValue()));
        return result;
    }

    // ---- keys ---------------------------------------------------------------------------------------------------------------------------------------------------
    public static <K, V> void forEachKey(ConcurrentHashMap<K, V> map, long threshold, Consumer<? super K> action) {
        if (action == null) throw new NullPointerException();
        for (K key : map.keySet()) action.accept(key);
    }

    public static <K, V, U> void forEachKey(ConcurrentHashMap<K, V> map, long threshold, Function<? super K, ? extends U> transformer, Consumer<? super U> action) {
        if (transformer == null || action == null) throw new NullPointerException();
        for (K key : map.keySet()) { U u = transformer.apply(key); if (u != null) action.accept(u); }
    }

    public static <K, V, U> U searchKeys(ConcurrentHashMap<K, V> map, long threshold, Function<? super K, ? extends U> searchFunction) {
        if (searchFunction == null) throw new NullPointerException();
        for (K key : map.keySet()) { U u = searchFunction.apply(key); if (u != null) return u; }
        return null;
    }

    public static <K, V> K reduceKeys(ConcurrentHashMap<K, V> map, long threshold, BiFunction<? super K, ? super K, ? extends K> reducer) {
        if (reducer == null) throw new NullPointerException();
        K result = null;
        for (K key : map.keySet()) result = result == null ? key : reducer.apply(result, key);
        return result;
    }

    public static <K, V, U> U reduceKeys(ConcurrentHashMap<K, V> map, long threshold, Function<? super K, ? extends U> transformer, BiFunction<? super U, ? super U, ? extends U> reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        U result = null;
        for (K key : map.keySet()) { U u = transformer.apply(key); if (u != null) result = result == null ? u : reducer.apply(result, u); }
        return result;
    }

    public static <K, V> double reduceKeysToDouble(ConcurrentHashMap<K, V> map, long threshold, ToDoubleFunction<? super K> transformer, double basis, DoubleBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        double result = basis;
        for (K key : map.keySet()) result = reducer.applyAsDouble(result, transformer.applyAsDouble(key));
        return result;
    }

    public static <K, V> long reduceKeysToLong(ConcurrentHashMap<K, V> map, long threshold, ToLongFunction<? super K> transformer, long basis, LongBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        long result = basis;
        for (K key : map.keySet()) result = reducer.applyAsLong(result, transformer.applyAsLong(key));
        return result;
    }

    public static <K, V> int reduceKeysToInt(ConcurrentHashMap<K, V> map, long threshold, ToIntFunction<? super K> transformer, int basis, IntBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        int result = basis;
        for (K key : map.keySet()) result = reducer.applyAsInt(result, transformer.applyAsInt(key));
        return result;
    }

    // ---- values -------------------------------------------------------------------------------------------------------------------------------------------------
    public static <K, V> void forEachValue(ConcurrentHashMap<K, V> map, long threshold, Consumer<? super V> action) {
        if (action == null) throw new NullPointerException();
        for (V value : map.values()) action.accept(value);
    }

    public static <K, V, U> void forEachValue(ConcurrentHashMap<K, V> map, long threshold, Function<? super V, ? extends U> transformer, Consumer<? super U> action) {
        if (transformer == null || action == null) throw new NullPointerException();
        for (V value : map.values()) { U u = transformer.apply(value); if (u != null) action.accept(u); }
    }

    public static <K, V, U> U searchValues(ConcurrentHashMap<K, V> map, long threshold, Function<? super V, ? extends U> searchFunction) {
        if (searchFunction == null) throw new NullPointerException();
        for (V value : map.values()) { U u = searchFunction.apply(value); if (u != null) return u; }
        return null;
    }

    public static <K, V> V reduceValues(ConcurrentHashMap<K, V> map, long threshold, BiFunction<? super V, ? super V, ? extends V> reducer) {
        if (reducer == null) throw new NullPointerException();
        V result = null;
        for (V value : map.values()) result = result == null ? value : reducer.apply(result, value);
        return result;
    }

    public static <K, V, U> U reduceValues(ConcurrentHashMap<K, V> map, long threshold, Function<? super V, ? extends U> transformer, BiFunction<? super U, ? super U, ? extends U> reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        U result = null;
        for (V value : map.values()) { U u = transformer.apply(value); if (u != null) result = result == null ? u : reducer.apply(result, u); }
        return result;
    }

    public static <K, V> double reduceValuesToDouble(ConcurrentHashMap<K, V> map, long threshold, ToDoubleFunction<? super V> transformer, double basis, DoubleBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        double result = basis;
        for (V value : map.values()) result = reducer.applyAsDouble(result, transformer.applyAsDouble(value));
        return result;
    }

    public static <K, V> long reduceValuesToLong(ConcurrentHashMap<K, V> map, long threshold, ToLongFunction<? super V> transformer, long basis, LongBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        long result = basis;
        for (V value : map.values()) result = reducer.applyAsLong(result, transformer.applyAsLong(value));
        return result;
    }

    public static <K, V> int reduceValuesToInt(ConcurrentHashMap<K, V> map, long threshold, ToIntFunction<? super V> transformer, int basis, IntBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        int result = basis;
        for (V value : map.values()) result = reducer.applyAsInt(result, transformer.applyAsInt(value));
        return result;
    }

    // ---- entries ------------------------------------------------------------------------------------------------------------------------------------------------
    public static <K, V> void forEachEntry(ConcurrentHashMap<K, V> map, long threshold, Consumer<? super Map.Entry<K, V>> action) {
        if (action == null) throw new NullPointerException();
        for (Map.Entry<K, V> entry : map.entrySet()) action.accept(entry);
    }

    public static <K, V, U> void forEachEntry(ConcurrentHashMap<K, V> map, long threshold, Function<Map.Entry<K, V>, ? extends U> transformer, Consumer<? super U> action) {
        if (transformer == null || action == null) throw new NullPointerException();
        for (Map.Entry<K, V> entry : map.entrySet()) { U u = transformer.apply(entry); if (u != null) action.accept(u); }
    }

    public static <K, V, U> U searchEntries(ConcurrentHashMap<K, V> map, long threshold, Function<Map.Entry<K, V>, ? extends U> searchFunction) {
        if (searchFunction == null) throw new NullPointerException();
        for (Map.Entry<K, V> entry : map.entrySet()) { U u = searchFunction.apply(entry); if (u != null) return u; }
        return null;
    }

    public static <K, V> Map.Entry<K, V> reduceEntries(ConcurrentHashMap<K, V> map, long threshold, BiFunction<Map.Entry<K, V>, Map.Entry<K, V>, ? extends Map.Entry<K, V>> reducer) {
        if (reducer == null) throw new NullPointerException();
        Map.Entry<K, V> result = null;
        for (Map.Entry<K, V> entry : map.entrySet()) result = result == null ? entry : reducer.apply(result, entry);
        return result;
    }

    public static <K, V, U> U reduceEntries(ConcurrentHashMap<K, V> map, long threshold, Function<Map.Entry<K, V>, ? extends U> transformer, BiFunction<? super U, ? super U, ? extends U> reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        U result = null;
        for (Map.Entry<K, V> entry : map.entrySet()) { U u = transformer.apply(entry); if (u != null) result = result == null ? u : reducer.apply(result, u); }
        return result;
    }

    public static <K, V> double reduceEntriesToDouble(ConcurrentHashMap<K, V> map, long threshold, ToDoubleFunction<Map.Entry<K, V>> transformer, double basis, DoubleBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        double result = basis;
        for (Map.Entry<K, V> entry : map.entrySet()) result = reducer.applyAsDouble(result, transformer.applyAsDouble(entry));
        return result;
    }

    public static <K, V> long reduceEntriesToLong(ConcurrentHashMap<K, V> map, long threshold, ToLongFunction<Map.Entry<K, V>> transformer, long basis, LongBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        long result = basis;
        for (Map.Entry<K, V> entry : map.entrySet()) result = reducer.applyAsLong(result, transformer.applyAsLong(entry));
        return result;
    }

    public static <K, V> int reduceEntriesToInt(ConcurrentHashMap<K, V> map, long threshold, ToIntFunction<Map.Entry<K, V>> transformer, int basis, IntBinaryOperator reducer) {
        if (transformer == null || reducer == null) throw new NullPointerException();
        int result = basis;
        for (Map.Entry<K, V> entry : map.entrySet()) result = reducer.applyAsInt(result, transformer.applyAsInt(entry));
        return result;
    }
}
