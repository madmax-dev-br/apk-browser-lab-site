package dev.apkweb.util;

import java.io.Serializable;
import java.util.Comparator;

/** String.CASE_INSENSITIVE_ORDER (libcore android-13.0.0_r1 String.CaseInsensitiveComparator): the VM's host String hands this out for the static field. */
public final class CaseInsensitiveOrder implements Comparator<String>, Serializable {
    private static final long serialVersionUID = 8575799808933029326L;
    public int compare(String s1, String s2) { return s1.compareToIgnoreCase(s2); }
}
