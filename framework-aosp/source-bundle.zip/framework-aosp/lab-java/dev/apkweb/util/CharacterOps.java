package dev.apkweb.util;

/**
 * Lab-authored java.lang.Character statics (android-13.0.0_r1 / JDK 11 semantics) the VM's host Character lacks: the array and CharSequence code point operations, the surrogate and
 * code point range helpers, and the predicates that are fixed combinations of the general category (Character.getType, served by the host). The property-based ones (isAlphabetic,
 * isIdeographic, isMirrored, isUnicodeIdentifierStart/Part, getNumericValue) are host methods. No static state: helper methods run without class initialisation.
 */
public final class CharacterOps {
    private CharacterOps() {}

    public static boolean isValidCodePoint(int codePoint) { return codePoint >= 0 && codePoint <= 0x10FFFF; }
    public static boolean isBmpCodePoint(int codePoint) { return codePoint >>> 16 == 0; }
    public static boolean isSupplementaryCodePoint(int codePoint) { return codePoint >= 0x10000 && codePoint <= 0x10FFFF; }
    public static char highSurrogate(int codePoint) { return (char) ((codePoint >>> 10) + (0xD800 - (0x010000 >>> 10))); }
    public static char lowSurrogate(int codePoint) { return (char) ((codePoint & 0x3ff) + 0xDC00); }
    public static int compare(char x, char y) { return x - y; }
    public static String toString(char c) { return String.valueOf(c); }
    public static boolean isSpace(char ch) { return ch <= 0x0020 && (((((1L << 0x0009) | (1L << 0x000A) | (1L << 0x000C) | (1L << 0x000D) | (1L << 0x0020)) >> ch) & 1L) != 0); }

    public static char[] toChars(int codePoint) {
        if (isBmpCodePoint(codePoint)) return new char[] { (char) codePoint };
        if (isValidCodePoint(codePoint)) return new char[] { highSurrogate(codePoint), lowSurrogate(codePoint) };
        throw new IllegalArgumentException(String.format("Not a valid Unicode code point: 0x%X", codePoint));
    }

    public static int toChars(int codePoint, char[] dst, int dstIndex) {
        if (isBmpCodePoint(codePoint)) { dst[dstIndex] = (char) codePoint; return 1; }
        if (isValidCodePoint(codePoint)) { dst[dstIndex + 1] = lowSurrogate(codePoint); dst[dstIndex] = highSurrogate(codePoint); return 2; }
        throw new IllegalArgumentException(String.format("Not a valid Unicode code point: 0x%X", codePoint));
    }

    private static int toCodePoint(char high, char low) { return ((high << 10) + low) + (0x010000 - (0xD800 << 10) - 0xDC00); }

    public static int codePointAt(char[] a, int index) { return codePointAt(a, index, a.length); }

    public static int codePointAt(char[] a, int index, int limit) {
        if (index >= limit || limit < 0 || limit > a.length) throw new IndexOutOfBoundsException();
        char c1 = a[index];
        if (Character.isHighSurrogate(c1) && ++index < limit) {
            char c2 = a[index];
            if (Character.isLowSurrogate(c2)) return toCodePoint(c1, c2);
        }
        return c1;
    }

    public static int codePointBefore(char[] a, int index) { return codePointBefore(a, index, 0); }

    public static int codePointBefore(char[] a, int index, int start) {
        if (index <= start || start < 0 || start >= a.length) throw new IndexOutOfBoundsException();
        char c2 = a[--index];
        if (Character.isLowSurrogate(c2) && index > start) {
            char c1 = a[--index];
            if (Character.isHighSurrogate(c1)) return toCodePoint(c1, c2);
        }
        return c2;
    }

    public static int codePointCount(CharSequence seq, int beginIndex, int endIndex) {
        int length = seq.length();
        if (beginIndex < 0 || endIndex > length || beginIndex > endIndex) throw new IndexOutOfBoundsException();
        int n = endIndex - beginIndex;
        for (int i = beginIndex; i < endIndex; ) {
            if (Character.isHighSurrogate(seq.charAt(i++)) && i < endIndex && Character.isLowSurrogate(seq.charAt(i))) { n--; i++; }
        }
        return n;
    }

    public static int codePointCount(char[] a, int offset, int count) {
        if (count > a.length - offset || offset < 0 || count < 0) throw new IndexOutOfBoundsException();
        int endIndex = offset + count, n = count;
        for (int i = offset; i < endIndex; ) {
            if (Character.isHighSurrogate(a[i++]) && i < endIndex && Character.isLowSurrogate(a[i])) { n--; i++; }
        }
        return n;
    }

    public static int offsetByCodePoints(CharSequence seq, int index, int codePointOffset) {
        int length = seq.length();
        if (index < 0 || index > length) throw new IndexOutOfBoundsException();
        int x = index;
        if (codePointOffset >= 0) {
            int i;
            for (i = 0; x < length && i < codePointOffset; i++) {
                if (Character.isHighSurrogate(seq.charAt(x++)) && x < length && Character.isLowSurrogate(seq.charAt(x))) x++;
            }
            if (i < codePointOffset) throw new IndexOutOfBoundsException();
        } else {
            int i;
            for (i = codePointOffset; x > 0 && i < 0; i++) {
                if (Character.isLowSurrogate(seq.charAt(--x)) && x > 0 && Character.isHighSurrogate(seq.charAt(x - 1))) x--;
            }
            if (i < 0) throw new IndexOutOfBoundsException();
        }
        return x;
    }

    public static int offsetByCodePoints(char[] a, int start, int count, int index, int codePointOffset) {
        if (count > a.length - start || start < 0 || count < 0 || index < start || index > start + count) throw new IndexOutOfBoundsException();
        int x = index;
        if (codePointOffset >= 0) {
            int limit = start + count, i;
            for (i = 0; x < limit && i < codePointOffset; i++) {
                if (Character.isHighSurrogate(a[x++]) && x < limit && Character.isLowSurrogate(a[x])) x++;
            }
            if (i < codePointOffset) throw new IndexOutOfBoundsException();
        } else {
            int i;
            for (i = codePointOffset; x > start && i < 0; i++) {
                if (Character.isLowSurrogate(a[--x]) && x > start && Character.isHighSurrogate(a[x - 1])) x--;
            }
            if (i < 0) throw new IndexOutOfBoundsException();
        }
        return x;
    }

    // ---- predicates over the general category -------------------------------------------------------------------------------------------------------------------
    public static boolean isISOControl(char ch) { return isISOControl((int) ch); }
    public static boolean isISOControl(int codePoint) { return codePoint <= 0x9F && (codePoint >= 0x7F || (codePoint >>> 5 == 0)); }

    public static boolean isDefined(char ch) { return isDefined((int) ch); }
    public static boolean isDefined(int codePoint) { return isValidCodePoint(codePoint) && Character.getType(codePoint) != Character.UNASSIGNED; }

    public static boolean isTitleCase(char ch) { return isTitleCase((int) ch); }
    public static boolean isTitleCase(int codePoint) { return isValidCodePoint(codePoint) && Character.getType(codePoint) == Character.TITLECASE_LETTER; }

    public static boolean isIdentifierIgnorable(char ch) { return isIdentifierIgnorable((int) ch); }
    public static boolean isIdentifierIgnorable(int codePoint) {
        return (codePoint >= 0x0000 && codePoint <= 0x0008) || (codePoint >= 0x000E && codePoint <= 0x001B) || (codePoint >= 0x007F && codePoint <= 0x009F)
            || (isValidCodePoint(codePoint) && Character.getType(codePoint) == Character.FORMAT);
    }

    public static boolean isJavaIdentifierStart(char ch) { return isJavaIdentifierStart((int) ch); }
    public static boolean isJavaIdentifierStart(int codePoint) {
        if (!isValidCodePoint(codePoint)) return false;
        if (Character.isLetter(codePoint)) return true;
        int type = Character.getType(codePoint);
        return type == Character.LETTER_NUMBER || type == Character.CURRENCY_SYMBOL || type == Character.CONNECTOR_PUNCTUATION;
    }

    public static boolean isJavaIdentifierPart(char ch) { return isJavaIdentifierPart((int) ch); }
    public static boolean isJavaIdentifierPart(int codePoint) {
        if (isIdentifierIgnorable(codePoint)) return true;
        if (!isValidCodePoint(codePoint)) return false;
        if (Character.isLetter(codePoint) || Character.isDigit(codePoint)) return true;
        int type = Character.getType(codePoint);
        return type == Character.LETTER_NUMBER || type == Character.CURRENCY_SYMBOL || type == Character.CONNECTOR_PUNCTUATION
            || type == Character.COMBINING_SPACING_MARK || type == Character.NON_SPACING_MARK;
    }

    public static boolean isJavaLetter(char ch) { return isJavaIdentifierStart(ch); }
    public static boolean isJavaLetterOrDigit(char ch) { return isJavaIdentifierPart(ch); }
}
