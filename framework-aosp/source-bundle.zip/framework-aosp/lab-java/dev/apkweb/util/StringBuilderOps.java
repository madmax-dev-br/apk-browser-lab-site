package dev.apkweb.util;

/**
 * Lab-authored java.lang.StringBuilder / StringBuffer methods (android-13.0.0_r1 / JDK 11 semantics) the VM's host builders lack. No static state: helper methods run without class
 * initialisation.
 */
public final class StringBuilderOps {
    private StringBuilderOps() {}

    private static int compare(CharSequence a, CharSequence b) {
        int n = Math.min(a.length(), b.length());
        for (int i = 0; i < n; i++) {
            char x = a.charAt(i), y = b.charAt(i);
            if (x != y) return x - y;
        }
        return a.length() - b.length();
    }

    public static int compareTo(StringBuilder self, StringBuilder another) { return compare(self, another); }
    public static int compareTo(StringBuilder self, Object another) { return compare(self, (StringBuilder) another); }
    public static int compareTo(StringBuffer self, StringBuffer another) { return compare(self, another); }
    public static int compareTo(StringBuffer self, Object another) { return compare(self, (StringBuffer) another); }

    public static StringBuilder append(StringBuilder self, StringBuffer sb) { return self.append(String.valueOf(sb)); }
    public static StringBuffer append(StringBuffer self, StringBuffer sb) { return self.append(String.valueOf(sb)); }

    public static StringBuilder insert(StringBuilder self, int offset, double d) { return self.insert(offset, String.valueOf(d)); }
    public static StringBuilder insert(StringBuilder self, int offset, float f) { return self.insert(offset, String.valueOf(f)); }
    public static StringBuffer insert(StringBuffer self, int offset, double d) { return self.insert(offset, String.valueOf(d)); }
    public static StringBuffer insert(StringBuffer self, int offset, float f) { return self.insert(offset, String.valueOf(f)); }
}
