package dev.apkweb.util;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.*;

/**
 * Lab-authored AtomicIntegerOps: the java.util.concurrent.atomic.AtomicInteger methods (android-13.0.0_r1 / JDK 11 semantics) the VM's host class does not provide natively. The host class has the atomic
 * primitives get/set/compareAndSet; everything here is built from them with the same retry loops as the JDK, so a green-thread switch between the read and the write only costs a retry.
 * The memory-order variants (Plain, Opaque, Acquire, Release, weak*) are all the volatile operation: the VM is single-processor.
 */
public final class AtomicIntegerOps {
    private AtomicIntegerOps() {}
    public static int updateAndGet(AtomicInteger a, IntUnaryOperator f)
    {
        for (;;) {
            int p = a.get();
            int n = f.applyAsInt(p);
            if (a.compareAndSet(p, n)) return n;
        }
    }
    public static int getAndUpdate(AtomicInteger a, IntUnaryOperator f)
    {
        for (;;) {
            int p = a.get();
            int n = f.applyAsInt(p);
            if (a.compareAndSet(p, n)) return p;
        }
    }
    public static int accumulateAndGet(AtomicInteger a, int x, IntBinaryOperator f)
    {
        for (;;) {
            int p = a.get();
            int n = f.applyAsInt(p, x);
            if (a.compareAndSet(p, n)) return n;
        }
    }
    public static int getAndAccumulate(AtomicInteger a, int x, IntBinaryOperator f)
    {
        for (;;) {
            int p = a.get();
            int n = f.applyAsInt(p, x);
            if (a.compareAndSet(p, n)) return p;
        }
    }
    public static int compareAndExchange(AtomicInteger a, int expected, int newValue)
    {
        for (;;) {
            int witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static int compareAndExchangeAcquire(AtomicInteger a, int expected, int newValue)
    {
        for (;;) {
            int witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static int compareAndExchangeRelease(AtomicInteger a, int expected, int newValue)
    {
        for (;;) {
            int witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static int getAcquire(AtomicInteger a)
    {
        return a.get();
    }
    public static int getOpaque(AtomicInteger a)
    {
        return a.get();
    }
    public static int getPlain(AtomicInteger a)
    {
        return a.get();
    }
    public static void setOpaque(AtomicInteger a, int newValue)
    {
        a.set(newValue);
    }
    public static void setPlain(AtomicInteger a, int newValue)
    {
        a.set(newValue);
    }
    public static void setRelease(AtomicInteger a, int newValue)
    {
        a.set(newValue);
    }
    public static boolean weakCompareAndSetAcquire(AtomicInteger a, int expected, int newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static boolean weakCompareAndSetPlain(AtomicInteger a, int expected, int newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static boolean weakCompareAndSetRelease(AtomicInteger a, int expected, int newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static boolean weakCompareAndSetVolatile(AtomicInteger a, int expected, int newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
}
