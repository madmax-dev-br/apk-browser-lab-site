package dev.apkweb.util;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Lab-authored AtomicBooleanOps: the java.util.concurrent.atomic.AtomicBoolean methods (android-13.0.0_r1 / JDK 11 semantics) the VM's host class does not provide natively. The host class has the atomic
 * primitives get/set/compareAndSet; everything here is built from them with the same retry loops as the JDK, so a green-thread switch between the read and the write only costs a retry.
 * The memory-order variants (Plain, Opaque, Acquire, Release, weak*) are all the volatile operation: the VM is single-processor.
 */
public final class AtomicBooleanOps {
    private AtomicBooleanOps() {}
    public static boolean compareAndExchange(AtomicBoolean a, boolean expected, boolean newValue)
    {
        for (;;) {
            boolean witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }

    public static boolean compareAndExchangeAcquire(AtomicBoolean a, boolean expected, boolean newValue)
    {
        for (;;) {
            boolean witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }

    public static boolean compareAndExchangeRelease(AtomicBoolean a, boolean expected, boolean newValue)
    {
        for (;;) {
            boolean witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }

    public static boolean getAcquire(AtomicBoolean a)
    {
        return a.get();
    }

    public static boolean getOpaque(AtomicBoolean a)
    {
        return a.get();
    }

    public static boolean getPlain(AtomicBoolean a)
    {
        return a.get();
    }

    public static void setOpaque(AtomicBoolean a, boolean newValue)
    {
        a.set(newValue);
    }

    public static void setPlain(AtomicBoolean a, boolean newValue)
    {
        a.set(newValue);
    }

    public static void setRelease(AtomicBoolean a, boolean newValue)
    {
        a.set(newValue);
    }

    public static boolean weakCompareAndSetAcquire(AtomicBoolean a, boolean expected, boolean newValue)
    {
        return a.compareAndSet(expected, newValue);
    }

    public static boolean weakCompareAndSetPlain(AtomicBoolean a, boolean expected, boolean newValue)
    {
        return a.compareAndSet(expected, newValue);
    }

    public static boolean weakCompareAndSetRelease(AtomicBoolean a, boolean expected, boolean newValue)
    {
        return a.compareAndSet(expected, newValue);
    }

    public static boolean weakCompareAndSetVolatile(AtomicBoolean a, boolean expected, boolean newValue)
    {
        return a.compareAndSet(expected, newValue);
    }

}
