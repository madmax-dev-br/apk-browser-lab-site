package dev.apkweb.util;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

/**
 * Lab-authored streams of java.util.Random and the bounded draws of java.util.concurrent.ThreadLocalRandom (android-13.0.0_r1 / JDK 11 algorithms). The VM's host Random is the
 * bit-exact LCG; the streams here are the sequential, unsized streams of its draws (the JDK's spliterators draw the same values in the same order sequentially). No static
 * state: helper methods run without class initialisation.
 */
public final class RandomOps {
    private RandomOps() {}

    private static IntStream ints(Random r, long size, int origin, int bound, boolean bounded) {
        if (size < 0L) throw new IllegalArgumentException("size must be non-negative");
        if (bounded && origin >= bound) throw new IllegalArgumentException("bound must be greater than origin");
        IntStream s = bounded ? IntStream.generate(() -> nextInt(r, origin, bound)) : IntStream.generate(() -> r.nextInt());
        return size == Long.MAX_VALUE ? s : s.limit(size);
    }

    private static LongStream longs(Random r, long size, long origin, long bound, boolean bounded) {
        if (size < 0L) throw new IllegalArgumentException("size must be non-negative");
        if (bounded && origin >= bound) throw new IllegalArgumentException("bound must be greater than origin");
        LongStream s = bounded ? LongStream.generate(() -> nextLong(r, origin, bound)) : LongStream.generate(() -> r.nextLong());
        return size == Long.MAX_VALUE ? s : s.limit(size);
    }

    private static DoubleStream doubles(Random r, long size, double origin, double bound, boolean bounded) {
        if (size < 0L) throw new IllegalArgumentException("size must be non-negative");
        if (bounded && !(origin < bound && (bound - origin) < Double.POSITIVE_INFINITY)) throw new IllegalArgumentException("bound must be greater than origin");
        DoubleStream s = bounded ? DoubleStream.generate(() -> nextDouble(r, origin, bound)) : DoubleStream.generate(() -> r.nextDouble());
        return size == Long.MAX_VALUE ? s : s.limit(size);
    }

    /** Random.internalNextInt */
    private static int nextInt(Random r, int origin, int bound) {
        if (origin < bound) {
            int n = bound - origin;
            if (n > 0) return r.nextInt(n) + origin;
            int v;
            do { v = r.nextInt(); } while (v < origin || v >= bound);
            return v;
        }
        return r.nextInt();
    }

    /** Random.internalNextLong */
    private static long nextLong(Random r, long origin, long bound) {
        long v = r.nextLong();
        if (origin < bound) {
            long n = bound - origin, m = n - 1;
            if ((n & m) == 0L) v = (v & m) + origin;
            else if (n > 0L) {
                for (long u = v >>> 1; u + m - (v = u % n) < 0L; u = r.nextLong() >>> 1) { }
                v += origin;
            } else {
                while (v < origin || v >= bound) v = r.nextLong();
            }
        }
        return v;
    }

    /** Random.internalNextDouble */
    private static double nextDouble(Random r, double origin, double bound) {
        double v = r.nextDouble();
        if (origin < bound) {
            v = v * (bound - origin) + origin;
            if (v >= bound) v = Math.nextDown(bound);
        }
        return v;
    }

    public static IntStream ints(Random r) { return ints(r, Long.MAX_VALUE, 0, 0, false); }
    public static IntStream ints(Random r, long streamSize) { return ints(r, streamSize, 0, 0, false); }
    public static IntStream ints(Random r, int randomNumberOrigin, int randomNumberBound) { return ints(r, Long.MAX_VALUE, randomNumberOrigin, randomNumberBound, true); }
    public static IntStream ints(Random r, long streamSize, int randomNumberOrigin, int randomNumberBound) { return ints(r, streamSize, randomNumberOrigin, randomNumberBound, true); }
    public static LongStream longs(Random r) { return longs(r, Long.MAX_VALUE, 0L, 0L, false); }
    public static LongStream longs(Random r, long streamSize) { return longs(r, streamSize, 0L, 0L, false); }
    public static LongStream longs(Random r, long randomNumberOrigin, long randomNumberBound) { return longs(r, Long.MAX_VALUE, randomNumberOrigin, randomNumberBound, true); }
    public static LongStream longs(Random r, long streamSize, long randomNumberOrigin, long randomNumberBound) { return longs(r, streamSize, randomNumberOrigin, randomNumberBound, true); }
    public static DoubleStream doubles(Random r) { return doubles(r, Long.MAX_VALUE, 0.0, 0.0, false); }
    public static DoubleStream doubles(Random r, long streamSize) { return doubles(r, streamSize, 0.0, 0.0, false); }
    public static DoubleStream doubles(Random r, double randomNumberOrigin, double randomNumberBound) { return doubles(r, Long.MAX_VALUE, randomNumberOrigin, randomNumberBound, true); }
    public static DoubleStream doubles(Random r, long streamSize, double randomNumberOrigin, double randomNumberBound) { return doubles(r, streamSize, randomNumberOrigin, randomNumberBound, true); }

    public static IntStream ints(ThreadLocalRandom r) { return ints(r, Long.MAX_VALUE, 0, 0, false); }
    public static IntStream ints(ThreadLocalRandom r, long streamSize) { return ints(r, streamSize, 0, 0, false); }
    public static IntStream ints(ThreadLocalRandom r, int randomNumberOrigin, int randomNumberBound) { return ints(r, Long.MAX_VALUE, randomNumberOrigin, randomNumberBound, true); }
    public static IntStream ints(ThreadLocalRandom r, long streamSize, int randomNumberOrigin, int randomNumberBound) { return ints(r, streamSize, randomNumberOrigin, randomNumberBound, true); }
    public static LongStream longs(ThreadLocalRandom r) { return longs(r, Long.MAX_VALUE, 0L, 0L, false); }
    public static LongStream longs(ThreadLocalRandom r, long streamSize) { return longs(r, streamSize, 0L, 0L, false); }
    public static LongStream longs(ThreadLocalRandom r, long randomNumberOrigin, long randomNumberBound) { return longs(r, Long.MAX_VALUE, randomNumberOrigin, randomNumberBound, true); }
    public static LongStream longs(ThreadLocalRandom r, long streamSize, long randomNumberOrigin, long randomNumberBound) { return longs(r, streamSize, randomNumberOrigin, randomNumberBound, true); }
    public static DoubleStream doubles(ThreadLocalRandom r) { return doubles(r, Long.MAX_VALUE, 0.0, 0.0, false); }
    public static DoubleStream doubles(ThreadLocalRandom r, long streamSize) { return doubles(r, streamSize, 0.0, 0.0, false); }
    public static DoubleStream doubles(ThreadLocalRandom r, double randomNumberOrigin, double randomNumberBound) { return doubles(r, Long.MAX_VALUE, randomNumberOrigin, randomNumberBound, true); }
    public static DoubleStream doubles(ThreadLocalRandom r, long streamSize, double randomNumberOrigin, double randomNumberBound) { return doubles(r, streamSize, randomNumberOrigin, randomNumberBound, true); }

    // ---- ThreadLocalRandom bounded draws -------------------------------------------------------------------------------------------------------------------------
    public static long nextLong(ThreadLocalRandom r, long bound) {
        if (bound <= 0) throw new IllegalArgumentException("bound must be positive");
        long m = bound - 1;
        long v = r.nextLong();
        if ((bound & m) == 0L) v &= m;
        else {
            for (long u = v >>> 1; u + m - (v = u % bound) < 0L; u = r.nextLong() >>> 1) { }
        }
        return v;
    }

    public static long nextLong(ThreadLocalRandom r, long origin, long bound) {
        if (origin >= bound) throw new IllegalArgumentException("bound must be greater than origin");
        return nextLong((Random) r, origin, bound);
    }

    public static double nextDouble(ThreadLocalRandom r, double bound) {
        if (!(bound > 0.0)) throw new IllegalArgumentException("bound must be positive");
        double result = r.nextDouble() * bound;
        return (result < bound) ? result : Double.longBitsToDouble(Double.doubleToLongBits(bound) - 1);
    }

    public static double nextDouble(ThreadLocalRandom r, double origin, double bound) {
        if (!(origin < bound)) throw new IllegalArgumentException("bound must be greater than origin");
        return nextDouble((Random) r, origin, bound);
    }
}
