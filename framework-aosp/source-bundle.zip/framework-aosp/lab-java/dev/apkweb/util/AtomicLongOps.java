package dev.apkweb.util;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.*;

/**
 * Lab-authored AtomicLongOps: the java.util.concurrent.atomic.AtomicLong methods (android-13.0.0_r1 / JDK 11 semantics) the VM's host class does not provide natively. The host class has the atomic
 * primitives get/set/compareAndSet; everything here is built from them with the same retry loops as the JDK, so a green-thread switch between the read and the write only costs a retry.
 * The memory-order variants (Plain, Opaque, Acquire, Release, weak*) are all the volatile operation: the VM is single-processor.
 */
public final class AtomicLongOps {
    private AtomicLongOps() {}
    public static long updateAndGet(AtomicLong a, LongUnaryOperator f)
    {
        for (;;) {
            long p = a.get();
            long n = f.applyAsLong(p);
            if (a.compareAndSet(p, n)) return n;
        }
    }
    public static long getAndUpdate(AtomicLong a, LongUnaryOperator f)
    {
        for (;;) {
            long p = a.get();
            long n = f.applyAsLong(p);
            if (a.compareAndSet(p, n)) return p;
        }
    }
    public static long accumulateAndGet(AtomicLong a, long x, LongBinaryOperator f)
    {
        for (;;) {
            long p = a.get();
            long n = f.applyAsLong(p, x);
            if (a.compareAndSet(p, n)) return n;
        }
    }
    public static long getAndAccumulate(AtomicLong a, long x, LongBinaryOperator f)
    {
        for (;;) {
            long p = a.get();
            long n = f.applyAsLong(p, x);
            if (a.compareAndSet(p, n)) return p;
        }
    }
    public static long compareAndExchange(AtomicLong a, long expected, long newValue)
    {
        for (;;) {
            long witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static long compareAndExchangeAcquire(AtomicLong a, long expected, long newValue)
    {
        for (;;) {
            long witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static long compareAndExchangeRelease(AtomicLong a, long expected, long newValue)
    {
        for (;;) {
            long witness = a.get();
            if (witness != expected) return witness;
            if (a.compareAndSet(expected, newValue)) return expected;
        }
    }
    public static long getAcquire(AtomicLong a)
    {
        return a.get();
    }
    public static long getOpaque(AtomicLong a)
    {
        return a.get();
    }
    public static long getPlain(AtomicLong a)
    {
        return a.get();
    }
    public static void setOpaque(AtomicLong a, long newValue)
    {
        a.set(newValue);
    }
    public static void setPlain(AtomicLong a, long newValue)
    {
        a.set(newValue);
    }
    public static void setRelease(AtomicLong a, long newValue)
    {
        a.set(newValue);
    }
    public static boolean weakCompareAndSetAcquire(AtomicLong a, long expected, long newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static boolean weakCompareAndSetPlain(AtomicLong a, long expected, long newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static boolean weakCompareAndSetRelease(AtomicLong a, long expected, long newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
    public static boolean weakCompareAndSetVolatile(AtomicLong a, long expected, long newValue)
    {
        return a.compareAndSet(expected, newValue);
    }
}
