package dev.apkweb.util;

/** Lab-authored java.lang.Boolean statics. */
public final class BooleanOps {
    private BooleanOps() {}

    public static int compare(boolean x, boolean y) { return (x == y) ? 0 : (x ? 1 : -1); }
    public static boolean logicalAnd(boolean a, boolean b) { return a && b; }
    public static boolean logicalOr(boolean a, boolean b) { return a || b; }
    public static boolean logicalXor(boolean a, boolean b) { return a ^ b; }
    public static String toString(boolean b) { return b ? "true" : "false"; }
}
