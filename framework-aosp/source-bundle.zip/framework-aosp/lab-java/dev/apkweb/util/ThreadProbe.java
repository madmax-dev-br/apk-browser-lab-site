package dev.apkweb.util;

/** Thread.threadLocalRandomProbe, the per-thread contention hash java.util.concurrent.atomic.Striped64 keeps in a private Thread field (reached by VarHandle in the JDK). Same default (0, "not initialized") and the Striped64 xorshift advance. */
public final class ThreadProbe {
    private static final ThreadLocal<int[]> PROBE = new ThreadLocal<int[]>() { @Override protected int[] initialValue() { return new int[1]; } };
    private ThreadProbe() {}
    public static int get() { return PROBE.get()[0]; }
    public static void set(int probe) { PROBE.get()[0] = probe; }
}
