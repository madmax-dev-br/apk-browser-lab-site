package dev.apkweb.util;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Thread.threadLocalRandomProbe, the per-thread contention hash java.util.concurrent.atomic.Striped64 and ConcurrentHashMap's counter cells keep in a private Thread field (reached by
 * VarHandle / Unsafe through the package-private ThreadLocalRandom.getProbe/localInit/advanceProbe in libcore). Same default (0, "not initialized"), the same Weyl-sequence
 * initialization as ThreadLocalRandom.localInit (probeGenerator += 0x9e3779b9, skipping 0) and the same xorshift advance as ThreadLocalRandom.advanceProbe.
 */
public final class ThreadProbe {
    private static final ThreadLocal<int[]> PROBE = new ThreadLocal<int[]>() { @Override protected int[] initialValue() { return new int[1]; } };
    private static final int PROBE_INCREMENT = 0x9e3779b9;
    private static final AtomicInteger PROBE_GENERATOR = new AtomicInteger();
    private ThreadProbe() {}
    public static int get() { return PROBE.get()[0]; }
    public static void set(int probe) { PROBE.get()[0] = probe; }
    /** ThreadLocalRandom.localInit, probe half (the seed half belongs to ThreadLocalRandom's own generator). */
    public static void localInit() {
        int p = PROBE_GENERATOR.addAndGet(PROBE_INCREMENT);
        set(p == 0 ? 1 : p);
    }
    /** ThreadLocalRandom.advanceProbe. */
    public static int advance(int probe) {
        probe ^= probe << 13;
        probe ^= probe >>> 17;
        probe ^= probe << 5;
        set(probe);
        return probe;
    }
}
