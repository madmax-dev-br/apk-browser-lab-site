package dev.apkweb.util;

import java.math.BigInteger;

/** Lab-authored java.lang.Long statics, see BoxOps. */
public final class LongOps {
    private LongOps() {}

    public static Long valueOf(String s) throws NumberFormatException { return Long.valueOf(Long.parseLong(s, 10)); }
    public static Long valueOf(String s, int radix) throws NumberFormatException { return Long.valueOf(Long.parseLong(s, radix)); }

    public static long parseLong(CharSequence s, int beginIndex, int endIndex, int radix) throws NumberFormatException {
        return Long.parseLong(BoxOps.slice(s, beginIndex, endIndex), radix);
    }

    public static long parseUnsignedLong(String s) throws NumberFormatException { return parseUnsignedLong(s, 10); }

    public static long parseUnsignedLong(String s, int radix) throws NumberFormatException {
        if (s == null) throw new NumberFormatException("null");
        int len = s.length();
        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar == '-') throw new NumberFormatException(String.format("Illegal leading minus sign on unsigned string %s.", s));
            if (len <= 12 || (radix == 10 && len <= 18)) return Long.parseLong(s, radix);
            BigInteger value = new BigInteger(s, radix);
            if (value.bitLength() > 64) throw new NumberFormatException(String.format("String value %s exceeds range of unsigned long.", s));
            return value.longValue();
        }
        throw new NumberFormatException("For input string: \"" + s + "\"" + (radix == 10 ? "" : " under radix " + radix));
    }

    public static long parseUnsignedLong(CharSequence s, int beginIndex, int endIndex, int radix) throws NumberFormatException {
        return parseUnsignedLong(BoxOps.slice(s, beginIndex, endIndex), radix);
    }
}
