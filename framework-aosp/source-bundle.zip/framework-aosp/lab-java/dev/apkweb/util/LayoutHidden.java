package dev.apkweb.util;

import android.text.Layout;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Layout.getLineExtra(int) -- the extra line spacing of a line, AOSP's @hide Layout member BulletSpan reads. Hidden API is not on the compile classpath, so
 * scripts/prepare-javatime-sources.py rewrites that call site to this helper, which calls the framework's own Layout method by reflection.
 */
public final class LayoutHidden {
    private LayoutHidden() {}

    public static int lineExtra(Layout layout, int line) {
        try {
            Method method = Layout.class.getMethod("getLineExtra", int.class);
            return (Integer) method.invoke(layout, line);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            throw new IllegalStateException(cause);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Layout.getLineExtra is not available", e);
        }
    }
}
