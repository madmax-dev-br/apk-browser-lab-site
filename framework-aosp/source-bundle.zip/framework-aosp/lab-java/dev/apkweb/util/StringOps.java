package dev.apkweb.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Lab-authored java.lang.String methods (android-13.0.0_r1 / JDK 11 semantics) the VM's host String does not provide natively. The receiver is the String; the VM routes the call
 * here (LAB_HELPERS in src/apk-runtime.js). Only methods on the String's own public API are used.
 */
public final class StringOps {
    private StringOps() {}

    public static int codePointBefore(String s, int index) {
        int i = index - 1;
        if (i < 0 || i >= s.length()) throw new StringIndexOutOfBoundsException("index " + index + ", length " + s.length());
        char c2 = s.charAt(i);
        if (Character.isLowSurrogate(c2) && i > 0) {
            char c1 = s.charAt(i - 1);
            if (Character.isHighSurrogate(c1)) return Character.toCodePoint(c1, c2);
        }
        return c2;
    }

    public static int codePointCount(String s, int beginIndex, int endIndex) {
        if (beginIndex < 0 || beginIndex > endIndex || endIndex > s.length()) throw new IndexOutOfBoundsException();
        int n = endIndex - beginIndex;
        for (int i = beginIndex; i < endIndex - 1; ) {
            if (Character.isHighSurrogate(s.charAt(i++)) && Character.isLowSurrogate(s.charAt(i))) { n--; i++; }
        }
        return n;
    }

    public static int offsetByCodePoints(String s, int index, int codePointOffset) {
        if (index < 0 || index > s.length()) throw new IndexOutOfBoundsException();
        int x = index;
        if (codePointOffset >= 0) {
            int i;
            for (i = 0; x < s.length() && i < codePointOffset; i++) {
                if (Character.isHighSurrogate(s.charAt(x++)) && x < s.length() && Character.isLowSurrogate(s.charAt(x))) x++;
            }
            if (i < codePointOffset) throw new IndexOutOfBoundsException();
        } else {
            int i;
            for (i = codePointOffset; x > 0 && i < 0; i++) {
                if (Character.isLowSurrogate(s.charAt(--x)) && x > 0 && Character.isHighSurrogate(s.charAt(x - 1))) x--;
            }
            if (i < 0) throw new IndexOutOfBoundsException();
        }
        return x;
    }

    public static boolean contentEquals(String s, StringBuffer sb) { return s.contentEquals((CharSequence) sb); }

    public static void getBytes(String s, int srcBegin, int srcEnd, byte[] dst, int dstBegin) {
        if (srcBegin < 0 || srcBegin > srcEnd || srcEnd > s.length()) throw new StringIndexOutOfBoundsException("begin " + srcBegin + ", end " + srcEnd + ", length " + s.length());
        if (dst == null) throw new NullPointerException("dst == null");
        if (dstBegin < 0 || dstBegin + (srcEnd - srcBegin) > dst.length) throw new ArrayIndexOutOfBoundsException("dstBegin " + dstBegin);
        for (int i = srcBegin; i < srcEnd; i++) dst[dstBegin++] = (byte) s.charAt(i);   // the low byte of each char, as the deprecated method defines
    }

    public static String join(CharSequence delimiter, CharSequence... elements) {
        if (delimiter == null || elements == null) throw new NullPointerException();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < elements.length; i++) { if (i > 0) sb.append(delimiter); sb.append(elements[i]); }
        return sb.toString();
    }

    public static String join(CharSequence delimiter, Iterable<? extends CharSequence> elements) {
        if (delimiter == null || elements == null) throw new NullPointerException();
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (CharSequence cs : elements) { if (!first) sb.append(delimiter); first = false; sb.append(cs); }
        return sb.toString();
    }

    public static String copyValueOf(char[] data, int offset, int count) { return new String(data, offset, count); }
    public static String valueOf(char[] data) { return new String(data); }
    public static String valueOf(char[] data, int offset, int count) { return new String(data, offset, count); }

    private static boolean isStripWhitespace(int cp) { return Character.isWhitespace(cp); }

    public static String strip(String s) { return stripTrailing(stripLeading(s)); }

    public static String stripLeading(String s) {
        int i = 0, n = s.length();
        while (i < n) { int cp = s.codePointAt(i); if (!isStripWhitespace(cp)) break; i += Character.charCount(cp); }
        return i == 0 ? s : s.substring(i);
    }

    public static String stripTrailing(String s) {
        int end = s.length();
        while (end > 0) { int cp = s.codePointBefore(end); if (!isStripWhitespace(cp)) break; end -= Character.charCount(cp); }
        return end == s.length() ? s : s.substring(0, end);
    }

    public static Stream<String> lines(String s) {
        List<String> lines = new ArrayList<String>();
        int start = 0, n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c == '\n' || c == '\r') {
                lines.add(s.substring(start, i));
                if (c == '\r' && i + 1 < n && s.charAt(i + 1) == '\n') i++;
                start = i + 1;
            }
        }
        if (start < n) lines.add(s.substring(start));
        return lines.stream();
    }
}
