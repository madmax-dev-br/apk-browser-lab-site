package dev.apkweb.util;

import java.math.BigDecimal;

/**
 * (No static state: the VM runs helper methods without class initialisation.)
 * Lab-authored java.lang.Math statics (android-13.0.0_r1 / JDK 11 algorithms) the VM's host Math does not provide natively. sinh and tanh are served by the host (see
 * src/apk-runtime.js); the rest are exact integer or IEEE bit manipulations, and fma is computed exactly with BigDecimal and rounded once, as the JDK's fallback does.
 */
public final class MathOps {
    private MathOps() {}

    public static long floorDiv(long x, int y) { return Math.floorDiv(x, (long) y); }
    public static int floorMod(long x, int y) { return (int) Math.floorMod(x, (long) y); }
    public static long multiplyExact(long x, int y) { return Math.multiplyExact(x, (long) y); }
    public static long multiplyFull(int x, int y) { return (long) x * (long) y; }

    public static long multiplyHigh(long x, long y) {
        if (x < 0 || y < 0) {
            long x1 = x >> 32, x2 = x & 0xFFFFFFFFL, y1 = y >> 32, y2 = y & 0xFFFFFFFFL;
            long z2 = x2 * y2;
            long t = x1 * y2 + (z2 >>> 32);
            long z1 = t & 0xFFFFFFFFL;
            long z0 = t >> 32;
            z1 += x2 * y1;
            return x1 * y1 + z0 + (z1 >> 32);
        }
        long x1 = x >>> 32, y1 = y >>> 32, x2 = x & 0xFFFFFFFFL, y2 = y & 0xFFFFFFFFL;
        long a = x1 * y1, b = x2 * y2, c = (x1 + x2) * (y1 + y2), k = c - a - b;
        return (((b >>> 32) + k) >>> 32) + a;
    }

    public static int getExponent(double d) { return (int) (((Double.doubleToRawLongBits(d) & 0x7FF0000000000000L) >> 52) - 1023); }
    public static int getExponent(float f) { return ((Float.floatToRawIntBits(f) & 0x7f800000) >> 23) - 127; }

    public static double nextUp(double d) {
        if (Double.isNaN(d) || d == Double.POSITIVE_INFINITY) return d;
        d += 0.0d;
        return Double.longBitsToDouble(Double.doubleToRawLongBits(d) + ((d >= 0.0d) ? +1L : -1L));
    }

    public static float nextUp(float f) {
        if (Float.isNaN(f) || f == Float.POSITIVE_INFINITY) return f;
        f += 0.0f;
        return Float.intBitsToFloat(Float.floatToRawIntBits(f) + ((f >= 0.0f) ? +1 : -1));
    }

    public static double nextDown(double d) {
        if (Double.isNaN(d) || d == Double.NEGATIVE_INFINITY) return d;
        if (d == 0.0) return -Double.MIN_VALUE;
        return Double.longBitsToDouble(Double.doubleToRawLongBits(d) + ((d > 0.0d) ? -1L : +1L));
    }

    public static float nextDown(float f) {
        if (Float.isNaN(f) || f == Float.NEGATIVE_INFINITY) return f;
        if (f == 0.0f) return -Float.MIN_VALUE;
        return Float.intBitsToFloat(Float.floatToRawIntBits(f) + ((f > 0.0f) ? -1 : +1));
    }

    public static float nextAfter(float start, double direction) {
        if (Float.isNaN(start) || Double.isNaN(direction)) return start + (float) direction;
        if (start == direction) return (float) direction;
        int transducer = Float.floatToRawIntBits(start + 0.0f);
        if (direction > start) transducer = transducer + (transducer >= 0 ? 1 : -1);
        else if (transducer > 0) --transducer;
        else if (transducer < 0) ++transducer;
        else transducer = Integer.MIN_VALUE | 1;
        return Float.intBitsToFloat(transducer);
    }

    private static double powerOfTwoD(int n) { return Double.longBitsToDouble((((long) n + (long) 1023) << 52) & 0x7FF0000000000000L); }
    private static float powerOfTwoF(int n) { return Float.intBitsToFloat(((n + 127) << 23) & 0x7F800000); }

    public static double scalb(double d, int scaleFactor) {
        final int maxScale = 1023 + 1023 + 52 + 1;
        int scaleIncrement;
        double expDelta;
        if (scaleFactor < 0) { scaleFactor = Math.max(scaleFactor, -maxScale); scaleIncrement = -512; expDelta = powerOfTwoD(-512); }
        else { scaleFactor = Math.min(scaleFactor, maxScale); scaleIncrement = 512; expDelta = powerOfTwoD(512); }
        int t = (scaleFactor >> 9 - 1) >>> 32 - 9;
        int expAdjust = ((scaleFactor + t) & (512 - 1)) - t;
        d *= powerOfTwoD(expAdjust);
        scaleFactor -= expAdjust;
        while (scaleFactor != 0) { d *= expDelta; scaleFactor -= scaleIncrement; }
        return d;
    }

    public static float scalb(float f, int scaleFactor) {
        final int maxScale = 127 + 126 + 24 + 1;
        scaleFactor = Math.max(Math.min(scaleFactor, maxScale), -maxScale);
        return (float) ((double) f * powerOfTwoD(scaleFactor));
    }

    public static float ulp(float f) {
        int exp = getExponent(f);
        switch (exp) {
            case 127 + 1: return Math.abs(f);
            case -126 - 1: return Float.MIN_VALUE;
            default:
                exp = exp - (24 - 1);
                if (exp >= -126) return powerOfTwoF(exp);
                return Float.intBitsToFloat(1 << (exp - (-126 - (24 - 1))));
        }
    }

    public static double fma(double a, double b, double c) {
        if (Double.isNaN(a) || Double.isNaN(b) || Double.isNaN(c)) return Double.NaN;
        boolean infiniteA = Double.isInfinite(a), infiniteB = Double.isInfinite(b), infiniteC = Double.isInfinite(c);
        if (infiniteA || infiniteB || infiniteC) {
            if (infiniteA && b == 0.0 || infiniteB && a == 0.0) return Double.NaN;
            double product = a * b;
            if (Double.isInfinite(product) && !infiniteA && !infiniteB) return c;
            return product + c;
        }
        BigDecimal product = new BigDecimal(a).multiply(new BigDecimal(b));
        if (c == 0.0) {
            if (a == 0.0 || b == 0.0) return a * b + c;
            return product.doubleValue();
        }
        return product.add(new BigDecimal(c)).doubleValue();
    }

    public static float fma(float a, float b, float c) {
        if (Float.isFinite(a) && Float.isFinite(b) && Float.isFinite(c)) {
            if (a == 0.0 || b == 0.0) return a * b + c;
            BigDecimal product = new BigDecimal((double) a).multiply(new BigDecimal((double) b));
            if (c == 0.0f) return product.floatValue();
            return product.add(new BigDecimal(c)).floatValue();
        }
        return (float) fma((double) a, (double) b, (double) c);
    }
}
