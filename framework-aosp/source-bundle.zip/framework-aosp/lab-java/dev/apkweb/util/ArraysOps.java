package dev.apkweb.util;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.*;

/**
 * Lab-authored java.util.Arrays methods (android-13.0.0_r1 / JDK 11 semantics, static): the comparison family (compare, compareUnsigned, mismatch, equals over ranges, deepEquals,
 * deepToString), the binarySearch overloads over ranges / comparators, setAll / parallelSetAll, parallelPrefix and parallelSort. The VM's host Arrays serves the rest. The
 * parallel operations run sequentially: parallelism is permitted by the contract, never required.
 */
public final class ArraysOps {
    private ArraysOps() {}

    private static void rangeCheck(int arrayLength, int fromIndex, int toIndex) {
        if (fromIndex > toIndex) throw new IllegalArgumentException("fromIndex(" + fromIndex + ") > toIndex(" + toIndex + ")");
        if (fromIndex < 0) throw new ArrayIndexOutOfBoundsException(fromIndex);
        if (toIndex > arrayLength) throw new ArrayIndexOutOfBoundsException(toIndex);
    }


    private static int compareElements(boolean x, boolean y) { return (x == y) ? 0 : (x ? 1 : -1); }

    public static int mismatch(boolean[] a, boolean[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(boolean[] a, int aFromIndex, int aToIndex, boolean[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(boolean[] a, int aFrom, boolean[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (a[aFrom + i] != b[bFrom + i]) return i;
        return -1;
    }
    public static int compare(boolean[] a, boolean[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(boolean[] a, int aFromIndex, int aToIndex, boolean[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(boolean[] a, int aFromIndex, int aToIndex, boolean[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareElements(byte x, byte y) { return x - y; }

    public static int mismatch(byte[] a, byte[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(byte[] a, int aFromIndex, int aToIndex, byte[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(byte[] a, int aFrom, byte[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (a[aFrom + i] != b[bFrom + i]) return i;
        return -1;
    }
    public static int compare(byte[] a, byte[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(byte[] a, int aFromIndex, int aToIndex, byte[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(byte[] a, int aFromIndex, int aToIndex, byte[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareElements(char x, char y) { return x - y; }

    public static int mismatch(char[] a, char[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(char[] a, int aFromIndex, int aToIndex, char[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(char[] a, int aFrom, char[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (a[aFrom + i] != b[bFrom + i]) return i;
        return -1;
    }
    public static int compare(char[] a, char[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(char[] a, int aFromIndex, int aToIndex, char[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(char[] a, int aFromIndex, int aToIndex, char[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareElements(short x, short y) { return x - y; }

    public static int mismatch(short[] a, short[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(short[] a, int aFromIndex, int aToIndex, short[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(short[] a, int aFrom, short[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (a[aFrom + i] != b[bFrom + i]) return i;
        return -1;
    }
    public static int compare(short[] a, short[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(short[] a, int aFromIndex, int aToIndex, short[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(short[] a, int aFromIndex, int aToIndex, short[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareElements(int x, int y) { return (x < y) ? -1 : ((x == y) ? 0 : 1); }

    public static int mismatch(int[] a, int[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(int[] a, int aFromIndex, int aToIndex, int[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(int[] a, int aFrom, int[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (a[aFrom + i] != b[bFrom + i]) return i;
        return -1;
    }
    public static int compare(int[] a, int[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(int[] a, int aFromIndex, int aToIndex, int[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(int[] a, int aFromIndex, int aToIndex, int[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareElements(long x, long y) { return (x < y) ? -1 : ((x == y) ? 0 : 1); }

    public static int mismatch(long[] a, long[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(long[] a, int aFromIndex, int aToIndex, long[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(long[] a, int aFrom, long[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (a[aFrom + i] != b[bFrom + i]) return i;
        return -1;
    }
    public static int compare(long[] a, long[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(long[] a, int aFromIndex, int aToIndex, long[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(long[] a, int aFromIndex, int aToIndex, long[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareElements(float x, float y) { return Float.compare(x, y); }

    public static int mismatch(float[] a, float[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(float[] a, int aFromIndex, int aToIndex, float[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(float[] a, int aFrom, float[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (Float.floatToIntBits(a[aFrom + i]) != Float.floatToIntBits(b[bFrom + i])) return i;
        return -1;
    }
    public static int compare(float[] a, float[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(float[] a, int aFromIndex, int aToIndex, float[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(float[] a, int aFromIndex, int aToIndex, float[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareElements(double x, double y) { return Double.compare(x, y); }

    public static int mismatch(double[] a, double[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchRange(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(double[] a, int aFromIndex, int aToIndex, double[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchRange(double[] a, int aFrom, double[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (Double.doubleToLongBits(a[aFrom + i]) != Double.doubleToLongBits(b[bFrom + i])) return i;
        return -1;
    }
    public static int compare(double[] a, double[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compare(double[] a, int aFromIndex, int aToIndex, double[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }
    public static boolean equals(double[] a, int aFromIndex, int aToIndex, double[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        if (aLength != bLength) return false;
        return mismatchRange(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }


    private static int compareUnsignedElements(byte x, byte y) { return (x & 0xff) - (y & 0xff); }
    public static int compareUnsigned(byte[] a, byte[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareUnsignedElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compareUnsigned(byte[] a, int aFromIndex, int aToIndex, byte[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareUnsignedElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }


    private static int compareUnsignedElements(short x, short y) { return (x & 0xffff) - (y & 0xffff); }
    public static int compareUnsigned(short[] a, short[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareUnsignedElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compareUnsigned(short[] a, int aFromIndex, int aToIndex, short[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareUnsignedElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }


    private static int compareUnsignedElements(int x, int y) { return (x + Integer.MIN_VALUE < y + Integer.MIN_VALUE) ? -1 : ((x == y) ? 0 : 1); }
    public static int compareUnsigned(int[] a, int[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareUnsignedElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compareUnsigned(int[] a, int aFromIndex, int aToIndex, int[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareUnsignedElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }


    private static int compareUnsignedElements(long x, long y) { return (x + Long.MIN_VALUE < y + Long.MIN_VALUE) ? -1 : ((x == y) ? 0 : 1); }
    public static int compareUnsigned(long[] a, long[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int i = mismatchRange(a, 0, b, 0, Math.min(a.length, b.length));
        if (i >= 0) return compareUnsignedElements(a[i], b[i]);
        return a.length - b.length;
    }
    public static int compareUnsigned(long[] a, int aFromIndex, int aToIndex, long[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex;
        int i = mismatchRange(a, aFromIndex, b, bFromIndex, Math.min(aLength, bLength));
        if (i >= 0) return compareUnsignedElements(a[aFromIndex + i], b[bFromIndex + i]);
        return aLength - bLength;
    }


    public static int mismatch(Object[] a, Object[] b) {
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchObjects(a, 0, b, 0, length);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static int mismatch(Object[] a, int aFromIndex, int aToIndex, Object[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchObjects(a, aFromIndex, b, bFromIndex, length);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static int mismatchObjects(Object[] a, int aFrom, Object[] b, int bFrom, int length) {
        for (int i = 0; i < length; i++) if (!Objects.equals(a[aFrom + i], b[bFrom + i])) return i;
        return -1;
    }
    public static <T> int mismatch(T[] a, T[] b, Comparator<? super T> cmp) {
        Objects.requireNonNull(cmp);
        int length = Math.min(a.length, b.length);
        if (a == b) return -1;
        int i = mismatchComparator(a, 0, b, 0, length, cmp);
        return (i < 0 && a.length != b.length) ? length : i;
    }
    public static <T> int mismatch(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex, Comparator<? super T> cmp) {
        Objects.requireNonNull(cmp);
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        int i = mismatchComparator(a, aFromIndex, b, bFromIndex, length, cmp);
        return (i < 0 && aLength != bLength) ? length : i;
    }
    private static <T> int mismatchComparator(T[] a, int aFrom, T[] b, int bFrom, int length, Comparator<? super T> cmp) {
        for (int i = 0; i < length; i++) {
            T oa = a[aFrom + i], ob = b[bFrom + i];
            if (oa != ob && (oa == null || ob == null || cmp.compare(oa, ob) != 0)) return i;
        }
        return -1;
    }
    public static boolean equals(Object[] a, int aFromIndex, int aToIndex, Object[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex;
        if (aLength != bToIndex - bFromIndex) return false;
        return mismatchObjects(a, aFromIndex, b, bFromIndex, aLength) < 0;
    }
    public static <T> boolean equals(T[] a, T[] a2, Comparator<? super T> cmp) {
        Objects.requireNonNull(cmp);
        if (a == a2) return true;
        if (a == null || a2 == null) return false;
        int length = a.length;
        if (a2.length != length) return false;
        return mismatchComparator(a, 0, a2, 0, length, cmp) < 0;
    }
    public static <T> boolean equals(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex, Comparator<? super T> cmp) {
        Objects.requireNonNull(cmp);
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex;
        if (aLength != bToIndex - bFromIndex) return false;
        return mismatchComparator(a, aFromIndex, b, bFromIndex, aLength, cmp) < 0;
    }
    public static <T extends Comparable<? super T>> int compare(T[] a, T[] b) {
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int length = Math.min(a.length, b.length);
        for (int i = 0; i < length; i++) {
            T oa = a[i], ob = b[i];
            if (oa != ob) {
                if (oa == null || ob == null) return oa == null ? -1 : 1;
                int v = oa.compareTo(ob);
                if (v != 0) return v;
            }
        }
        return a.length - b.length;
    }
    public static <T extends Comparable<? super T>> int compare(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex) {
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        for (int i = 0; i < length; i++) {
            T oa = a[aFromIndex + i], ob = b[bFromIndex + i];
            if (oa != ob) {
                if (oa == null || ob == null) return oa == null ? -1 : 1;
                int v = oa.compareTo(ob);
                if (v != 0) return v;
            }
        }
        return aLength - bLength;
    }
    public static <T> int compare(T[] a, T[] b, Comparator<? super T> cmp) {
        Objects.requireNonNull(cmp);
        if (a == b) return 0;
        if (a == null || b == null) return a == null ? -1 : 1;
        int length = Math.min(a.length, b.length);
        for (int i = 0; i < length; i++) {
            T oa = a[i], ob = b[i];
            if (oa != ob) {
                if (oa == null || ob == null) return oa == null ? -1 : 1;
                int v = cmp.compare(oa, ob);
                if (v != 0) return v;
            }
        }
        return a.length - b.length;
    }
    public static <T> int compare(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex, Comparator<? super T> cmp) {
        Objects.requireNonNull(cmp);
        rangeCheck(a.length, aFromIndex, aToIndex);
        rangeCheck(b.length, bFromIndex, bToIndex);
        int aLength = aToIndex - aFromIndex, bLength = bToIndex - bFromIndex, length = Math.min(aLength, bLength);
        for (int i = 0; i < length; i++) {
            T oa = a[aFromIndex + i], ob = b[bFromIndex + i];
            if (oa != ob) {
                if (oa == null || ob == null) return oa == null ? -1 : 1;
                int v = cmp.compare(oa, ob);
                if (v != 0) return v;
            }
        }
        return aLength - bLength;
    }

    // ---- deepEquals / deepToString ------------------------------------------------------------------------------------------------------------------------------
    public static boolean deepEquals(Object[] a1, Object[] a2) {
        if (a1 == a2) return true;
        if (a1 == null || a2 == null) return false;
        int length = a1.length;
        if (a2.length != length) return false;
        for (int i = 0; i < length; i++) {
            Object e1 = a1[i], e2 = a2[i];
            if (e1 == e2) continue;
            if (e1 == null) return false;
            if (!deepEquals0(e1, e2)) return false;
        }
        return true;
    }
    private static boolean deepEquals0(Object e1, Object e2) {
        if (e1 instanceof Object[] && e2 instanceof Object[]) return deepEquals((Object[]) e1, (Object[]) e2);
        if (e1 instanceof byte[] && e2 instanceof byte[]) return Arrays.equals((byte[]) e1, (byte[]) e2);
        if (e1 instanceof short[] && e2 instanceof short[]) return Arrays.equals((short[]) e1, (short[]) e2);
        if (e1 instanceof int[] && e2 instanceof int[]) return Arrays.equals((int[]) e1, (int[]) e2);
        if (e1 instanceof long[] && e2 instanceof long[]) return Arrays.equals((long[]) e1, (long[]) e2);
        if (e1 instanceof char[] && e2 instanceof char[]) return Arrays.equals((char[]) e1, (char[]) e2);
        if (e1 instanceof float[] && e2 instanceof float[]) return Arrays.equals((float[]) e1, (float[]) e2);
        if (e1 instanceof double[] && e2 instanceof double[]) return Arrays.equals((double[]) e1, (double[]) e2);
        if (e1 instanceof boolean[] && e2 instanceof boolean[]) return Arrays.equals((boolean[]) e1, (boolean[]) e2);
        return e1.equals(e2);
    }
    public static String deepToString(Object[] a) {
        if (a == null) return "null";
        StringBuilder buf = new StringBuilder();
        deepToString(a, buf, new HashSet<Object[]>());
        return buf.toString();
    }
    private static void deepToString(Object[] a, StringBuilder buf, Set<Object[]> dejaVu) {
        if (a == null) { buf.append("null"); return; }
        int iMax = a.length - 1;
        if (iMax == -1) { buf.append("[]"); return; }
        dejaVu.add(a);
        buf.append('[');
        for (int i = 0; ; i++) {
            Object element = a[i];
            if (element == null) buf.append("null");
            else if (element instanceof Object[]) {
                if (dejaVu.contains(element)) buf.append("[...]"); else deepToString((Object[]) element, buf, dejaVu);
            }
            else if (element instanceof byte[]) buf.append(Arrays.toString((byte[]) element));
            else if (element instanceof short[]) buf.append(Arrays.toString((short[]) element));
            else if (element instanceof int[]) buf.append(Arrays.toString((int[]) element));
            else if (element instanceof long[]) buf.append(Arrays.toString((long[]) element));
            else if (element instanceof char[]) buf.append(Arrays.toString((char[]) element));
            else if (element instanceof float[]) buf.append(Arrays.toString((float[]) element));
            else if (element instanceof double[]) buf.append(Arrays.toString((double[]) element));
            else if (element instanceof boolean[]) buf.append(Arrays.toString((boolean[]) element));
            else buf.append(element.toString());
            if (i == iMax) break;
            buf.append(", ");
        }
        buf.append(']');
        dejaVu.remove(a);
    }

    // ---- binarySearch -------------------------------------------------------------------------------------------------------------------------------------------
    public static int binarySearch(Object[] a, int fromIndex, int toIndex, Object key) {
        rangeCheck(a.length, fromIndex, toIndex);
        int low = fromIndex, high = toIndex - 1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            @SuppressWarnings("rawtypes") Comparable midVal = (Comparable) a[mid];
            @SuppressWarnings("unchecked") int cmp = midVal.compareTo(key);
            if (cmp < 0) low = mid + 1; else if (cmp > 0) high = mid - 1; else return mid;
        }
        return -(low + 1);
    }
    public static <T> int binarySearch(T[] a, T key, Comparator<? super T> c) { return binarySearch(a, 0, a.length, key, c); }
    public static <T> int binarySearch(T[] a, int fromIndex, int toIndex, T key, Comparator<? super T> c) {
        if (c == null) return binarySearch((Object[]) a, fromIndex, toIndex, (Object) key);
        rangeCheck(a.length, fromIndex, toIndex);
        int low = fromIndex, high = toIndex - 1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            T midVal = a[mid];
            int cmp = c.compare(midVal, key);
            if (cmp < 0) low = mid + 1; else if (cmp > 0) high = mid - 1; else return mid;
        }
        return -(low + 1);
    }

    // ---- setAll / parallelSetAll / parallelPrefix / parallelSort ------------------------------------------------------------------------------------------------
    public static <T> void setAll(T[] array, IntFunction<? extends T> generator) { Objects.requireNonNull(generator); for (int i = 0; i < array.length; i++) array[i] = generator.apply(i); }
    public static <T> void parallelSetAll(T[] array, IntFunction<? extends T> generator) { setAll(array, generator); }
    public static void setAll(int[] array, IntUnaryOperator generator) { Objects.requireNonNull(generator); for (int i = 0; i < array.length; i++) array[i] = generator.applyAsInt(i); }
    public static void parallelSetAll(int[] array, IntUnaryOperator generator) { setAll(array, generator); }
    public static void setAll(long[] array, IntToLongFunction generator) { Objects.requireNonNull(generator); for (int i = 0; i < array.length; i++) array[i] = generator.applyAsLong(i); }
    public static void parallelSetAll(long[] array, IntToLongFunction generator) { setAll(array, generator); }
    public static void setAll(double[] array, IntToDoubleFunction generator) { Objects.requireNonNull(generator); for (int i = 0; i < array.length; i++) array[i] = generator.applyAsDouble(i); }
    public static void parallelSetAll(double[] array, IntToDoubleFunction generator) { setAll(array, generator); }

    public static <T> void parallelPrefix(T[] array, BinaryOperator<T> op) { Objects.requireNonNull(op); for (int i = 1; i < array.length; i++) array[i] = op.apply(array[i - 1], array[i]); }
    public static <T> void parallelPrefix(T[] array, int fromIndex, int toIndex, BinaryOperator<T> op) {
        Objects.requireNonNull(op); rangeCheck(array.length, fromIndex, toIndex);
        for (int i = fromIndex + 1; i < toIndex; i++) array[i] = op.apply(array[i - 1], array[i]);
    }
    public static void parallelPrefix(int[] array, IntBinaryOperator op) { Objects.requireNonNull(op); for (int i = 1; i < array.length; i++) array[i] = op.applyAsInt(array[i - 1], array[i]); }
    public static void parallelPrefix(int[] array, int fromIndex, int toIndex, IntBinaryOperator op) {
        Objects.requireNonNull(op); rangeCheck(array.length, fromIndex, toIndex);
        for (int i = fromIndex + 1; i < toIndex; i++) array[i] = op.applyAsInt(array[i - 1], array[i]);
    }
    public static void parallelPrefix(long[] array, LongBinaryOperator op) { Objects.requireNonNull(op); for (int i = 1; i < array.length; i++) array[i] = op.applyAsLong(array[i - 1], array[i]); }
    public static void parallelPrefix(long[] array, int fromIndex, int toIndex, LongBinaryOperator op) {
        Objects.requireNonNull(op); rangeCheck(array.length, fromIndex, toIndex);
        for (int i = fromIndex + 1; i < toIndex; i++) array[i] = op.applyAsLong(array[i - 1], array[i]);
    }
    public static void parallelPrefix(double[] array, DoubleBinaryOperator op) { Objects.requireNonNull(op); for (int i = 1; i < array.length; i++) array[i] = op.applyAsDouble(array[i - 1], array[i]); }
    public static void parallelPrefix(double[] array, int fromIndex, int toIndex, DoubleBinaryOperator op) {
        Objects.requireNonNull(op); rangeCheck(array.length, fromIndex, toIndex);
        for (int i = fromIndex + 1; i < toIndex; i++) array[i] = op.applyAsDouble(array[i - 1], array[i]);
    }
    public static <T extends Comparable<? super T>> void parallelSort(T[] a) { Arrays.sort(a); }
    public static <T extends Comparable<? super T>> void parallelSort(T[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }
    public static <T> void parallelSort(T[] a, Comparator<? super T> cmp) { Arrays.sort(a, cmp); }
    public static <T> void parallelSort(T[] a, int fromIndex, int toIndex, Comparator<? super T> cmp) { Arrays.sort(a, fromIndex, toIndex, cmp); }


    public static void parallelSort(byte[] a) { Arrays.sort(a); }
    public static void parallelSort(byte[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }

    public static void parallelSort(char[] a) { Arrays.sort(a); }
    public static void parallelSort(char[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }

    public static void parallelSort(short[] a) { Arrays.sort(a); }
    public static void parallelSort(short[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }

    public static void parallelSort(int[] a) { Arrays.sort(a); }
    public static void parallelSort(int[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }

    public static void parallelSort(long[] a) { Arrays.sort(a); }
    public static void parallelSort(long[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }

    public static void parallelSort(float[] a) { Arrays.sort(a); }
    public static void parallelSort(float[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }

    public static void parallelSort(double[] a) { Arrays.sort(a); }
    public static void parallelSort(double[] a, int fromIndex, int toIndex) { Arrays.sort(a, fromIndex, toIndex); }

}
