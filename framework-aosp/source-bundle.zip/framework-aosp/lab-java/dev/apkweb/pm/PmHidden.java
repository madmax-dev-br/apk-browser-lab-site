package dev.apkweb.pm;

import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Process;
import android.os.UserHandle;

/**
 * Hidden members the original android.content.pm.ShortcutInfo reads. The browser VM runs one user (id 0) and its Icon host has no tint, so these are exact:
 * Context.getUserId() is 0, UserHandle.of(0) is the process's own handle and Icon.hasTint() is false. scripts/prepare-javatime-sources.py rewrites the hidden call
 * sites to these helpers (recorded transform).
 */
public final class PmHidden {
    private PmHidden() {}

    public static int userId(Context context) { return 0; }

    public static boolean hasTint(Icon icon) { return false; }

    public static UserHandle userHandle(int userId) {
        if (userId != 0) throw new IllegalArgumentException("The browser VM has a single user (0), not " + userId);
        return Process.myUserHandle();
    }
}
