package dev.apkweb.view;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

/**
 * The hidden View / ViewGroup members the original android.view.FocusFinder reads, written over the public View API (scripts/prepare-javatime-sources.py rewrites the call sites).
 * View.findUserSetNextFocus resolves nextFocus*Id relative to the focused view's namespace: the id is looked up in the focused view's subtree and then in each ancestor's, up to the root.
 */
public final class FocusHidden {
    private FocusHidden() { }

    private static View findViewInsideOut(View root, View start, int id) {
        for (View current = start; current != null; ) {
            View hit = current.findViewById(id);
            if (hit != null) return hit;
            if (current == root) return null;
            ViewParent parent = current.getParent();
            current = parent instanceof View ? (View) parent : null;
        }
        return null;
    }

    private static View findByForwardTarget(View view, int id) {
        if (view.getNextFocusForwardId() == id) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) { View hit = findByForwardTarget(group.getChildAt(i), id); if (hit != null) return hit; }
        }
        return null;
    }

    private static View findByClusterForwardTarget(View view, int id) {
        if (view.getNextClusterForwardId() == id) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) { View hit = findByClusterForwardTarget(group.getChildAt(i), id); if (hit != null) return hit; }
        }
        return null;
    }

    public static View findUserSetNextFocus(View view, View root, int direction) {
        switch (direction) {
            case View.FOCUS_LEFT: return view.getNextFocusLeftId() == View.NO_ID ? null : findViewInsideOut(root, view, view.getNextFocusLeftId());
            case View.FOCUS_RIGHT: return view.getNextFocusRightId() == View.NO_ID ? null : findViewInsideOut(root, view, view.getNextFocusRightId());
            case View.FOCUS_UP: return view.getNextFocusUpId() == View.NO_ID ? null : findViewInsideOut(root, view, view.getNextFocusUpId());
            case View.FOCUS_DOWN: return view.getNextFocusDownId() == View.NO_ID ? null : findViewInsideOut(root, view, view.getNextFocusDownId());
            case View.FOCUS_FORWARD: return view.getNextFocusForwardId() == View.NO_ID ? null : findViewInsideOut(root, view, view.getNextFocusForwardId());
            case View.FOCUS_BACKWARD: return view.getId() == View.NO_ID ? null : findByForwardTarget(root, view.getId());
        }
        return null;
    }

    public static View findUserSetNextKeyboardNavigationCluster(View view, View root, int direction) {
        switch (direction) {
            case View.FOCUS_FORWARD: return view.getNextClusterForwardId() == View.NO_ID ? null : findViewInsideOut(root, view, view.getNextClusterForwardId());
            case View.FOCUS_BACKWARD: return view.getId() == View.NO_ID ? null : findByClusterForwardTarget(root, view.getId());
        }
        return null;
    }

    public static boolean isLayoutRtl(View view) { return view.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL; }

    /** ViewGroup.offsetRectBetweenParentAndChild over the public offset methods (clipToBounds is not applied). */
    public static void offsetRectBetweenParentAndChild(ViewGroup parent, View descendant, Rect rect, boolean offsetFromChildToParent, boolean clipToBounds) {
        if (offsetFromChildToParent) parent.offsetDescendantRectToMyCoords(descendant, rect); else parent.offsetRectIntoDescendantCoords(descendant, rect);
    }
}
