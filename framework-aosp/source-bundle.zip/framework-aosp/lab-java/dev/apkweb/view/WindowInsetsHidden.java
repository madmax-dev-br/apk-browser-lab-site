package dev.apkweb.view;

import android.graphics.Insets;

/** WindowInsets.insetInsets (hidden static of android-13.0.0_r1): the original body, used by the original WindowInsetsAnimation.Bounds through a documented source transform. */
public final class WindowInsetsHidden {
    private WindowInsetsHidden() {}

    public static Insets insetInsets(Insets insets, int left, int top, int right, int bottom) {
        int newLeft = Math.max(0, insets.left - left);
        int newTop = Math.max(0, insets.top - top);
        int newRight = Math.max(0, insets.right - right);
        int newBottom = Math.max(0, insets.bottom - bottom);
        if (newLeft == left && newTop == top && newRight == right && newBottom == bottom) {
            return insets;
        }
        return Insets.of(newLeft, newTop, newRight, newBottom);
    }
}
