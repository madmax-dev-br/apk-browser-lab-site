package dev.apkweb.view;

import android.view.View;

/**
 * The hidden View/Build members the original AccessibilityNodeInfo family reads (View.getAccessibilityViewId, View.getAccessibilityWindowId, Build.IS_DEBUGGABLE): hidden API is
 * not on the compile classpath, so scripts/prepare-javatime-sources.py rewrites those few call sites to this helper (documented transform, see javatime-transforms.json).
 * Native: the ids belong to the view host (src/view-hidden-native.js): a view's accessibility id is allocated on first use from one counter, like View.sNextAccessibilityViewId.
 */
public final class ViewHidden {
    private ViewHidden() {}
    public static native int accessibilityViewId(View view);
    public static native int accessibilityWindowId(View view);
    public static final boolean IS_DEBUGGABLE = false;
}
