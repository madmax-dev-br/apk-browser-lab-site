/*
 * APK Browser Lab -- lab-authored replacement for libcore's java.time.zone.IcuZoneRulesProvider (android-13.0.0_r1).
 *
 * The Android class generates ZoneRules from ICU4J (android.icu.util.TimeZone + com.android.icu.util.ExtendedTimeZone), a library this VM does not
 * contain. This class keeps the same name and contract (the single ZoneRulesProvider that java.time.zone.ZoneRulesProvider registers) but takes the
 * rules from vendor/tzdata/tzdb.dat: the IANA tz database 2022a that AOSP android-13.0.0_r1 ships (system/timezone/input_data/iana/tzdata2022a.tar.gz)
 * compiled by OpenJDK's own TzdbZoneRulesCompiler into serialized java.time ZoneRules (see scripts/build-tzdb.sh and vendor/tzdata/provenance.json).
 * Rules are real transitions plus the recurring last-rules; nothing is synthesized. The bytes arrive through the framework native nativeTzdb().
 */
package java.time.zone;

import java.io.DataInput;
import java.io.IOException;
import java.io.UTFDataFormatException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;

public class IcuZoneRulesProvider extends ZoneRulesProvider {

    /** The serialized tzdb.dat of the vendored tz database (never null). */
    private static native byte[] nativeTzdb();

    private final String versionId;
    private final Map<String, byte[]> regionToRules = new HashMap<>();
    private final Map<String, ZoneRules> cache = new HashMap<>();

    public IcuZoneRulesProvider() {
        byte[] data = nativeTzdb();
        try {
            ArrayDataInput in = new ArrayDataInput(data);
            if (in.readByte() != 1) {
                throw new ZoneRulesException("File format not recognised");
            }
            if (!"TZDB".equals(in.readUTF())) {
                throw new ZoneRulesException("File format not recognised");
            }
            int versionCount = in.readShort();
            String version = null;
            for (int i = 0; i < versionCount; i++) {
                version = in.readUTF();
            }
            versionId = version;
            int regionCount = in.readShort();
            String[] regions = new String[regionCount];
            for (int i = 0; i < regionCount; i++) {
                regions[i] = in.readUTF();
            }
            int ruleCount = in.readShort();
            byte[][] rules = new byte[ruleCount][];
            for (int i = 0; i < ruleCount; i++) {
                rules[i] = new byte[in.readShort()];
                in.readFully(rules[i]);
            }
            // Only the last (current) version's region table is kept, as TzdbZoneRulesProvider does.
            for (int i = 0; i < versionCount; i++) {
                int versionRegionCount = in.readShort();
                regionToRules.clear();
                for (int j = 0; j < versionRegionCount; j++) {
                    String region = regions[in.readShort()];
                    byte[] rule = rules[in.readShort() & 0xffff];
                    regionToRules.put(region, rule);
                }
            }
        } catch (Exception ex) {
            throw new ZoneRulesException("Unable to load the tz database", ex);
        }
    }

    @Override
    protected Set<String> provideZoneIds() {
        Set<String> zoneIds = new HashSet<>(regionToRules.keySet());
        // java.time assumes ZoneId that start with "GMT" fit the pattern "GMT+HH:mm:ss" which these do not; as the Android provider does, drop them.
        zoneIds.remove("GMT+0");
        zoneIds.remove("GMT-0");
        return zoneIds;
    }

    @Override
    protected ZoneRules provideRules(String zoneId, boolean forCaching) {
        // Ignore forCaching, as this is a static provider.
        synchronized (cache) {
            ZoneRules rules = cache.get(zoneId);
            if (rules == null) {
                byte[] data = regionToRules.get(zoneId);
                if (data == null) {
                    throw new ZoneRulesException("Unknown time-zone ID: " + zoneId);
                }
                try {
                    rules = (ZoneRules) Ser.read(new ArrayDataInput(data));
                } catch (Exception ex) {
                    throw new ZoneRulesException("Invalid binary time-zone data: TZDB:" + zoneId + ", version: " + versionId, ex);
                }
                cache.put(zoneId, rules);
            }
            return rules;
        }
    }

    @Override
    protected NavigableMap<String, ZoneRules> provideVersions(String zoneId) {
        return new TreeMap<>(Collections.singletonMap(versionId, provideRules(zoneId, false)));
    }

    @Override
    public String toString() {
        return "TZDB[" + versionId + "]";
    }

    /** Big-endian java.io.DataInput over a byte array (the format DataOutputStream writes). */
    private static final class ArrayDataInput implements DataInput {
        private final byte[] data;
        private int pos;

        ArrayDataInput(byte[] data) {
            this.data = data;
        }

        private int next() throws IOException {
            if (pos >= data.length) {
                throw new java.io.EOFException();
            }
            return data[pos++] & 0xff;
        }

        @Override public void readFully(byte[] b) throws IOException { readFully(b, 0, b.length); }
        @Override public void readFully(byte[] b, int off, int len) throws IOException {
            if (len < 0 || pos + len > data.length) {
                throw new java.io.EOFException();
            }
            System.arraycopy(data, pos, b, off, len);
            pos += len;
        }
        @Override public int skipBytes(int n) throws IOException {
            int skipped = Math.max(0, Math.min(n, data.length - pos));
            pos += skipped;
            return skipped;
        }
        @Override public boolean readBoolean() throws IOException { return next() != 0; }
        @Override public byte readByte() throws IOException { return (byte) next(); }
        @Override public int readUnsignedByte() throws IOException { return next(); }
        @Override public short readShort() throws IOException { return (short) ((next() << 8) | next()); }
        @Override public int readUnsignedShort() throws IOException { return (next() << 8) | next(); }
        @Override public char readChar() throws IOException { return (char) ((next() << 8) | next()); }
        @Override public int readInt() throws IOException { return (next() << 24) | (next() << 16) | (next() << 8) | next(); }
        @Override public long readLong() throws IOException { return ((long) readInt() << 32) | (readInt() & 0xffffffffL); }
        @Override public float readFloat() throws IOException { return Float.intBitsToFloat(readInt()); }
        @Override public double readDouble() throws IOException { return Double.longBitsToDouble(readLong()); }
        @Override public String readLine() throws IOException { throw new UnsupportedOperationException("readLine"); }
        @Override public String readUTF() throws IOException {
            int length = readUnsignedShort();
            char[] chars = new char[length];
            int count = 0;
            int end = pos + length;
            if (end > data.length) {
                throw new java.io.EOFException();
            }
            while (pos < end) {
                int a = data[pos++] & 0xff;
                switch (a >> 4) {
                    case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
                        chars[count++] = (char) a;
                        break;
                    case 12: case 13: {
                        if (pos >= end) {
                            throw new UTFDataFormatException("malformed input: partial character at end");
                        }
                        int b = data[pos++];
                        if ((b & 0xC0) != 0x80) {
                            throw new UTFDataFormatException("malformed input around byte " + (pos - 1));
                        }
                        chars[count++] = (char) (((a & 0x1F) << 6) | (b & 0x3F));
                        break;
                    }
                    case 14: {
                        if (pos + 2 > end) {
                            throw new UTFDataFormatException("malformed input: partial character at end");
                        }
                        int b = data[pos++];
                        int c = data[pos++];
                        if ((b & 0xC0) != 0x80 || (c & 0xC0) != 0x80) {
                            throw new UTFDataFormatException("malformed input around byte " + (pos - 1));
                        }
                        chars[count++] = (char) (((a & 0x0F) << 12) | ((b & 0x3F) << 6) | (c & 0x3F));
                        break;
                    }
                    default:
                        throw new UTFDataFormatException("malformed input around byte " + (pos - 1));
                }
            }
            return new String(chars, 0, count);
        }
    }
}
