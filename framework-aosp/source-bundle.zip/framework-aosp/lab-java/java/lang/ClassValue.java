package java.lang;

import java.util.Objects;
import java.util.WeakHashMap;

/**
 * Lab-authored java.lang.ClassValue with the documented contract (the libcore class stores the values in a hidden field of java.lang.Class): one lazily computed, cached value per Class and
 * ClassValue instance; computeValue may run more than once when threads race, and the first value stored wins; remove(Class) makes the next get recompute. Keys are held weakly.
 */
public abstract class ClassValue<T> {
    private static final Object NULL = new Object();
    private final WeakHashMap<Class<?>, Object> values = new WeakHashMap<>();

    protected ClassValue() {}

    protected abstract T computeValue(Class<?> type);

    @SuppressWarnings("unchecked")
    public T get(Class<?> type) {
        Objects.requireNonNull(type);
        Object value;
        synchronized (values) { value = values.get(type); }
        if (value == null) {
            T computed = computeValue(type);
            Object stored = computed == null ? NULL : computed;
            synchronized (values) {
                Object existing = values.get(type);
                if (existing != null) stored = existing; else values.put(type, stored);
            }
            value = stored;
        }
        return value == NULL ? null : (T) value;
    }

    public void remove(Class<?> type) {
        Objects.requireNonNull(type);
        synchronized (values) { values.remove(type); }
    }
}
