/*
 * Lab-authored java.util.concurrent.ForkJoinWorkerThread: the VM has no ForkJoinPool, so no instance can exist; the class is here so that `Thread.currentThread() instanceof ForkJoinWorkerThread`
 * (CompletableFuture's blocking paths) resolves and answers false.
 */
package java.util.concurrent;

public class ForkJoinWorkerThread extends Thread {
    ForkJoinWorkerThread() {}
}
