/*
 * Lab-authored minimal java.util.concurrent.ForkJoinTask for the browser VM. The VM has no ForkJoinPool (no work-stealing workers), so the only job of this class is to be the base type that
 * CompletableFuture's internal Completion / AsyncSupply / AsyncRun nodes extend: the abstract task contract and the 16-bit task tag CompletableFuture claims nodes with
 * (compareAndSetForkJoinTaskTag). Everything that would hand work to a pool (fork, invoke, join, get) fails explicitly instead of pretending.
 */
package java.util.concurrent;

import java.io.Serializable;

public abstract class ForkJoinTask<V> implements Future<V>, Serializable {
    private static final long serialVersionUID = -7721805057305804111L;
    private short tag;

    public ForkJoinTask() {}

    public abstract V getRawResult();

    protected abstract void setRawResult(V value);

    protected abstract boolean exec();

    public final synchronized short getForkJoinTaskTag() { return tag; }

    public final synchronized short setForkJoinTaskTag(short newValue) { short old = tag; tag = newValue; return old; }

    public final synchronized boolean compareAndSetForkJoinTaskTag(short expect, short update) {
        if (tag != expect) return false;
        tag = update;
        return true;
    }

    private static UnsupportedOperationException unsupported(String what) {
        return new UnsupportedOperationException("ForkJoinTask." + what + ": the browser VM has no ForkJoinPool");
    }

    public final ForkJoinTask<V> fork() { throw unsupported("fork"); }

    public final V join() { throw unsupported("join"); }

    public final V invoke() { throw unsupported("invoke"); }

    @Override public boolean cancel(boolean mayInterruptIfRunning) { throw unsupported("cancel"); }

    @Override public final boolean isDone() { throw unsupported("isDone"); }

    @Override public final boolean isCancelled() { throw unsupported("isCancelled"); }

    @Override public final V get() throws InterruptedException, ExecutionException { throw unsupported("get"); }

    @Override public final V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException { throw unsupported("get"); }
}
