package java.util.concurrent.atomic;

import java.util.Arrays;
import java.util.function.LongBinaryOperator;
import java.util.function.LongUnaryOperator;

/**
 * An long array in which elements may be updated atomically (android-13.0.0_r1 API). Lab-authored: libcore builds it on VarHandle array element access; this class makes every
 * access a synchronized operation on the array, which is atomic under the VM's green threads (the memory-order variants are all the volatile operation: single processor).
 */
public class AtomicLongArray implements java.io.Serializable {
    private static final long serialVersionUID = -2308431214976778248L;
    private final long[] array;

    public AtomicLongArray(int length) { array = new long[length]; }

    public AtomicLongArray(long[] array) { this.array = array.clone(); }

    public final int length() { return array.length; }

    public final synchronized long get(int i) { return array[i]; }
    public final synchronized void set(int i, long newValue) { array[i] = newValue; }
    public final synchronized void lazySet(int i, long newValue) { array[i] = newValue; }
    public final synchronized long getAndSet(int i, long newValue) { long old = array[i]; array[i] = newValue; return old; }
    public final synchronized boolean compareAndSet(int i, long expectedValue, long newValue) {
        if (array[i] != expectedValue) return false;
        array[i] = newValue;
        return true;
    }
    @Deprecated public final boolean weakCompareAndSet(int i, long expectedValue, long newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetPlain(int i, long expectedValue, long newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetVolatile(int i, long expectedValue, long newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetAcquire(int i, long expectedValue, long newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetRelease(int i, long expectedValue, long newValue) { return compareAndSet(i, expectedValue, newValue); }

    public final synchronized long getAndIncrement(int i) { return array[i]++; }
    public final synchronized long getAndDecrement(int i) { return array[i]--; }
    public final synchronized long getAndAdd(int i, long delta) { long old = array[i]; array[i] = old + delta; return old; }
    public final synchronized long incrementAndGet(int i) { return ++array[i]; }
    public final synchronized long decrementAndGet(int i) { return --array[i]; }
    public final synchronized long addAndGet(int i, long delta) { return array[i] += delta; }

    public final synchronized long getAndUpdate(int i, LongUnaryOperator updateFunction) { long old = array[i]; array[i] = updateFunction.applyAsLong(old); return old; }
    public final synchronized long updateAndGet(int i, LongUnaryOperator updateFunction) { return array[i] = updateFunction.applyAsLong(array[i]); }
    public final synchronized long getAndAccumulate(int i, long x, LongBinaryOperator accumulatorFunction) { long old = array[i]; array[i] = accumulatorFunction.applyAsLong(old, x); return old; }
    public final synchronized long accumulateAndGet(int i, long x, LongBinaryOperator accumulatorFunction) { return array[i] = accumulatorFunction.applyAsLong(array[i], x); }

    public final synchronized long getPlain(int i) { return array[i]; }
    public final synchronized long getOpaque(int i) { return array[i]; }
    public final synchronized long getAcquire(int i) { return array[i]; }
    public final synchronized void setPlain(int i, long newValue) { array[i] = newValue; }
    public final synchronized void setOpaque(int i, long newValue) { array[i] = newValue; }
    public final synchronized void setRelease(int i, long newValue) { array[i] = newValue; }

    public final synchronized long compareAndExchange(int i, long expectedValue, long newValue) {
        long witness = array[i];
        if (witness == expectedValue) array[i] = newValue;
        return witness;
    }
    public final long compareAndExchangeAcquire(int i, long expectedValue, long newValue) { return compareAndExchange(i, expectedValue, newValue); }
    public final long compareAndExchangeRelease(int i, long expectedValue, long newValue) { return compareAndExchange(i, expectedValue, newValue); }

    public synchronized String toString() { return Arrays.toString(array); }
}
