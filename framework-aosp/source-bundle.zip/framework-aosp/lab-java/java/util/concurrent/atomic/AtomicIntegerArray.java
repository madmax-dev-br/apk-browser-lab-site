package java.util.concurrent.atomic;

import java.util.Arrays;
import java.util.function.IntBinaryOperator;
import java.util.function.IntUnaryOperator;

/**
 * An int array in which elements may be updated atomically (android-13.0.0_r1 API). Lab-authored: libcore builds it on VarHandle array element access; this class makes every
 * access a synchronized operation on the array, which is atomic under the VM's green threads (the memory-order variants are all the volatile operation: single processor).
 */
public class AtomicIntegerArray implements java.io.Serializable {
    private static final long serialVersionUID = 2862133569453604235L;
    private final int[] array;

    public AtomicIntegerArray(int length) { array = new int[length]; }

    public AtomicIntegerArray(int[] array) { this.array = array.clone(); }

    public final int length() { return array.length; }

    public final synchronized int get(int i) { return array[i]; }
    public final synchronized void set(int i, int newValue) { array[i] = newValue; }
    public final synchronized void lazySet(int i, int newValue) { array[i] = newValue; }
    public final synchronized int getAndSet(int i, int newValue) { int old = array[i]; array[i] = newValue; return old; }
    public final synchronized boolean compareAndSet(int i, int expectedValue, int newValue) {
        if (array[i] != expectedValue) return false;
        array[i] = newValue;
        return true;
    }
    @Deprecated public final boolean weakCompareAndSet(int i, int expectedValue, int newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetPlain(int i, int expectedValue, int newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetVolatile(int i, int expectedValue, int newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetAcquire(int i, int expectedValue, int newValue) { return compareAndSet(i, expectedValue, newValue); }
    public final boolean weakCompareAndSetRelease(int i, int expectedValue, int newValue) { return compareAndSet(i, expectedValue, newValue); }

    public final synchronized int getAndIncrement(int i) { return array[i]++; }
    public final synchronized int getAndDecrement(int i) { return array[i]--; }
    public final synchronized int getAndAdd(int i, int delta) { int old = array[i]; array[i] = old + delta; return old; }
    public final synchronized int incrementAndGet(int i) { return ++array[i]; }
    public final synchronized int decrementAndGet(int i) { return --array[i]; }
    public final synchronized int addAndGet(int i, int delta) { return array[i] += delta; }

    public final synchronized int getAndUpdate(int i, IntUnaryOperator updateFunction) { int old = array[i]; array[i] = updateFunction.applyAsInt(old); return old; }
    public final synchronized int updateAndGet(int i, IntUnaryOperator updateFunction) { return array[i] = updateFunction.applyAsInt(array[i]); }
    public final synchronized int getAndAccumulate(int i, int x, IntBinaryOperator accumulatorFunction) { int old = array[i]; array[i] = accumulatorFunction.applyAsInt(old, x); return old; }
    public final synchronized int accumulateAndGet(int i, int x, IntBinaryOperator accumulatorFunction) { return array[i] = accumulatorFunction.applyAsInt(array[i], x); }

    public final synchronized int getPlain(int i) { return array[i]; }
    public final synchronized int getOpaque(int i) { return array[i]; }
    public final synchronized int getAcquire(int i) { return array[i]; }
    public final synchronized void setPlain(int i, int newValue) { array[i] = newValue; }
    public final synchronized void setOpaque(int i, int newValue) { array[i] = newValue; }
    public final synchronized void setRelease(int i, int newValue) { array[i] = newValue; }

    public final synchronized int compareAndExchange(int i, int expectedValue, int newValue) {
        int witness = array[i];
        if (witness == expectedValue) array[i] = newValue;
        return witness;
    }
    public final int compareAndExchangeAcquire(int i, int expectedValue, int newValue) { return compareAndExchange(i, expectedValue, newValue); }
    public final int compareAndExchangeRelease(int i, int expectedValue, int newValue) { return compareAndExchange(i, expectedValue, newValue); }

    public synchronized String toString() { return Arrays.toString(array); }
}
