package android.media;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.PersistableBundle;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;

/**
 * android.media.AudioTrack (API 33 public surface) for the virtual device.
 *
 * The framework class sits on PlayerBase, the audio service binder (IAudioService / IPlayer / AppOps), the audio policy and a native AudioTrack in AudioFlinger; none of those exist in the
 * browser VM. This class keeps the public contract of the original -- constants, argument validation (audioParamCheck / audioBuffSizeCheck), play / pause / stop / flush / release state
 * machine, blocking and non-blocking writes of byte[] / short[] / float[] / ByteBuffer, static-mode loop points, head position, markers and periodic notifications, playback rate,
 * volume, the Builder -- while the mixer is the host in src/audio-native.js: written PCM is queued in a ring, consumed at the track's real-time rate against the VM clock while playing,
 * and handed to the page's Web Audio output (or recorded when there is none). Not modelled: offloaded / tunneled / encapsulated playback (rejected), AudioPolicy mixes, effects
 * (attachAuxEffect fails), per-device routing (the route is always the built-in speaker), VolumeShaper.
 */
public class AudioTrack implements AudioRouting {
    private static final String TAG = "android.media.AudioTrack";

    public static final int PLAYSTATE_STOPPED = 1;
    public static final int PLAYSTATE_PAUSED = 2;
    public static final int PLAYSTATE_PLAYING = 3;
    private static final int PLAYSTATE_STOPPING = 4;
    private static final int PLAYSTATE_PAUSED_STOPPING = 5;

    public static final int MODE_STATIC = 0;
    public static final int MODE_STREAM = 1;

    public static final int STATE_UNINITIALIZED = 0;
    public static final int STATE_INITIALIZED = 1;
    public static final int STATE_NO_STATIC_DATA = 2;

    public static final int SUCCESS = AudioSystem.SUCCESS;
    public static final int ERROR = AudioSystem.ERROR;
    public static final int ERROR_BAD_VALUE = AudioSystem.BAD_VALUE;
    public static final int ERROR_INVALID_OPERATION = AudioSystem.INVALID_OPERATION;
    public static final int ERROR_DEAD_OBJECT = AudioSystem.DEAD_OBJECT;

    public static final int WRITE_BLOCKING = 0;
    public static final int WRITE_NON_BLOCKING = 1;

    public static final int PERFORMANCE_MODE_NONE = 0;
    public static final int PERFORMANCE_MODE_LOW_LATENCY = 1;
    public static final int PERFORMANCE_MODE_POWER_SAVING = 2;

    public static final int ENCAPSULATION_MODE_NONE = 0;
    public static final int ENCAPSULATION_MODE_ELEMENTARY_STREAM = 1;
    public static final int ENCAPSULATION_MODE_HANDLE = 2;

    public static final int ENCAPSULATION_METADATA_TYPE_NONE = 0;
    public static final int ENCAPSULATION_METADATA_TYPE_FRAMEWORK_TUNER = 1;
    public static final int ENCAPSULATION_METADATA_TYPE_DVB_AD_DESCRIPTOR = 2;

    private static final float VOLUME_MIN = 0.0f;
    private static final float VOLUME_MAX = 1.0f;
    private static final float GAIN_MIN = VOLUME_MIN;
    private static final float GAIN_MAX = VOLUME_MAX;
    private static final int SUPPORTED_OUT_CHANNELS = AudioFormat.CHANNEL_OUT_FRONT_LEFT | AudioFormat.CHANNEL_OUT_FRONT_RIGHT | AudioFormat.CHANNEL_OUT_FRONT_CENTER | AudioFormat.CHANNEL_OUT_LOW_FREQUENCY
        | AudioFormat.CHANNEL_OUT_BACK_LEFT | AudioFormat.CHANNEL_OUT_BACK_RIGHT | AudioFormat.CHANNEL_OUT_BACK_CENTER | AudioFormat.CHANNEL_OUT_SIDE_LEFT | AudioFormat.CHANNEL_OUT_SIDE_RIGHT;

    // events delivered from the host mixer (what codes of the native event)
    private static final int NATIVE_EVENT_MARKER = 3;
    private static final int NATIVE_EVENT_NEW_POS = 4;
    private static final int NATIVE_EVENT_STREAM_END = 7;

    private final Object mPlayStateLock = new Object();
    private volatile int mPlayState = PLAYSTATE_STOPPED;
    private int mState = STATE_UNINITIALIZED;
    private long mNativeHandle = 0;                 // the host mixer's track id
    private AudioAttributes mAttributes;
    private AudioAttributes mConfiguredAudioAttributes;
    private int mSampleRate = 0;
    private int mChannelCount = 1;
    private int mChannelMask = AudioFormat.CHANNEL_OUT_MONO;
    private int mChannelIndexMask = 0;
    private int mChannelConfiguration = AudioFormat.CHANNEL_OUT_MONO;
    private int mAudioFormat = AudioFormat.ENCODING_PCM_16BIT;
    private int mDataLoadMode = MODE_STREAM;
    private int mStreamType = AudioSystem.STREAM_DEFAULT;
    private int mNativeBufferSizeInBytes = 0;
    private int mNativeBufferSizeInFrames = 0;
    private int mSessionId = AudioManager.AUDIO_SESSION_ID_GENERATE;
    private int mPerformanceMode = PERFORMANCE_MODE_NONE;
    private Looper mInitializationLooper = null;
    private final Object mPositionListenerLock = new Object();
    private OnPlaybackPositionUpdateListener mPositionListener;
    private NativeEventHandlerDelegate mEventHandlerDelegate;
    private float mVolume = 1.0f, mLeftVolume = 1.0f, mRightVolume = 1.0f;
    private PlaybackParams mPlaybackParams = new PlaybackParams();
    private final WeakReference<AudioTrack> mWeakSelf = new WeakReference<AudioTrack>(this);
    private AudioDeviceInfo mPreferredDevice;
    private final java.util.ArrayList<RoutingListener> mRoutingListeners = new java.util.ArrayList<RoutingListener>();

    private static void loge(String s) { Log.e(TAG, s); }

    // ---- constructors ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    @Deprecated
    public AudioTrack(int streamType, int sampleRateInHz, int channelConfig, int audioFormat, int bufferSizeInBytes, int mode) throws IllegalArgumentException {
        this(streamType, sampleRateInHz, channelConfig, audioFormat, bufferSizeInBytes, mode, AudioManager.AUDIO_SESSION_ID_GENERATE);
    }

    @Deprecated
    public AudioTrack(int streamType, int sampleRateInHz, int channelConfig, int audioFormat, int bufferSizeInBytes, int mode, int sessionId) throws IllegalArgumentException {
        this((new AudioAttributes.Builder()).setLegacyStreamType(streamType).build(),
             (new AudioFormat.Builder()).setChannelMask(channelConfig).setEncoding(audioFormat).setSampleRate(sampleRateInHz).build(), bufferSizeInBytes, mode, sessionId);
        deprecateStreamTypeForPlayback(streamType, "AudioTrack", "AudioTrack()");
    }

    public AudioTrack(AudioAttributes attributes, AudioFormat format, int bufferSizeInBytes, int mode, int sessionId) throws IllegalArgumentException {
        this(attributes, format, bufferSizeInBytes, mode, sessionId, false, ENCAPSULATION_MODE_NONE);
    }

    private AudioTrack(AudioAttributes attributes, AudioFormat format, int bufferSizeInBytes, int mode, int sessionId, boolean offload, int encapsulationMode) throws IllegalArgumentException {
        if (attributes == null) throw new IllegalArgumentException("Illegal null AudioAttributes");
        mAttributes = attributes;
        mConfiguredAudioAttributes = attributes;
        if (format == null) throw new IllegalArgumentException("Illegal null AudioFormat");
        Looper looper;
        if ((looper = Looper.myLooper()) == null) looper = Looper.getMainLooper();
        int rate = format.getSampleRate();
        if (rate == AudioFormat.SAMPLE_RATE_UNSPECIFIED) rate = 0;
        int channelIndexMask = 0;
        if ((format.getPropertySetMask() & AudioFormat.AUDIO_FORMAT_HAS_PROPERTY_CHANNEL_INDEX_MASK) != 0) channelIndexMask = format.getChannelIndexMask();
        int channelMask = 0;
        if ((format.getPropertySetMask() & AudioFormat.AUDIO_FORMAT_HAS_PROPERTY_CHANNEL_MASK) != 0) channelMask = format.getChannelMask();
        else if (channelIndexMask == 0) channelMask = AudioFormat.CHANNEL_OUT_FRONT_LEFT | AudioFormat.CHANNEL_OUT_FRONT_RIGHT;
        int encoding = AudioFormat.ENCODING_DEFAULT;
        if ((format.getPropertySetMask() & AudioFormat.AUDIO_FORMAT_HAS_PROPERTY_ENCODING) != 0) encoding = format.getEncoding();
        audioParamCheck(rate, channelMask, channelIndexMask, encoding, mode);
        mStreamType = AudioSystem.STREAM_DEFAULT;
        audioBuffSizeCheck(bufferSizeInBytes);
        mInitializationLooper = looper;
        if (sessionId < 0) throw new IllegalArgumentException("Invalid audio session ID: " + sessionId);
        if (offload || encapsulationMode != ENCAPSULATION_MODE_NONE) {
            loge("Offloaded and encapsulated playback are not available on the virtual device");
            return;                                                     // mState stays STATE_UNINITIALIZED, like a failed native setup
        }
        int[] sampleRate = new int[] {mSampleRate};
        int[] session = new int[] {sessionId};
        int initResult = native_setup(mWeakSelf, mAttributes.getUsage(), mAttributes.getContentType(), sampleRate, mChannelCount, mAudioFormat, mNativeBufferSizeInBytes, mDataLoadMode, session);
        if (initResult != SUCCESS) { loge("Error code " + initResult + " when initializing AudioTrack."); return; }
        mSampleRate = sampleRate[0];
        mSessionId = session[0];
        mPlaybackParams.setSpeed(1.0f).setPitch(1.0f);
        mState = mDataLoadMode == MODE_STATIC ? STATE_NO_STATIC_DATA : STATE_INITIALIZED;
        mEventHandlerDelegate = new NativeEventHandlerDelegate(this, null, looper);
    }

    private static void deprecateStreamTypeForPlayback(int streamType, String className, String opName) {
        if (streamType == AudioManager.STREAM_ACCESSIBILITY) throw new IllegalArgumentException("Use of STREAM_ACCESSIBILITY is reserved for volume control endpoints. Use USAGE_ASSISTANCE_ACCESSIBILITY for narration instead");
        Log.w(className, "Use of stream types is deprecated for operations other than volume control");
        Log.w(className, "See the documentation of " + opName + " for what to use instead with android.media.AudioAttributes to qualify your playback use case");
    }

    // ---- Builder ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public static class Builder {
        private AudioAttributes mAttributes;
        private AudioFormat mFormat;
        private int mBufferSizeInBytes;
        private int mEncapsulationMode = ENCAPSULATION_MODE_NONE;
        private int mSessionId = AudioManager.AUDIO_SESSION_ID_GENERATE;
        private int mMode = MODE_STREAM;
        private int mPerformanceMode = PERFORMANCE_MODE_NONE;
        private boolean mOffload = false;

        public Builder() { }

        public @NonNull Builder setAudioAttributes(@NonNull AudioAttributes attributes) throws IllegalArgumentException {
            if (attributes == null) throw new IllegalArgumentException("Illegal null AudioAttributes argument");
            mAttributes = attributes;
            return this;
        }

        public @NonNull Builder setAudioFormat(@NonNull AudioFormat format) throws IllegalArgumentException {
            if (format == null) throw new IllegalArgumentException("Illegal null AudioFormat argument");
            mFormat = format;
            return this;
        }

        public @NonNull Builder setBufferSizeInBytes(int bufferSizeInBytes) throws IllegalArgumentException {
            if (bufferSizeInBytes <= 0) throw new IllegalArgumentException("Invalid buffer size " + bufferSizeInBytes);
            mBufferSizeInBytes = bufferSizeInBytes;
            return this;
        }

        public @NonNull Builder setEncapsulationMode(int encapsulationMode) {
            switch (encapsulationMode) {
                case ENCAPSULATION_MODE_NONE: case ENCAPSULATION_MODE_ELEMENTARY_STREAM: case ENCAPSULATION_MODE_HANDLE: mEncapsulationMode = encapsulationMode; break;
                default: throw new IllegalArgumentException("Invalid encapsulation mode " + encapsulationMode);
            }
            return this;
        }

        public @NonNull Builder setTransferMode(int mode) throws IllegalArgumentException {
            switch (mode) {
                case MODE_STREAM: case MODE_STATIC: mMode = mode; break;
                default: throw new IllegalArgumentException("Invalid transfer mode " + mode);
            }
            return this;
        }

        public @NonNull Builder setSessionId(int sessionId) throws IllegalArgumentException {
            if ((sessionId != AudioManager.AUDIO_SESSION_ID_GENERATE) && (sessionId < 1)) throw new IllegalArgumentException("Invalid audio session ID " + sessionId);
            mSessionId = sessionId;
            return this;
        }

        public @NonNull Builder setPerformanceMode(int performanceMode) {
            switch (performanceMode) {
                case PERFORMANCE_MODE_NONE: case PERFORMANCE_MODE_LOW_LATENCY: case PERFORMANCE_MODE_POWER_SAVING: mPerformanceMode = performanceMode; break;
                default: throw new IllegalArgumentException("Invalid performance mode " + performanceMode);
            }
            return this;
        }

        public @NonNull Builder setOffloadedPlayback(boolean offload) { mOffload = offload; return this; }

        public @NonNull AudioTrack build() throws UnsupportedOperationException {
            if (mAttributes == null) mAttributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build();
            switch (mPerformanceMode) {
                case PERFORMANCE_MODE_LOW_LATENCY: mAttributes = new AudioAttributes.Builder(mAttributes).replaceFlags((mAttributes.getAllFlags() | AudioAttributes.FLAG_LOW_LATENCY) & ~AudioAttributes.FLAG_DEEP_BUFFER).build(); break;
                case PERFORMANCE_MODE_NONE: if (!shouldEnablePowerSaving(mAttributes, mFormat, mBufferSizeInBytes, mMode)) break; // else fall through
                case PERFORMANCE_MODE_POWER_SAVING: mAttributes = new AudioAttributes.Builder(mAttributes).replaceFlags((mAttributes.getAllFlags() | AudioAttributes.FLAG_DEEP_BUFFER) & ~AudioAttributes.FLAG_LOW_LATENCY).build(); break;
            }
            if (mFormat == null) mFormat = new AudioFormat.Builder().setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_DEFAULT).build();
            if (mOffload) {
                if (mPerformanceMode == PERFORMANCE_MODE_LOW_LATENCY) throw new UnsupportedOperationException("Offload and low latency modes are incompatible");
                throw new UnsupportedOperationException("Cannot create AudioTrack, offload format / attributes not supported");   // the virtual device has no offload-capable output
            }
            try {
                if (mMode == MODE_STREAM && mBufferSizeInBytes == 0) {
                    // use the minimum buffer size for the stream the way the framework builder does
                    int channelCount = AudioFormat.channelCountFromOutChannelMask(mFormat.getChannelMask() == 0 ? AudioFormat.CHANNEL_OUT_STEREO : mFormat.getChannelMask());
                    int minBytes = native_get_min_buff_size(mFormat.getSampleRate() <= 0 ? 44100 : mFormat.getSampleRate(), channelCount, mFormat.getEncoding() == AudioFormat.ENCODING_INVALID ? AudioFormat.ENCODING_PCM_16BIT : mFormat.getEncoding());
                    mBufferSizeInBytes = minBytes;
                }
                final AudioTrack track = new AudioTrack(mAttributes, mFormat, mBufferSizeInBytes, mMode, mSessionId, mOffload, mEncapsulationMode);
                if (track.getState() == STATE_UNINITIALIZED) track.release(); // release is not necessary
                if (track.getState() == STATE_UNINITIALIZED) throw new UnsupportedOperationException("Cannot create AudioTrack");
                return track;
            } catch (IllegalArgumentException e) {
                throw new UnsupportedOperationException(e.getMessage());
            }
        }
    }

    private static boolean shouldEnablePowerSaving(@Nullable AudioAttributes attributes, @Nullable AudioFormat format, int bufferSizeInBytes, int mode) {
        if (attributes != null && (attributes.getAllFlags() != 0 || attributes.getUsage() != AudioAttributes.USAGE_MEDIA || (attributes.getContentType() != AudioAttributes.CONTENT_TYPE_MUSIC && attributes.getContentType() != AudioAttributes.CONTENT_TYPE_UNKNOWN))) return false;
        if (format == null || format.getSampleRate() == AudioFormat.SAMPLE_RATE_UNSPECIFIED || !AudioFormat.isEncodingLinearPcm(format.getEncoding()) || !AudioFormat.isValidEncoding(format.getEncoding()) || format.getChannelCount() < 1) return false;
        if (mode != MODE_STREAM) return false;
        if (bufferSizeInBytes != 0) {
            final long BUFFER_TARGET_MODE_STREAM_MS = 100;
            final int MILLIS_PER_SECOND = 1000;
            final long bufferTargetSize = BUFFER_TARGET_MODE_STREAM_MS * format.getChannelCount() * format.getBytesPerSample(format.getEncoding()) * format.getSampleRate() / MILLIS_PER_SECOND;
            if (bufferSizeInBytes < bufferTargetSize) return false;
        }
        return true;
    }

    // ---- parameter checks (AudioTrack.audioParamCheck / audioBuffSizeCheck) -----------------------------------------------------------------------------------------------------------------------------
    private void audioParamCheck(int sampleRateInHz, int channelConfig, int channelIndexMask, int audioFormat, int mode) {
        if ((sampleRateInHz < AudioFormat.SAMPLE_RATE_HZ_MIN || sampleRateInHz > AudioFormat.SAMPLE_RATE_HZ_MAX) && sampleRateInHz != AudioFormat.SAMPLE_RATE_UNSPECIFIED) throw new IllegalArgumentException(sampleRateInHz + "Hz is not a supported sample rate.");
        mSampleRate = sampleRateInHz;
        if (audioFormat == AudioFormat.ENCODING_IEC61937 && channelConfig != AudioFormat.CHANNEL_OUT_STEREO && AudioFormat.channelCountFromOutChannelMask(channelConfig) != 8) Log.w(TAG, "ENCODING_IEC61937 is configured with channel mask as " + channelConfig + ", which is not 2 or 8 channels");
        mChannelConfiguration = channelConfig;
        switch (channelConfig) {
            case AudioFormat.CHANNEL_OUT_DEFAULT: case AudioFormat.CHANNEL_OUT_MONO: case AudioFormat.CHANNEL_CONFIGURATION_MONO:
                mChannelCount = 1; mChannelMask = AudioFormat.CHANNEL_OUT_MONO; mChannelConfiguration = AudioFormat.CHANNEL_OUT_MONO; break;
            case AudioFormat.CHANNEL_OUT_STEREO: case AudioFormat.CHANNEL_CONFIGURATION_STEREO:
                mChannelCount = 2; mChannelMask = AudioFormat.CHANNEL_OUT_STEREO; mChannelConfiguration = AudioFormat.CHANNEL_OUT_STEREO; break;
            default:
                if (channelConfig == AudioFormat.CHANNEL_INVALID && channelIndexMask != 0) { mChannelCount = 0; break; }
                if (!isMultichannelConfigSupported(channelConfig, audioFormat)) throw new IllegalArgumentException("Unsupported channel configuration.");
                mChannelMask = channelConfig;
                mChannelCount = AudioFormat.channelCountFromOutChannelMask(channelConfig);
        }
        mChannelIndexMask = channelIndexMask;
        if (mChannelIndexMask != 0) {
            final int fullIndexMask = (1 << 24) - 1;
            final int channelIndexCount = Integer.bitCount(channelIndexMask);
            final boolean accepted = (channelIndexMask & ~fullIndexMask) == 0;
            if (!accepted) throw new IllegalArgumentException("Unsupported channel index configuration " + channelIndexMask);
            if (mChannelCount == 0) mChannelCount = channelIndexCount;
            else if (mChannelCount != channelIndexCount) throw new IllegalArgumentException("Channel count must match");
        }
        if (audioFormat == AudioFormat.ENCODING_DEFAULT) audioFormat = AudioFormat.ENCODING_PCM_16BIT;
        if (!AudioFormat.isPublicEncoding(audioFormat)) throw new IllegalArgumentException("Unsupported audio encoding.");
        mAudioFormat = audioFormat;
        if (((mode != MODE_STREAM) && (mode != MODE_STATIC)) || ((mode != MODE_STREAM) && !AudioFormat.isEncodingLinearPcm(mAudioFormat))) throw new IllegalArgumentException("Invalid mode.");
        mDataLoadMode = mode;
    }

    private static boolean isMultichannelConfigSupported(int channelConfig, int encoding) {
        if ((channelConfig & SUPPORTED_OUT_CHANNELS) != channelConfig) { loge("Channel configuration features unsupported channels"); return false; }
        final int channelCount = AudioFormat.channelCountFromOutChannelMask(channelConfig);
        if (channelCount > 24) { loge("Channel configuration contains too many channels " + channelCount + ">" + 24); return false; }
        if ((channelConfig & (AudioFormat.CHANNEL_OUT_FRONT_LEFT | AudioFormat.CHANNEL_OUT_FRONT_RIGHT)) != (AudioFormat.CHANNEL_OUT_FRONT_LEFT | AudioFormat.CHANNEL_OUT_FRONT_RIGHT)) { loge("Front channels must be present in multichannel configurations"); return false; }
        final int backPair = AudioFormat.CHANNEL_OUT_BACK_LEFT | AudioFormat.CHANNEL_OUT_BACK_RIGHT;
        if ((channelConfig & backPair) != 0 && (channelConfig & backPair) != backPair) { loge("Rear channels can't be used independently"); return false; }
        final int sidePair = AudioFormat.CHANNEL_OUT_SIDE_LEFT | AudioFormat.CHANNEL_OUT_SIDE_RIGHT;
        if ((channelConfig & sidePair) != 0 && (channelConfig & sidePair) != sidePair) { loge("Side channels can't be used independently"); return false; }
        return true;
    }

    private void audioBuffSizeCheck(int audioBufferSize) {
        int frameSizeInBytes;
        if (AudioFormat.isEncodingLinearFrames(mAudioFormat)) frameSizeInBytes = mChannelCount * AudioFormat.getBytesPerSample(mAudioFormat);
        else frameSizeInBytes = 1;
        if ((audioBufferSize % frameSizeInBytes != 0) || (audioBufferSize < 1)) throw new IllegalArgumentException("Invalid audio buffer size.");
        mNativeBufferSizeInBytes = audioBufferSize;
        mNativeBufferSizeInFrames = audioBufferSize / frameSizeInBytes;
    }

    // ---- lifecycle ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public void release() {
        try { stop(); } catch (IllegalStateException ise) { /* don't raise an exception, we're releasing the resources. */ }
        native_release();
        synchronized (mPlayStateLock) {
            mState = STATE_UNINITIALIZED;
            mPlayState = PLAYSTATE_STOPPED;
            mPlayStateLock.notify();
        }
    }

    @Override protected void finalize() throws Throwable { native_finalize(); }

    public static float getMinVolume() { return GAIN_MIN; }
    public static float getMaxVolume() { return GAIN_MAX; }
    public int getSampleRate() { return mSampleRate; }
    public int getPlaybackRate() { return native_get_playback_rate(); }
    public int getAudioFormat() { return mAudioFormat; }
    public int getStreamType() { return mStreamType; }
    public int getChannelConfiguration() { return mChannelConfiguration; }
    public AudioFormat getFormat() {
        AudioFormat.Builder builder = new AudioFormat.Builder().setSampleRate(mSampleRate).setEncoding(mAudioFormat);
        if (mChannelConfiguration != AudioFormat.CHANNEL_INVALID) builder.setChannelMask(mChannelConfiguration);
        if (mChannelIndexMask != AudioFormat.CHANNEL_INVALID) builder.setChannelIndexMask(mChannelIndexMask);
        return builder.build();
    }
    public int getChannelCount() { return mChannelCount; }
    public int getState() { return mState; }
    public int getPlayState() {
        synchronized (mPlayStateLock) {
            switch (mPlayState) {
                case PLAYSTATE_STOPPING: return PLAYSTATE_PLAYING;
                case PLAYSTATE_PAUSED_STOPPING: return PLAYSTATE_PAUSED;
                default: return mPlayState;
            }
        }
    }
    public int getBufferSizeInFrames() { return native_get_buffer_size_frames(); }
    public int setBufferSizeInFrames(int bufferSizeInFrames) {
        if (mDataLoadMode == MODE_STATIC || mState == STATE_UNINITIALIZED) return ERROR_INVALID_OPERATION;
        if (bufferSizeInFrames < 0) return ERROR_BAD_VALUE;
        return native_set_buffer_size_frames(bufferSizeInFrames);
    }
    public int getBufferCapacityInFrames() { return native_get_buffer_capacity_frames(); }
    @Deprecated protected int getNativeFrameCount() { return native_get_buffer_capacity_frames(); }
    public int getNotificationMarkerPosition() { return native_get_marker_pos(); }
    public int getPositionNotificationPeriod() { return native_get_pos_update_period(); }
    public int getPlaybackHeadPosition() { return native_get_position(); }
    public int getUnderrunCount() { return native_get_underrun_count(); }
    public int getPerformanceMode() {
        final int flags = native_get_flags();
        if ((flags & AudioAttributes.FLAG_LOW_LATENCY) != 0) return PERFORMANCE_MODE_LOW_LATENCY;
        else if ((flags & AudioAttributes.FLAG_DEEP_BUFFER) != 0) return PERFORMANCE_MODE_POWER_SAVING;
        else return PERFORMANCE_MODE_NONE;
    }
    public static int getNativeOutputSampleRate(int streamType) { return native_get_output_sample_rate(streamType); }

    public static int getMinBufferSize(int sampleRateInHz, int channelConfig, int audioFormat) {
        int channelCount = 0;
        switch (channelConfig) {
            case AudioFormat.CHANNEL_OUT_DEFAULT: case AudioFormat.CHANNEL_OUT_MONO: case AudioFormat.CHANNEL_CONFIGURATION_MONO: channelCount = 1; break;
            case AudioFormat.CHANNEL_OUT_STEREO: case AudioFormat.CHANNEL_CONFIGURATION_STEREO: channelCount = 2; break;
            default:
                if (!isMultichannelConfigSupported(channelConfig, audioFormat)) { loge("getMinBufferSize(): Invalid channel configuration."); return ERROR_BAD_VALUE; }
                channelCount = AudioFormat.channelCountFromOutChannelMask(channelConfig);
        }
        if (!AudioFormat.isPublicEncoding(audioFormat)) { loge("getMinBufferSize(): Invalid audio format."); return ERROR_BAD_VALUE; }
        if ((sampleRateInHz < AudioFormat.SAMPLE_RATE_HZ_MIN) || (sampleRateInHz > AudioFormat.SAMPLE_RATE_HZ_MAX)) { loge("getMinBufferSize(): " + sampleRateInHz + " Hz is not a supported sample rate."); return ERROR_BAD_VALUE; }
        int size = native_get_min_buff_size(sampleRateInHz, channelCount, audioFormat);
        if (size <= 0) { loge("getMinBufferSize(): error querying hardware"); return ERROR; }
        return size;
    }

    public int getAudioSessionId() { return mSessionId; }
    @Deprecated public AudioAttributes getAudioAttributes() throws IllegalStateException {
        if (mState == STATE_UNINITIALIZED || mAttributes == null) throw new IllegalStateException("track not initialized");
        return mAttributes;
    }
    public boolean getTimestamp(AudioTimestamp timestamp) {
        if (timestamp == null) throw new IllegalArgumentException();
        long[] longArray = new long[2];
        int ret = native_get_timestamp(longArray);
        if (ret != SUCCESS) return false;
        timestamp.framePosition = longArray[0];
        timestamp.nanoTime = longArray[1];
        return true;
    }

    // ---- listeners and notification positions ----------------------------------------------------------------------------------------------------------------------------------------------------------
    public void setPlaybackPositionUpdateListener(OnPlaybackPositionUpdateListener listener) { setPlaybackPositionUpdateListener(listener, null); }
    public void setPlaybackPositionUpdateListener(OnPlaybackPositionUpdateListener listener, Handler handler) {
        if (listener != null) mEventHandlerDelegate = new NativeEventHandlerDelegate(this, handler, mInitializationLooper);
        else mEventHandlerDelegate = null;
        synchronized (mPositionListenerLock) { mPositionListener = listener; }
    }
    public int setNotificationMarkerPosition(int markerInFrames) {
        if (mState == STATE_UNINITIALIZED) return ERROR_INVALID_OPERATION;
        return native_set_marker_pos(markerInFrames);
    }
    public int setPositionNotificationPeriod(int periodInFrames) {
        if (mState == STATE_UNINITIALIZED) return ERROR_INVALID_OPERATION;
        return native_set_pos_update_period(periodInFrames);
    }
    public int reloadStaticData() {
        if (mDataLoadMode == MODE_STREAM || mState != STATE_INITIALIZED) return ERROR_INVALID_OPERATION;
        return native_reload_static();
    }
    public int setPlaybackHeadPosition(int positionInFrames) {
        if (mDataLoadMode == MODE_STREAM || mState == STATE_UNINITIALIZED || getPlayState() == PLAYSTATE_PLAYING) return ERROR_INVALID_OPERATION;
        return native_set_position(positionInFrames);
    }
    public int setLoopPoints(int startInFrames, int endInFrames, int loopCount) {
        if (mDataLoadMode == MODE_STREAM || mState == STATE_UNINITIALIZED || getPlayState() == PLAYSTATE_PLAYING) return ERROR_INVALID_OPERATION;
        if (loopCount == 0) { ; /* explicitly allowed as an exception to the loop region range check */ }
        else if (!(0 <= startInFrames && startInFrames < mNativeBufferSizeInFrames && startInFrames < endInFrames && endInFrames <= mNativeBufferSizeInFrames)) return ERROR_BAD_VALUE;
        return native_set_loop(startInFrames, endInFrames, loopCount);
    }

    public int setPlaybackRate(int sampleRateInHz) {
        if (mState != STATE_INITIALIZED) return ERROR_INVALID_OPERATION;
        if (sampleRateInHz <= 0) return ERROR_BAD_VALUE;
        return native_set_playback_rate(sampleRateInHz);
    }
    public void setPlaybackParams(@NonNull PlaybackParams params) {
        if (params == null) throw new IllegalArgumentException("params is null");
        if (mState == STATE_UNINITIALIZED) throw new IllegalStateException("track not initialized");
        float speed = params.getSpeed();
        if (speed <= 0f) throw new IllegalArgumentException("playback params: speed must be positive");
        if (params.getPitch() <= 0f) throw new IllegalArgumentException("playback params: pitch must be positive");
        mPlaybackParams = new PlaybackParams(); mPlaybackParams.setSpeed(speed).setPitch(params.getPitch());
        native_set_playback_speed(speed);
    }
    public @NonNull PlaybackParams getPlaybackParams() { if (mState == STATE_UNINITIALIZED) throw new IllegalStateException("track not initialized"); PlaybackParams copy = new PlaybackParams(); copy.setSpeed(mPlaybackParams.getSpeed()).setPitch(mPlaybackParams.getPitch()); return copy; }

    // ---- volume ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    @Deprecated public int setStereoVolume(float leftGain, float rightGain) {
        if (mState == STATE_UNINITIALIZED) return ERROR_INVALID_OPERATION;
        mLeftVolume = clamp(leftGain); mRightVolume = clamp(rightGain);
        native_setVolume(mLeftVolume, mRightVolume);
        return SUCCESS;
    }
    public int setVolume(float gain) { return setStereoVolume(gain, gain); }
    private static float clamp(float v) { return v < GAIN_MIN ? GAIN_MIN : (v > GAIN_MAX ? GAIN_MAX : v); }
    public int setAuxEffectSendLevel(float level) {
        if (mState == STATE_UNINITIALIZED) return ERROR_INVALID_OPERATION;
        return level < 0.0f ? ERROR_BAD_VALUE : ERROR_INVALID_OPERATION;       // no effects exist to send to
    }
    public int attachAuxEffect(int effectId) {
        if (mState == STATE_UNINITIALIZED) return ERROR_INVALID_OPERATION;
        return ERROR_INVALID_OPERATION;                                        // android.media.audiofx is not part of the virtual device
    }

    // ---- transport -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public void play() throws IllegalStateException {
        if (mState != STATE_INITIALIZED) throw new IllegalStateException("play() called on uninitialized AudioTrack.");
        synchronized (mPlayStateLock) {
            native_start();
            if (mPlayState == PLAYSTATE_PAUSED_STOPPING) mPlayState = PLAYSTATE_STOPPING; else mPlayState = PLAYSTATE_PLAYING;
        }
    }
    public void stop() throws IllegalStateException {
        if (mState != STATE_INITIALIZED) throw new IllegalStateException("stop() called on uninitialized AudioTrack.");
        synchronized (mPlayStateLock) {
            native_stop();
            mPlayState = PLAYSTATE_STOPPED;
            mPlayStateLock.notify();
        }
    }
    public void pause() throws IllegalStateException {
        if (mState != STATE_INITIALIZED) throw new IllegalStateException("pause() called on uninitialized AudioTrack.");
        synchronized (mPlayStateLock) {
            native_pause();
            if (mPlayState == PLAYSTATE_STOPPING) mPlayState = PLAYSTATE_PAUSED_STOPPING; else mPlayState = PLAYSTATE_PAUSED;
        }
    }
    public void flush() { if (mState == STATE_INITIALIZED) native_flush(); }

    // ---- writes ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public int write(@NonNull byte[] audioData, int offsetInBytes, int sizeInBytes) { return write(audioData, offsetInBytes, sizeInBytes, WRITE_BLOCKING); }
    public int write(@NonNull byte[] audioData, int offsetInBytes, int sizeInBytes, int writeMode) {
        if (mState == STATE_UNINITIALIZED || mAudioFormat == AudioFormat.ENCODING_PCM_FLOAT) return ERROR_INVALID_OPERATION;
        if ((writeMode != WRITE_BLOCKING) && (writeMode != WRITE_NON_BLOCKING)) { Log.e(TAG, "AudioTrack.write() called with invalid blocking mode"); return ERROR_BAD_VALUE; }
        if ((audioData == null) || (offsetInBytes < 0) || (sizeInBytes < 0) || (offsetInBytes + sizeInBytes < 0) || (offsetInBytes + sizeInBytes > audioData.length)) return ERROR_BAD_VALUE;
        final int ret = native_write_byte(audioData, offsetInBytes, sizeInBytes, mAudioFormat, writeMode == WRITE_BLOCKING);
        if ((mDataLoadMode == MODE_STATIC) && (mState == STATE_NO_STATIC_DATA) && (ret > 0)) mState = STATE_INITIALIZED;
        return ret;
    }
    public int write(@NonNull short[] audioData, int offsetInShorts, int sizeInShorts) { return write(audioData, offsetInShorts, sizeInShorts, WRITE_BLOCKING); }
    public int write(@NonNull short[] audioData, int offsetInShorts, int sizeInShorts, int writeMode) {
        if (mState == STATE_UNINITIALIZED || mAudioFormat == AudioFormat.ENCODING_PCM_FLOAT) return ERROR_INVALID_OPERATION;
        if ((writeMode != WRITE_BLOCKING) && (writeMode != WRITE_NON_BLOCKING)) { Log.e(TAG, "AudioTrack.write() called with invalid blocking mode"); return ERROR_BAD_VALUE; }
        if ((audioData == null) || (offsetInShorts < 0) || (sizeInShorts < 0) || (offsetInShorts + sizeInShorts < 0) || (offsetInShorts + sizeInShorts > audioData.length)) return ERROR_BAD_VALUE;
        final int ret = native_write_short(audioData, offsetInShorts, sizeInShorts, mAudioFormat, writeMode == WRITE_BLOCKING);
        if ((mDataLoadMode == MODE_STATIC) && (mState == STATE_NO_STATIC_DATA) && (ret > 0)) mState = STATE_INITIALIZED;
        return ret;
    }
    public int write(@NonNull float[] audioData, int offsetInFloats, int sizeInFloats, int writeMode) {
        if (mState == STATE_UNINITIALIZED) { Log.e(TAG, "AudioTrack.write() called in invalid state STATE_UNINITIALIZED"); return ERROR_INVALID_OPERATION; }
        if (mAudioFormat != AudioFormat.ENCODING_PCM_FLOAT) { Log.e(TAG, "AudioTrack.write(float[] ...) requires format ENCODING_PCM_FLOAT"); return ERROR_INVALID_OPERATION; }
        if ((writeMode != WRITE_BLOCKING) && (writeMode != WRITE_NON_BLOCKING)) { Log.e(TAG, "AudioTrack.write() called with invalid blocking mode"); return ERROR_BAD_VALUE; }
        if ((audioData == null) || (offsetInFloats < 0) || (sizeInFloats < 0) || (offsetInFloats + sizeInFloats < 0) || (offsetInFloats + sizeInFloats > audioData.length)) { Log.e(TAG, "AudioTrack.write() called with invalid array, offset, or size"); return ERROR_BAD_VALUE; }
        final int ret = native_write_float(audioData, offsetInFloats, sizeInFloats, mAudioFormat, writeMode == WRITE_BLOCKING);
        if ((mDataLoadMode == MODE_STATIC) && (mState == STATE_NO_STATIC_DATA) && (ret > 0)) mState = STATE_INITIALIZED;
        return ret;
    }
    public int write(@NonNull ByteBuffer audioData, int sizeInBytes, int writeMode) {
        if (mState == STATE_UNINITIALIZED) { Log.e(TAG, "AudioTrack.write() called in invalid state STATE_UNINITIALIZED"); return ERROR_INVALID_OPERATION; }
        if ((writeMode != WRITE_BLOCKING) && (writeMode != WRITE_NON_BLOCKING)) { Log.e(TAG, "AudioTrack.write() called with invalid blocking mode"); return ERROR_BAD_VALUE; }
        if ((audioData == null) || (sizeInBytes < 0) || (sizeInBytes > audioData.remaining())) { Log.e(TAG, "AudioTrack.write() called with invalid size (" + sizeInBytes + ") value"); return ERROR_BAD_VALUE; }
        int ret;
        if (audioData.isDirect()) ret = native_write_native_bytes(audioData, audioData.position(), sizeInBytes, mAudioFormat, writeMode == WRITE_BLOCKING);
        else { byte[] copy = new byte[sizeInBytes]; int position = audioData.position(); audioData.get(copy); audioData.position(position); ret = native_write_byte(copy, 0, sizeInBytes, mAudioFormat, writeMode == WRITE_BLOCKING); }
        if ((mDataLoadMode == MODE_STATIC) && (mState == STATE_NO_STATIC_DATA) && (ret > 0)) mState = STATE_INITIALIZED;
        if (ret > 0) audioData.position(audioData.position() + ret);
        return ret;
    }
    public int write(@NonNull ByteBuffer audioData, int sizeInBytes, int writeMode, long timestamp) {
        if (mState == STATE_UNINITIALIZED) return ERROR_INVALID_OPERATION;
        if (mAttributes.getFlags() == 0 || (mAttributes.getFlags() & AudioAttributes.FLAG_HW_AV_SYNC) == 0) { Log.d(TAG, "AudioTrack.write() called on a regular AudioTrack. Ignoring pts..."); return write(audioData, sizeInBytes, writeMode); }
        return ERROR_INVALID_OPERATION;                                           // hardware A/V sync tracks do not exist on the virtual device
    }

    // ---- routing, metrics, remaining API surface -------------------------------------------------------------------------------------------------------------------------------------------------------------
    @Override public boolean setPreferredDevice(AudioDeviceInfo deviceInfo) {
        if (deviceInfo != null && !deviceInfo.isSink()) return false;
        mPreferredDevice = deviceInfo;
        return true;
    }
    @Override public AudioDeviceInfo getPreferredDevice() { return mPreferredDevice; }
    @Override public AudioDeviceInfo getRoutedDevice() { return AudioManagerDevices.builtInSpeaker(); }
    @Override public void addOnRoutingChangedListener(AudioRouting.OnRoutingChangedListener listener, Handler handler) {
        if (listener == null) throw new IllegalArgumentException("Illegal null AudioRouting.OnRoutingChangedListener");
        synchronized (mRoutingListeners) { for (RoutingListener l : mRoutingListeners) if (l.listener == listener) return; mRoutingListeners.add(new RoutingListener(listener)); }
    }
    @Override public void removeOnRoutingChangedListener(AudioRouting.OnRoutingChangedListener listener) {
        synchronized (mRoutingListeners) { for (int i = 0; i < mRoutingListeners.size(); i++) if (mRoutingListeners.get(i).listener == listener) { mRoutingListeners.remove(i); return; } }
    }
    private static final class RoutingListener { final AudioRouting.OnRoutingChangedListener listener; RoutingListener(AudioRouting.OnRoutingChangedListener l) { listener = l; } }
    public void addOnRoutingChangedListener(AudioRouting.OnRoutingChangedListener listener, android.os.Handler handler, boolean ignored) { addOnRoutingChangedListener(listener, handler); }

    public PersistableBundle getMetrics() {
        PersistableBundle bundle = new PersistableBundle();
        bundle.putString("android.media.audiotrack.streamtype", "USAGE_" + mAttributes.getUsage());
        bundle.putInt("android.media.audiotrack.samplerate", mSampleRate);
        bundle.putLong("android.media.audiotrack.channelmask", mChannelMask);
        return bundle;
    }
    public void setOffloadDelayPadding(int delayInFrames, int paddingInFrames) { throw new IllegalStateException("Cannot set delay and padding on a non-offloaded track"); }
    public void setOffloadEndOfStream() { throw new IllegalStateException("EOS not supported on non-offloaded track"); }
    public int getOffloadDelay() { throw new IllegalStateException("Cannot get delay on a non-offloaded track"); }
    public int getOffloadPadding() { throw new IllegalStateException("Cannot get padding on a non-offloaded track"); }
    public static boolean isDirectPlaybackSupported(@NonNull AudioFormat format, @NonNull AudioAttributes attributes) {
        if (format == null) throw new IllegalArgumentException("Illegal null AudioFormat argument");
        if (attributes == null) throw new IllegalArgumentException("Illegal null AudioAttributes argument");
        return false;
    }
    public boolean isOffloadedPlayback() { return false; }
    public static boolean isOffloadedPlaybackSupported(@NonNull AudioFormat format, @NonNull AudioAttributes attributes) {
        if (format == null) throw new NullPointerException("Illegal null AudioFormat");
        if (attributes == null) throw new NullPointerException("Illegal null AudioAttributes");
        return false;
    }
    public boolean setPreferredMicrophoneDirection() { return false; }

    // ---- notification events -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public interface OnPlaybackPositionUpdateListener {
        void onMarkerReached(AudioTrack track);
        void onPeriodicNotification(AudioTrack track);
    }

    private class NativeEventHandlerDelegate {
        private final Handler mHandler;
        NativeEventHandlerDelegate(final AudioTrack track, Handler handler, Looper initializationLooper) {
            Looper looper;
            if (handler != null) looper = handler.getLooper(); else looper = initializationLooper;
            if (looper != null) {
                mHandler = new Handler(looper) {
                    @Override public void handleMessage(Message msg) {
                        if (track == null) return;
                        OnPlaybackPositionUpdateListener listener = null;
                        synchronized (mPositionListenerLock) { listener = mPositionListener; }
                        switch (msg.what) {
                            case NATIVE_EVENT_MARKER: if (listener != null) listener.onMarkerReached(track); break;
                            case NATIVE_EVENT_NEW_POS: if (listener != null) listener.onPeriodicNotification(track); break;
                            default: loge("Unknown native event type: " + msg.what); break;
                        }
                    }
                };
            } else mHandler = null;
        }
        Handler getHandler() { return mHandler; }
    }

    /** Called by the host mixer on the VM clock: a marker or periodic position was reached. */
    private void postEventFromHost(int what) {
        NativeEventHandlerDelegate delegate = mEventHandlerDelegate;
        if (delegate == null) return;
        Handler handler = delegate.getHandler();
        if (handler != null) handler.sendMessage(handler.obtainMessage(what, 0, 0, null));
    }

    // ---- host mixer (src/audio-native.js) ------------------------------------------------------------------------------------------------------------------------------------------------------------------
    private native int native_setup(Object weakSelf, int usage, int contentType, int[] sampleRate, int channelCount, int audioFormat, int buffSizeInBytes, int mode, int[] sessionId);
    private final native void native_finalize();
    private final native void native_release();
    private final native void native_start();
    private final native void native_stop();
    private final native void native_pause();
    private final native void native_flush();
    private final native int native_write_byte(byte[] audioData, int offsetInBytes, int sizeInBytes, int format, boolean isBlocking);
    private final native int native_write_short(short[] audioData, int offsetInShorts, int sizeInShorts, int format, boolean isBlocking);
    private final native int native_write_float(float[] audioData, int offsetInFloats, int sizeInFloats, int format, boolean isBlocking);
    private final native int native_write_native_bytes(ByteBuffer audioData, int positionInBytes, int sizeInBytes, int format, boolean blocking);
    private final native int native_get_buffer_size_frames();
    private final native int native_set_buffer_size_frames(int bufferSizeInFrames);
    private final native int native_get_buffer_capacity_frames();
    private final native void native_setVolume(float leftVolume, float rightVolume);
    private final native int native_set_playback_rate(int sampleRateInHz);
    private final native int native_get_playback_rate();
    private final native void native_set_playback_speed(float speed);
    private final native int native_set_marker_pos(int marker);
    private final native int native_get_marker_pos();
    private final native int native_set_pos_update_period(int updatePeriod);
    private final native int native_get_pos_update_period();
    private final native int native_set_position(int position);
    private final native int native_get_position();
    private final native int native_get_latency();
    private final native int native_get_underrun_count();
    private final native int native_get_flags();
    private final native int native_get_timestamp(long[] longArray);
    private final native int native_set_loop(int start, int end, int loopCount);
    private final native int native_reload_static();
    private static native int native_get_output_sample_rate(int streamType);
    private static native int native_get_min_buff_size(int sampleRateInHz, int channelCount, int audioFormat);
}
