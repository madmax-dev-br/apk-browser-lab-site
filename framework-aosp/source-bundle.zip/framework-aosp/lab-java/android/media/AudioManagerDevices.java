package android.media;

/** The built-in output the virtual device routes every AudioTrack to (the host mixer has one sink: the page's Web Audio output). Constructed here because AudioDeviceInfo's constructor is package-private. */
public final class AudioManagerDevices {
    private AudioManagerDevices() { }
    private static AudioDeviceInfo sSpeaker, sEarpiece, sMic;
    private static final int[] RATES = {8000, 11025, 16000, 22050, 32000, 44100, 48000};
    private static final int[] OUT_MASKS = {AudioFormat.CHANNEL_OUT_MONO, AudioFormat.CHANNEL_OUT_STEREO};
    private static final int[] IN_MASKS = {AudioFormat.CHANNEL_IN_MONO, AudioFormat.CHANNEL_IN_STEREO};
    private static final int[] ENCODINGS = {AudioFormat.ENCODING_PCM_16BIT, AudioFormat.ENCODING_PCM_FLOAT, AudioFormat.ENCODING_PCM_8BIT};

    public static synchronized AudioDeviceInfo builtInSpeaker() { if (sSpeaker == null) sSpeaker = new AudioDeviceInfo(2, AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, "Built-in Speaker", false, "", RATES, OUT_MASKS, ENCODINGS); return sSpeaker; }
    public static synchronized AudioDeviceInfo builtInEarpiece() { if (sEarpiece == null) sEarpiece = new AudioDeviceInfo(3, AudioDeviceInfo.TYPE_BUILTIN_EARPIECE, "Built-in Earpiece", false, "", RATES, OUT_MASKS, ENCODINGS); return sEarpiece; }
    public static synchronized AudioDeviceInfo builtInMic() { if (sMic == null) sMic = new AudioDeviceInfo(4, AudioDeviceInfo.TYPE_BUILTIN_MIC, "Built-in Microphone", true, "bottom", RATES, IN_MASKS, ENCODINGS); return sMic; }
}
