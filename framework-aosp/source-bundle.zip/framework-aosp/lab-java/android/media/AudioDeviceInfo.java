package android.media;

import android.annotation.NonNull;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

/**
 * android.media.AudioDeviceInfo (API 33 public surface) for the virtual device. The framework class wraps a hidden AudioDevicePort handed over by the audio service; the virtual device has
 * no audio service, so a device is described directly by the host (src/audio-host.js): the built-in speaker and earpiece as sinks, the built-in microphone as the source.
 */
public final class AudioDeviceInfo {
    public static final int TYPE_UNKNOWN = 0, TYPE_BUILTIN_EARPIECE = 1, TYPE_BUILTIN_SPEAKER = 2, TYPE_WIRED_HEADSET = 3, TYPE_WIRED_HEADPHONES = 4, TYPE_LINE_ANALOG = 5, TYPE_LINE_DIGITAL = 6,
        TYPE_BLUETOOTH_SCO = 7, TYPE_BLUETOOTH_A2DP = 8, TYPE_HDMI = 9, TYPE_HDMI_ARC = 10, TYPE_USB_DEVICE = 11, TYPE_USB_ACCESSORY = 12, TYPE_DOCK = 13, TYPE_FM = 14, TYPE_BUILTIN_MIC = 15,
        TYPE_FM_TUNER = 16, TYPE_TV_TUNER = 17, TYPE_TELEPHONY = 18, TYPE_AUX_LINE = 19, TYPE_IP = 20, TYPE_BUS = 21, TYPE_USB_HEADSET = 22, TYPE_HEARING_AID = 23, TYPE_BUILTIN_SPEAKER_SAFE = 24,
        TYPE_REMOTE_SUBMIX = 25, TYPE_BLE_HEADSET = 26, TYPE_BLE_SPEAKER = 27, TYPE_ECHO_REFERENCE = 28, TYPE_HDMI_EARC = 29, TYPE_BLE_BROADCAST = 30;

    private final int mId, mType;
    private final boolean mIsSource;
    private final String mName, mAddress;
    private final int[] mSampleRates, mChannelMasks, mEncodings;

    /** @hide Built by the host. */
    AudioDeviceInfo(int id, int type, String name, boolean isSource, String address, int[] sampleRates, int[] channelMasks, int[] encodings) {
        mId = id; mType = type; mName = name; mIsSource = isSource; mAddress = address == null ? "" : address;
        mSampleRates = sampleRates; mChannelMasks = channelMasks; mEncodings = encodings;
    }

    public int getId() { return mId; }
    public CharSequence getProductName() { return mName; }
    public String getAddress() { return mAddress; }
    public boolean isSource() { return mIsSource; }
    public boolean isSink() { return !mIsSource; }
    public int[] getSampleRates() { return mSampleRates.clone(); }
    public int[] getChannelMasks() { return mChannelMasks.clone(); }
    public int[] getChannelIndexMasks() { return new int[0]; }
    public int[] getChannelCounts() {
        TreeSet<Integer> counts = new TreeSet<Integer>();
        for (int mask : mChannelMasks) counts.add(mIsSource ? AudioFormat.channelCountFromInChannelMask(mask) : AudioFormat.channelCountFromOutChannelMask(mask));
        int[] result = new int[counts.size()]; int i = 0; for (int count : counts) result[i++] = count; return result;
    }
    public int[] getEncodings() { return mEncodings.clone(); }
    public @NonNull List<Object> getAudioProfiles() { return java.util.Collections.emptyList(); }
    public int getType() { return mType; }

    /** Whether the type is an output the user can hear (AudioDeviceInfo.isSink() for the public sink types). */
    public static boolean isValidAudioDeviceTypeOut(int type) { return type >= TYPE_BUILTIN_EARPIECE && type <= TYPE_BLE_BROADCAST && type != TYPE_BUILTIN_MIC && type != TYPE_FM_TUNER && type != TYPE_TV_TUNER && type != TYPE_ECHO_REFERENCE; }
    public static boolean isValidAudioDeviceTypeIn(int type) { return type == TYPE_BUILTIN_MIC || type == TYPE_WIRED_HEADSET || type == TYPE_BLUETOOTH_SCO || type == TYPE_HDMI || type == TYPE_USB_DEVICE || type == TYPE_USB_HEADSET || type == TYPE_FM_TUNER || type == TYPE_TV_TUNER || type == TYPE_TELEPHONY || type == TYPE_LINE_ANALOG || type == TYPE_LINE_DIGITAL || type == TYPE_AUX_LINE || type == TYPE_IP || type == TYPE_BUS || type == TYPE_REMOTE_SUBMIX || type == TYPE_BLE_HEADSET || type == TYPE_HDMI_ARC || type == TYPE_HDMI_EARC || type == TYPE_ECHO_REFERENCE || type == TYPE_DOCK; }

    @Override public boolean equals(Object o) { return o instanceof AudioDeviceInfo && ((AudioDeviceInfo) o).mId == mId && ((AudioDeviceInfo) o).mType == mType; }
    @Override public int hashCode() { return Arrays.hashCode(new int[] {mId, mType}); }
}
