package android.media.audiopolicy;

import android.media.AudioAttributes;
import java.util.Collections;
import java.util.List;

/** The virtual device has no audio policy service, so it reports no product strategies: AudioAttributes then uses its documented legacy usage/stream mapping. */
public final class AudioProductStrategy {
    private AudioProductStrategy() { }
    public static List<AudioProductStrategy> getAudioProductStrategies() { return Collections.emptyList(); }
    public static AudioAttributes getAudioAttributesForStrategyWithLegacyStreamType(int streamType) { return null; }
    public static int getLegacyStreamTypeForStrategyWithAudioAttributes(AudioAttributes aa) { return -1; }
}
