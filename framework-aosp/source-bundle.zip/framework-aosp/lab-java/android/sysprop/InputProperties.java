package android.sysprop;

import java.util.Optional;

/**
 * Generated system-property accessors of the input stack (android.sysprop.InputProperties). The web device sets none of these properties, so every accessor reports "unset"
 * exactly like a build without the property: the touch VelocityTracker then uses its default strategy.
 */
public final class InputProperties {
    private InputProperties() {}
    public static Optional<String> velocitytracker_strategy() { return Optional.empty(); }
    public static Optional<Boolean> debuggable() { return Optional.empty(); }
}
