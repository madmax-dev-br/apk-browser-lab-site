package android.os;

import android.system.ErrnoException;
import android.system.OsConstants;

import java.io.FileDescriptor;
import java.nio.ByteBuffer;

/**
 * Lab implementation of android.os.SharedMemory (android-13.0.0_r1 API contract). The platform class maps an ashmem file descriptor with mmap; the virtual device has one process and no
 * ashmem driver, so a region is a byte array and every mapping is a view of it: all mappings of one SharedMemory see each other's writes, a read-only mapping rejects writes
 * (ReadOnlyBufferException), setProtect narrows the protection that later map calls may ask for, and close() invalidates the region. Handing the region to another process (Parcel,
 * getFileDescriptor, fromFileDescriptor) needs a real file descriptor and fails explicitly.
 */
public final class SharedMemory implements Parcelable, java.io.Closeable {
    private final String mName;
    private final byte[] mData;
    private int mProt = OsConstants.PROT_READ | OsConstants.PROT_WRITE | OsConstants.PROT_EXEC;
    private boolean mClosed;
    private int mMapCount;

    private SharedMemory(String name, int size) {
        mName = name;
        mData = new byte[size];
    }

    /** Creates an unnamed or named region of the given size. */
    public static SharedMemory create(String name, int size) throws ErrnoException {
        if (size <= 0) {
            throw new IllegalArgumentException("Size must be greater than zero");
        }
        return new SharedMemory(name, size);
    }

    public static SharedMemory fromFileDescriptor(android.os.ParcelFileDescriptor fd) throws ErrnoException {
        throw new UnsupportedOperationException("SharedMemory.fromFileDescriptor: the virtual device has no ashmem file descriptors");
    }

    public FileDescriptor getFileDescriptor() {
        throw new UnsupportedOperationException("SharedMemory.getFileDescriptor: the virtual device has no ashmem file descriptors");
    }

    public int getSize() {
        checkOpen();
        return mData.length;
    }

    public boolean setProtect(int prot) {
        checkOpen();
        // ashmem only allows removing permissions
        if ((prot & ~mProt) != 0) {
            return false;
        }
        mProt = prot;
        return true;
    }

    public ByteBuffer mapReadWrite() throws ErrnoException {
        return map(OsConstants.PROT_READ | OsConstants.PROT_WRITE, 0, getSize());
    }

    public ByteBuffer mapReadOnly() throws ErrnoException {
        return map(OsConstants.PROT_READ, 0, getSize());
    }

    public ByteBuffer map(int prot, int offset, int length) throws ErrnoException {
        checkOpen();
        validateProt(prot);
        if (offset < 0) {
            throw new IllegalArgumentException("Offset must be >= 0");
        }
        if (length <= 0) {
            throw new IllegalArgumentException("Length must be > 0");
        }
        if (offset + length > mData.length) {
            throw new IllegalArgumentException("offset + length must not exceed getSize()");
        }
        if ((prot & mProt) != prot) {
            throw new ErrnoException("SharedMemory.map() failed", OsConstants.EPERM);
        }
        ByteBuffer view = ByteBuffer.wrap(mData, offset, length).slice();
        mMapCount++;
        return (prot & OsConstants.PROT_WRITE) != 0 ? view : view.asReadOnlyBuffer();
    }

    /** Releases a mapping returned by map(); the byte-array views need no unmapping. */
    public static void unmap(ByteBuffer buffer) {
        if (buffer == null) {
            throw new IllegalArgumentException("buffer must not be null");
        }
    }

    @Override
    public void close() {
        mClosed = true;
    }

    private void checkOpen() {
        if (mClosed) {
            throw new IllegalStateException("SharedMemory is closed");
        }
    }

    private static void validateProt(int prot) {
        if (prot != OsConstants.PROT_NONE && (prot & ~(OsConstants.PROT_READ | OsConstants.PROT_WRITE | OsConstants.PROT_EXEC)) != 0) {
            throw new IllegalArgumentException("Invalid prot value");
        }
    }

    @Override
    public int describeContents() {
        return Parcelable.CONTENTS_FILE_DESCRIPTOR;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        throw new UnsupportedOperationException("SharedMemory.writeToParcel: the virtual device has no ashmem file descriptors");
    }

    public static final Parcelable.Creator<SharedMemory> CREATOR = new Parcelable.Creator<SharedMemory>() {
        @Override
        public SharedMemory createFromParcel(Parcel source) {
            throw new UnsupportedOperationException("SharedMemory.CREATOR: the virtual device has no ashmem file descriptors");
        }

        @Override
        public SharedMemory[] newArray(int size) {
            return new SharedMemory[size];
        }
    };
}
