package android.view.accessibility;

import android.os.Bundle;
import android.os.IBinder;
import java.util.Collections;
import java.util.List;

/**
 * The client side of the accessibility interaction connection (AccessibilityNodeInfo.refresh/getParent/getChild/performAction ask it to cross to the process that owns the
 * node). The original class talks AIDL to the system's accessibility service. The web device runs one process and nodes created by an app are its own: an
 * AccessibilityNodeInfo that was not obtained from a connection (connection id UNDEFINED_CONNECTION_ID, which is every node the framework or an app builds here) has nothing
 * to ask, and the original answers exactly like the lookups below do when no connection exists: null / false / empty.
 */
public final class AccessibilityInteractionClient {
    public static final int NO_ID = -1;
    public static final int UNDEFINED_CONNECTION_ID = -1;
    private static final AccessibilityInteractionClient INSTANCE = new AccessibilityInteractionClient();
    private AccessibilityInteractionClient() {}
    public static AccessibilityInteractionClient getInstance() { return INSTANCE; }

    public AccessibilityNodeInfo findAccessibilityNodeInfoByAccessibilityId(int connectionId, int accessibilityWindowId, long accessibilityNodeId, boolean bypassCache, int prefetchFlags, Bundle arguments) { return null; }
    public AccessibilityNodeInfo findAccessibilityNodeInfoByAccessibilityId(int connectionId, IBinder leashToken, long accessibilityNodeId, boolean bypassCache, int prefetchFlags, Bundle arguments) { return null; }
    public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(int connectionId, int accessibilityWindowId, long accessibilityNodeId, String viewId) { return Collections.emptyList(); }
    public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(int connectionId, int accessibilityWindowId, long accessibilityNodeId, String text) { return Collections.emptyList(); }
    public AccessibilityNodeInfo findFocus(int connectionId, int accessibilityWindowId, long accessibilityNodeId, int focusType) { return null; }
    public AccessibilityNodeInfo focusSearch(int connectionId, int accessibilityWindowId, long accessibilityNodeId, int direction) { return null; }
    public boolean performAccessibilityAction(int connectionId, int accessibilityWindowId, long accessibilityNodeId, int action, Bundle arguments) { return false; }
    public AccessibilityWindowInfo getWindow(int connectionId, int accessibilityWindowId) { return null; }
    public AccessibilityWindowInfo getWindow(int connectionId, int accessibilityWindowId, boolean bypassCache) { return null; }
    public static void clearCache() {}
}
