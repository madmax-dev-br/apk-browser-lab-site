package android.graphics;

import android.os.Parcel;

/**
 * Lab-authored android.graphics.LeakyTypefaceStorage: AOSP shares a Typeface across processes by keeping it in an in-process list and parcelling an index plus the font
 * files in SharedMemory. The browser VM has one process and no SharedMemory, so parcelling a Typeface (TypefaceSpan.writeToParcel / TypefaceSpan(Parcel)) fails explicitly.
 */
public class LeakyTypefaceStorage {
    private LeakyTypefaceStorage() {}

    public static void writeTypefaceToParcel(Typeface typeface, Parcel parcel) {
        throw new UnsupportedOperationException("A Typeface cannot be parcelled in the browser VM (no SharedMemory-backed font transport)");
    }

    public static Typeface readTypefaceFromParcel(Parcel parcel) {
        throw new UnsupportedOperationException("A Typeface cannot be read from a Parcel in the browser VM (no SharedMemory-backed font transport)");
    }
}
