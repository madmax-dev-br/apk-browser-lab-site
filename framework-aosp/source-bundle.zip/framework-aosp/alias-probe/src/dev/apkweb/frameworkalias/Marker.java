package dev.apkweb.frameworkalias;
/** Resource-only probe marker: loadAPK requires a root DEX. No Activity or app functionality. */
public final class Marker { private Marker() {} }
