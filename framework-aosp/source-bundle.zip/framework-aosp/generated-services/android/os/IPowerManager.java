/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.os;
/** @hide */
public interface IPowerManager extends android.os.IInterface
{
  /** Default implementation for IPowerManager. */
  public static class Default implements android.os.IPowerManager
  {
    @Override public void acquireWakeLock(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, android.os.WorkSource ws, java.lang.String historyTag, int displayId, android.os.IWakeLockCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void acquireWakeLockWithUid(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, int uidtoblame, int displayId, android.os.IWakeLockCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void releaseWakeLock(android.os.IBinder lock, int flags) throws android.os.RemoteException
    {
    }
    @Override public void updateWakeLockUids(android.os.IBinder lock, int[] uids) throws android.os.RemoteException
    {
    }
    @Override public void setPowerBoost(int boost, int durationMs) throws android.os.RemoteException
    {
    }
    @Override public void setPowerMode(int mode, boolean enabled) throws android.os.RemoteException
    {
    }
    // Functionally identical to setPowerMode, but returns whether the call was successful
    @Override public boolean setPowerModeChecked(int mode, boolean enabled) throws android.os.RemoteException
    {
      return false;
    }
    @Override public void updateWakeLockWorkSource(android.os.IBinder lock, android.os.WorkSource ws, java.lang.String historyTag) throws android.os.RemoteException
    {
    }
    @Override public void updateWakeLockCallback(android.os.IBinder lock, android.os.IWakeLockCallback callback) throws android.os.RemoteException
    {
    }
    @Override public boolean isWakeLockLevelSupported(int level) throws android.os.RemoteException
    {
      return false;
    }
    @Override public void userActivity(int displayId, long time, int event, int flags) throws android.os.RemoteException
    {
    }
    @Override public void wakeUp(long time, int reason, java.lang.String details, java.lang.String opPackageName) throws android.os.RemoteException
    {
    }
    @Override public void goToSleep(long time, int reason, int flags) throws android.os.RemoteException
    {
    }
    @Override public void nap(long time) throws android.os.RemoteException
    {
    }
    @Override public float getBrightnessConstraint(int constraint) throws android.os.RemoteException
    {
      return 0.0f;
    }
    @Override public boolean isInteractive() throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean isPowerSaveMode() throws android.os.RemoteException
    {
      return false;
    }
    @Override public android.os.PowerSaveState getPowerSaveState(int serviceType) throws android.os.RemoteException
    {
      return null;
    }
    @Override public boolean setPowerSaveModeEnabled(boolean mode) throws android.os.RemoteException
    {
      return false;
    }
    @Override public android.os.BatterySaverPolicyConfig getFullPowerSavePolicy() throws android.os.RemoteException
    {
      return null;
    }
    @Override public boolean setFullPowerSavePolicy(android.os.BatterySaverPolicyConfig config) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean setDynamicPowerSaveHint(boolean powerSaveHint, int disableThreshold) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean setAdaptivePowerSavePolicy(android.os.BatterySaverPolicyConfig config) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean setAdaptivePowerSaveEnabled(boolean enabled) throws android.os.RemoteException
    {
      return false;
    }
    @Override public int getPowerSaveModeTrigger() throws android.os.RemoteException
    {
      return 0;
    }
    @Override public void setBatteryDischargePrediction(android.os.ParcelDuration timeRemaining, boolean isCustomized) throws android.os.RemoteException
    {
    }
    @Override public android.os.ParcelDuration getBatteryDischargePrediction() throws android.os.RemoteException
    {
      return null;
    }
    @Override public boolean isBatteryDischargePredictionPersonalized() throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean isDeviceIdleMode() throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean isLightDeviceIdleMode() throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean isLowPowerStandbySupported() throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean isLowPowerStandbyEnabled() throws android.os.RemoteException
    {
      return false;
    }
    @Override public void setLowPowerStandbyEnabled(boolean enabled) throws android.os.RemoteException
    {
    }
    @Override public void setLowPowerStandbyActiveDuringMaintenance(boolean activeDuringMaintenance) throws android.os.RemoteException
    {
    }
    @Override public void forceLowPowerStandbyActive(boolean active) throws android.os.RemoteException
    {
    }
    @Override public void reboot(boolean confirm, java.lang.String reason, boolean wait) throws android.os.RemoteException
    {
    }
    @Override public void rebootSafeMode(boolean confirm, boolean wait) throws android.os.RemoteException
    {
    }
    @Override public void shutdown(boolean confirm, java.lang.String reason, boolean wait) throws android.os.RemoteException
    {
    }
    @Override public void crash(java.lang.String message) throws android.os.RemoteException
    {
    }
    @Override public int getLastShutdownReason() throws android.os.RemoteException
    {
      return 0;
    }
    @Override public int getLastSleepReason() throws android.os.RemoteException
    {
      return 0;
    }
    @Override public void setStayOnSetting(int val) throws android.os.RemoteException
    {
    }
    @Override public void boostScreenBrightness(long time) throws android.os.RemoteException
    {
    }
    // Do not use, will be deprecated soon.  b/151831987
    @Override public void acquireWakeLockAsync(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, android.os.WorkSource ws, java.lang.String historyTag) throws android.os.RemoteException
    {
    }
    @Override public void releaseWakeLockAsync(android.os.IBinder lock, int flags) throws android.os.RemoteException
    {
    }
    @Override public void updateWakeLockUidsAsync(android.os.IBinder lock, int[] uids) throws android.os.RemoteException
    {
    }
    // --- deprecated ---
    @Override public boolean isScreenBrightnessBoosted() throws android.os.RemoteException
    {
      return false;
    }
    // sets the attention light (used by phone app only)
    @Override public void setAttentionLight(boolean on, int color) throws android.os.RemoteException
    {
    }
    // controls whether PowerManager should doze after the screen turns off or not
    @Override public void setDozeAfterScreenOff(boolean on) throws android.os.RemoteException
    {
    }
    // returns whether ambient display is available on the device.
    @Override public boolean isAmbientDisplayAvailable() throws android.os.RemoteException
    {
      return false;
    }
    // suppresses the current ambient display configuration and disables ambient display.
    @Override public void suppressAmbientDisplay(java.lang.String token, boolean suppress) throws android.os.RemoteException
    {
    }
    // returns whether ambient display is suppressed by the calling app with the given token.
    @Override public boolean isAmbientDisplaySuppressedForToken(java.lang.String token) throws android.os.RemoteException
    {
      return false;
    }
    // returns whether ambient display is suppressed by any app with any token.
    @Override public boolean isAmbientDisplaySuppressed() throws android.os.RemoteException
    {
      return false;
    }
    // returns whether ambient display is suppressed by the given app with the given token.
    @Override public boolean isAmbientDisplaySuppressedForTokenByApp(java.lang.String token, int appUid) throws android.os.RemoteException
    {
      return false;
    }
    // Forces the system to suspend even if there are held wakelocks.
    @Override public boolean forceSuspend() throws android.os.RemoteException
    {
      return false;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.os.IPowerManager
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.os.IPowerManager interface,
     * generating a proxy if needed.
     */
    public static android.os.IPowerManager asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.os.IPowerManager))) {
        return ((android.os.IPowerManager)iin);
      }
      return new android.os.IPowerManager.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_acquireWakeLock:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int _arg1;
          _arg1 = data.readInt();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _arg3;
          _arg3 = data.readString();
          android.os.WorkSource _arg4;
          _arg4 = _Parcel.readTypedObject(data, android.os.WorkSource.CREATOR);
          java.lang.String _arg5;
          _arg5 = data.readString();
          int _arg6;
          _arg6 = data.readInt();
          android.os.IWakeLockCallback _arg7;
          _arg7 = android.os.IWakeLockCallback.Stub.asInterface(data.readStrongBinder());
          this.acquireWakeLock(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_acquireWakeLockWithUid:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int _arg1;
          _arg1 = data.readInt();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _arg3;
          _arg3 = data.readString();
          int _arg4;
          _arg4 = data.readInt();
          int _arg5;
          _arg5 = data.readInt();
          android.os.IWakeLockCallback _arg6;
          _arg6 = android.os.IWakeLockCallback.Stub.asInterface(data.readStrongBinder());
          this.acquireWakeLockWithUid(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_releaseWakeLock:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int _arg1;
          _arg1 = data.readInt();
          this.releaseWakeLock(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_updateWakeLockUids:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int[] _arg1;
          _arg1 = data.createIntArray();
          this.updateWakeLockUids(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_setPowerBoost:
        {
          int _arg0;
          _arg0 = data.readInt();
          int _arg1;
          _arg1 = data.readInt();
          this.setPowerBoost(_arg0, _arg1);
          break;
        }
        case TRANSACTION_setPowerMode:
        {
          int _arg0;
          _arg0 = data.readInt();
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          this.setPowerMode(_arg0, _arg1);
          break;
        }
        case TRANSACTION_setPowerModeChecked:
        {
          int _arg0;
          _arg0 = data.readInt();
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          boolean _result = this.setPowerModeChecked(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateWakeLockWorkSource:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          android.os.WorkSource _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.os.WorkSource.CREATOR);
          java.lang.String _arg2;
          _arg2 = data.readString();
          this.updateWakeLockWorkSource(_arg0, _arg1, _arg2);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_updateWakeLockCallback:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          android.os.IWakeLockCallback _arg1;
          _arg1 = android.os.IWakeLockCallback.Stub.asInterface(data.readStrongBinder());
          this.updateWakeLockCallback(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_isWakeLockLevelSupported:
        {
          int _arg0;
          _arg0 = data.readInt();
          boolean _result = this.isWakeLockLevelSupported(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_userActivity:
        {
          int _arg0;
          _arg0 = data.readInt();
          long _arg1;
          _arg1 = data.readLong();
          int _arg2;
          _arg2 = data.readInt();
          int _arg3;
          _arg3 = data.readInt();
          this.userActivity(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_wakeUp:
        {
          long _arg0;
          _arg0 = data.readLong();
          int _arg1;
          _arg1 = data.readInt();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _arg3;
          _arg3 = data.readString();
          this.wakeUp(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_goToSleep:
        {
          long _arg0;
          _arg0 = data.readLong();
          int _arg1;
          _arg1 = data.readInt();
          int _arg2;
          _arg2 = data.readInt();
          this.goToSleep(_arg0, _arg1, _arg2);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_nap:
        {
          long _arg0;
          _arg0 = data.readLong();
          this.nap(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_getBrightnessConstraint:
        {
          int _arg0;
          _arg0 = data.readInt();
          float _result = this.getBrightnessConstraint(_arg0);
          reply.writeNoException();
          reply.writeFloat(_result);
          break;
        }
        case TRANSACTION_isInteractive:
        {
          boolean _result = this.isInteractive();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isPowerSaveMode:
        {
          boolean _result = this.isPowerSaveMode();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getPowerSaveState:
        {
          int _arg0;
          _arg0 = data.readInt();
          android.os.PowerSaveState _result = this.getPowerSaveState(_arg0);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_setPowerSaveModeEnabled:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          boolean _result = this.setPowerSaveModeEnabled(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getFullPowerSavePolicy:
        {
          android.os.BatterySaverPolicyConfig _result = this.getFullPowerSavePolicy();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_setFullPowerSavePolicy:
        {
          android.os.BatterySaverPolicyConfig _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.os.BatterySaverPolicyConfig.CREATOR);
          boolean _result = this.setFullPowerSavePolicy(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setDynamicPowerSaveHint:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          int _arg1;
          _arg1 = data.readInt();
          boolean _result = this.setDynamicPowerSaveHint(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setAdaptivePowerSavePolicy:
        {
          android.os.BatterySaverPolicyConfig _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.os.BatterySaverPolicyConfig.CREATOR);
          boolean _result = this.setAdaptivePowerSavePolicy(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setAdaptivePowerSaveEnabled:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          boolean _result = this.setAdaptivePowerSaveEnabled(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getPowerSaveModeTrigger:
        {
          int _result = this.getPowerSaveModeTrigger();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_setBatteryDischargePrediction:
        {
          android.os.ParcelDuration _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.os.ParcelDuration.CREATOR);
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          this.setBatteryDischargePrediction(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_getBatteryDischargePrediction:
        {
          android.os.ParcelDuration _result = this.getBatteryDischargePrediction();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_isBatteryDischargePredictionPersonalized:
        {
          boolean _result = this.isBatteryDischargePredictionPersonalized();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isDeviceIdleMode:
        {
          boolean _result = this.isDeviceIdleMode();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isLightDeviceIdleMode:
        {
          boolean _result = this.isLightDeviceIdleMode();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isLowPowerStandbySupported:
        {
          boolean _result = this.isLowPowerStandbySupported();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isLowPowerStandbyEnabled:
        {
          boolean _result = this.isLowPowerStandbyEnabled();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setLowPowerStandbyEnabled:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          this.setLowPowerStandbyEnabled(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_setLowPowerStandbyActiveDuringMaintenance:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          this.setLowPowerStandbyActiveDuringMaintenance(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_forceLowPowerStandbyActive:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          this.forceLowPowerStandbyActive(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_reboot:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          java.lang.String _arg1;
          _arg1 = data.readString();
          boolean _arg2;
          _arg2 = (0!=data.readInt());
          this.reboot(_arg0, _arg1, _arg2);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_rebootSafeMode:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          this.rebootSafeMode(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_shutdown:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          java.lang.String _arg1;
          _arg1 = data.readString();
          boolean _arg2;
          _arg2 = (0!=data.readInt());
          this.shutdown(_arg0, _arg1, _arg2);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_crash:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.crash(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_getLastShutdownReason:
        {
          int _result = this.getLastShutdownReason();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_getLastSleepReason:
        {
          int _result = this.getLastSleepReason();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_setStayOnSetting:
        {
          int _arg0;
          _arg0 = data.readInt();
          this.setStayOnSetting(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_boostScreenBrightness:
        {
          long _arg0;
          _arg0 = data.readLong();
          this.boostScreenBrightness(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_acquireWakeLockAsync:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int _arg1;
          _arg1 = data.readInt();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _arg3;
          _arg3 = data.readString();
          android.os.WorkSource _arg4;
          _arg4 = _Parcel.readTypedObject(data, android.os.WorkSource.CREATOR);
          java.lang.String _arg5;
          _arg5 = data.readString();
          this.acquireWakeLockAsync(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5);
          break;
        }
        case TRANSACTION_releaseWakeLockAsync:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int _arg1;
          _arg1 = data.readInt();
          this.releaseWakeLockAsync(_arg0, _arg1);
          break;
        }
        case TRANSACTION_updateWakeLockUidsAsync:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int[] _arg1;
          _arg1 = data.createIntArray();
          this.updateWakeLockUidsAsync(_arg0, _arg1);
          break;
        }
        case TRANSACTION_isScreenBrightnessBoosted:
        {
          boolean _result = this.isScreenBrightnessBoosted();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setAttentionLight:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          int _arg1;
          _arg1 = data.readInt();
          this.setAttentionLight(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_setDozeAfterScreenOff:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          this.setDozeAfterScreenOff(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_isAmbientDisplayAvailable:
        {
          boolean _result = this.isAmbientDisplayAvailable();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_suppressAmbientDisplay:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          this.suppressAmbientDisplay(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_isAmbientDisplaySuppressedForToken:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.isAmbientDisplaySuppressedForToken(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isAmbientDisplaySuppressed:
        {
          boolean _result = this.isAmbientDisplaySuppressed();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isAmbientDisplaySuppressedForTokenByApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          int _arg1;
          _arg1 = data.readInt();
          boolean _result = this.isAmbientDisplaySuppressedForTokenByApp(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_forceSuspend:
        {
          boolean _result = this.forceSuspend();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.os.IPowerManager
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void acquireWakeLock(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, android.os.WorkSource ws, java.lang.String historyTag, int displayId, android.os.IWakeLockCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeInt(flags);
          _data.writeString(tag);
          _data.writeString(packageName);
          _Parcel.writeTypedObject(_data, ws, 0);
          _data.writeString(historyTag);
          _data.writeInt(displayId);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_acquireWakeLock, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void acquireWakeLockWithUid(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, int uidtoblame, int displayId, android.os.IWakeLockCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeInt(flags);
          _data.writeString(tag);
          _data.writeString(packageName);
          _data.writeInt(uidtoblame);
          _data.writeInt(displayId);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_acquireWakeLockWithUid, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void releaseWakeLock(android.os.IBinder lock, int flags) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeInt(flags);
          boolean _status = mRemote.transact(Stub.TRANSACTION_releaseWakeLock, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void updateWakeLockUids(android.os.IBinder lock, int[] uids) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeIntArray(uids);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateWakeLockUids, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void setPowerBoost(int boost, int durationMs) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(boost);
          _data.writeInt(durationMs);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setPowerBoost, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void setPowerMode(int mode, boolean enabled) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(mode);
          _data.writeInt(((enabled)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setPowerMode, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      // Functionally identical to setPowerMode, but returns whether the call was successful
      @Override public boolean setPowerModeChecked(int mode, boolean enabled) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(mode);
          _data.writeInt(((enabled)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setPowerModeChecked, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void updateWakeLockWorkSource(android.os.IBinder lock, android.os.WorkSource ws, java.lang.String historyTag) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _Parcel.writeTypedObject(_data, ws, 0);
          _data.writeString(historyTag);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateWakeLockWorkSource, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void updateWakeLockCallback(android.os.IBinder lock, android.os.IWakeLockCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateWakeLockCallback, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public boolean isWakeLockLevelSupported(int level) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(level);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isWakeLockLevelSupported, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void userActivity(int displayId, long time, int event, int flags) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(displayId);
          _data.writeLong(time);
          _data.writeInt(event);
          _data.writeInt(flags);
          boolean _status = mRemote.transact(Stub.TRANSACTION_userActivity, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void wakeUp(long time, int reason, java.lang.String details, java.lang.String opPackageName) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(time);
          _data.writeInt(reason);
          _data.writeString(details);
          _data.writeString(opPackageName);
          boolean _status = mRemote.transact(Stub.TRANSACTION_wakeUp, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void goToSleep(long time, int reason, int flags) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(time);
          _data.writeInt(reason);
          _data.writeInt(flags);
          boolean _status = mRemote.transact(Stub.TRANSACTION_goToSleep, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void nap(long time) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(time);
          boolean _status = mRemote.transact(Stub.TRANSACTION_nap, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public float getBrightnessConstraint(int constraint) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        float _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(constraint);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getBrightnessConstraint, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readFloat();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isInteractive() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isInteractive, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isPowerSaveMode() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isPowerSaveMode, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public android.os.PowerSaveState getPowerSaveState(int serviceType) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.PowerSaveState _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(serviceType);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getPowerSaveState, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.PowerSaveState.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setPowerSaveModeEnabled(boolean mode) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((mode)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setPowerSaveModeEnabled, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public android.os.BatterySaverPolicyConfig getFullPowerSavePolicy() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.BatterySaverPolicyConfig _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getFullPowerSavePolicy, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.BatterySaverPolicyConfig.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setFullPowerSavePolicy(android.os.BatterySaverPolicyConfig config) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, config, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setFullPowerSavePolicy, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setDynamicPowerSaveHint(boolean powerSaveHint, int disableThreshold) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((powerSaveHint)?(1):(0)));
          _data.writeInt(disableThreshold);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setDynamicPowerSaveHint, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setAdaptivePowerSavePolicy(android.os.BatterySaverPolicyConfig config) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, config, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setAdaptivePowerSavePolicy, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setAdaptivePowerSaveEnabled(boolean enabled) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((enabled)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setAdaptivePowerSaveEnabled, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int getPowerSaveModeTrigger() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getPowerSaveModeTrigger, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void setBatteryDischargePrediction(android.os.ParcelDuration timeRemaining, boolean isCustomized) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, timeRemaining, 0);
          _data.writeInt(((isCustomized)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setBatteryDischargePrediction, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public android.os.ParcelDuration getBatteryDischargePrediction() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.ParcelDuration _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getBatteryDischargePrediction, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.ParcelDuration.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isBatteryDischargePredictionPersonalized() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isBatteryDischargePredictionPersonalized, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isDeviceIdleMode() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isDeviceIdleMode, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isLightDeviceIdleMode() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isLightDeviceIdleMode, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isLowPowerStandbySupported() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isLowPowerStandbySupported, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isLowPowerStandbyEnabled() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isLowPowerStandbyEnabled, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void setLowPowerStandbyEnabled(boolean enabled) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((enabled)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setLowPowerStandbyEnabled, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void setLowPowerStandbyActiveDuringMaintenance(boolean activeDuringMaintenance) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((activeDuringMaintenance)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setLowPowerStandbyActiveDuringMaintenance, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void forceLowPowerStandbyActive(boolean active) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((active)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_forceLowPowerStandbyActive, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void reboot(boolean confirm, java.lang.String reason, boolean wait) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((confirm)?(1):(0)));
          _data.writeString(reason);
          _data.writeInt(((wait)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_reboot, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void rebootSafeMode(boolean confirm, boolean wait) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((confirm)?(1):(0)));
          _data.writeInt(((wait)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_rebootSafeMode, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void shutdown(boolean confirm, java.lang.String reason, boolean wait) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((confirm)?(1):(0)));
          _data.writeString(reason);
          _data.writeInt(((wait)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_shutdown, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void crash(java.lang.String message) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(message);
          boolean _status = mRemote.transact(Stub.TRANSACTION_crash, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public int getLastShutdownReason() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getLastShutdownReason, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int getLastSleepReason() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getLastSleepReason, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void setStayOnSetting(int val) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(val);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setStayOnSetting, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void boostScreenBrightness(long time) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(time);
          boolean _status = mRemote.transact(Stub.TRANSACTION_boostScreenBrightness, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      // Do not use, will be deprecated soon.  b/151831987
      @Override public void acquireWakeLockAsync(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, android.os.WorkSource ws, java.lang.String historyTag) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeInt(flags);
          _data.writeString(tag);
          _data.writeString(packageName);
          _Parcel.writeTypedObject(_data, ws, 0);
          _data.writeString(historyTag);
          boolean _status = mRemote.transact(Stub.TRANSACTION_acquireWakeLockAsync, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void releaseWakeLockAsync(android.os.IBinder lock, int flags) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeInt(flags);
          boolean _status = mRemote.transact(Stub.TRANSACTION_releaseWakeLockAsync, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void updateWakeLockUidsAsync(android.os.IBinder lock, int[] uids) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(lock);
          _data.writeIntArray(uids);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateWakeLockUidsAsync, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      // --- deprecated ---
      @Override public boolean isScreenBrightnessBoosted() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isScreenBrightnessBoosted, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // sets the attention light (used by phone app only)
      @Override public void setAttentionLight(boolean on, int color) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((on)?(1):(0)));
          _data.writeInt(color);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setAttentionLight, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      // controls whether PowerManager should doze after the screen turns off or not
      @Override public void setDozeAfterScreenOff(boolean on) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((on)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_setDozeAfterScreenOff, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      // returns whether ambient display is available on the device.
      @Override public boolean isAmbientDisplayAvailable() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isAmbientDisplayAvailable, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // suppresses the current ambient display configuration and disables ambient display.
      @Override public void suppressAmbientDisplay(java.lang.String token, boolean suppress) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(token);
          _data.writeInt(((suppress)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_suppressAmbientDisplay, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      // returns whether ambient display is suppressed by the calling app with the given token.
      @Override public boolean isAmbientDisplaySuppressedForToken(java.lang.String token) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(token);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isAmbientDisplaySuppressedForToken, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // returns whether ambient display is suppressed by any app with any token.
      @Override public boolean isAmbientDisplaySuppressed() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isAmbientDisplaySuppressed, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // returns whether ambient display is suppressed by the given app with the given token.
      @Override public boolean isAmbientDisplaySuppressedForTokenByApp(java.lang.String token, int appUid) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(token);
          _data.writeInt(appUid);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isAmbientDisplaySuppressedForTokenByApp, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // Forces the system to suspend even if there are held wakelocks.
      @Override public boolean forceSuspend() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_forceSuspend, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    /** @hide */
    public static final java.lang.String DESCRIPTOR = "android.os.IPowerManager";
    static final int TRANSACTION_acquireWakeLock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_acquireWakeLockWithUid = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_releaseWakeLock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_updateWakeLockUids = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_setPowerBoost = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_setPowerMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_setPowerModeChecked = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_updateWakeLockWorkSource = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_updateWakeLockCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_isWakeLockLevelSupported = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_userActivity = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
    static final int TRANSACTION_wakeUp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
    static final int TRANSACTION_goToSleep = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
    static final int TRANSACTION_nap = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
    static final int TRANSACTION_getBrightnessConstraint = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
    static final int TRANSACTION_isInteractive = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
    static final int TRANSACTION_isPowerSaveMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
    static final int TRANSACTION_getPowerSaveState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
    static final int TRANSACTION_setPowerSaveModeEnabled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
    static final int TRANSACTION_getFullPowerSavePolicy = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
    static final int TRANSACTION_setFullPowerSavePolicy = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
    static final int TRANSACTION_setDynamicPowerSaveHint = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
    static final int TRANSACTION_setAdaptivePowerSavePolicy = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
    static final int TRANSACTION_setAdaptivePowerSaveEnabled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
    static final int TRANSACTION_getPowerSaveModeTrigger = (android.os.IBinder.FIRST_CALL_TRANSACTION + 24);
    static final int TRANSACTION_setBatteryDischargePrediction = (android.os.IBinder.FIRST_CALL_TRANSACTION + 25);
    static final int TRANSACTION_getBatteryDischargePrediction = (android.os.IBinder.FIRST_CALL_TRANSACTION + 26);
    static final int TRANSACTION_isBatteryDischargePredictionPersonalized = (android.os.IBinder.FIRST_CALL_TRANSACTION + 27);
    static final int TRANSACTION_isDeviceIdleMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 28);
    static final int TRANSACTION_isLightDeviceIdleMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 29);
    static final int TRANSACTION_isLowPowerStandbySupported = (android.os.IBinder.FIRST_CALL_TRANSACTION + 30);
    static final int TRANSACTION_isLowPowerStandbyEnabled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 31);
    static final int TRANSACTION_setLowPowerStandbyEnabled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 32);
    static final int TRANSACTION_setLowPowerStandbyActiveDuringMaintenance = (android.os.IBinder.FIRST_CALL_TRANSACTION + 33);
    static final int TRANSACTION_forceLowPowerStandbyActive = (android.os.IBinder.FIRST_CALL_TRANSACTION + 34);
    static final int TRANSACTION_reboot = (android.os.IBinder.FIRST_CALL_TRANSACTION + 35);
    static final int TRANSACTION_rebootSafeMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 36);
    static final int TRANSACTION_shutdown = (android.os.IBinder.FIRST_CALL_TRANSACTION + 37);
    static final int TRANSACTION_crash = (android.os.IBinder.FIRST_CALL_TRANSACTION + 38);
    static final int TRANSACTION_getLastShutdownReason = (android.os.IBinder.FIRST_CALL_TRANSACTION + 39);
    static final int TRANSACTION_getLastSleepReason = (android.os.IBinder.FIRST_CALL_TRANSACTION + 40);
    static final int TRANSACTION_setStayOnSetting = (android.os.IBinder.FIRST_CALL_TRANSACTION + 41);
    static final int TRANSACTION_boostScreenBrightness = (android.os.IBinder.FIRST_CALL_TRANSACTION + 42);
    static final int TRANSACTION_acquireWakeLockAsync = (android.os.IBinder.FIRST_CALL_TRANSACTION + 43);
    static final int TRANSACTION_releaseWakeLockAsync = (android.os.IBinder.FIRST_CALL_TRANSACTION + 44);
    static final int TRANSACTION_updateWakeLockUidsAsync = (android.os.IBinder.FIRST_CALL_TRANSACTION + 45);
    static final int TRANSACTION_isScreenBrightnessBoosted = (android.os.IBinder.FIRST_CALL_TRANSACTION + 46);
    static final int TRANSACTION_setAttentionLight = (android.os.IBinder.FIRST_CALL_TRANSACTION + 47);
    static final int TRANSACTION_setDozeAfterScreenOff = (android.os.IBinder.FIRST_CALL_TRANSACTION + 48);
    static final int TRANSACTION_isAmbientDisplayAvailable = (android.os.IBinder.FIRST_CALL_TRANSACTION + 49);
    static final int TRANSACTION_suppressAmbientDisplay = (android.os.IBinder.FIRST_CALL_TRANSACTION + 50);
    static final int TRANSACTION_isAmbientDisplaySuppressedForToken = (android.os.IBinder.FIRST_CALL_TRANSACTION + 51);
    static final int TRANSACTION_isAmbientDisplaySuppressed = (android.os.IBinder.FIRST_CALL_TRANSACTION + 52);
    static final int TRANSACTION_isAmbientDisplaySuppressedForTokenByApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 53);
    static final int TRANSACTION_forceSuspend = (android.os.IBinder.FIRST_CALL_TRANSACTION + 54);
  }
  public static final int LOCATION_MODE_NO_CHANGE = 0;
  public static final int LOCATION_MODE_GPS_DISABLED_WHEN_SCREEN_OFF = 1;
  public static final int LOCATION_MODE_ALL_DISABLED_WHEN_SCREEN_OFF = 2;
  public static final int LOCATION_MODE_FOREGROUND_ONLY = 3;
  public static final int LOCATION_MODE_THROTTLE_REQUESTS_WHEN_SCREEN_OFF = 4;
  public static final int MIN_LOCATION_MODE = 0;
  public static final int MAX_LOCATION_MODE = 4;
  public static final int GO_TO_SLEEP_REASON_MIN = 0;
  public static final int GO_TO_SLEEP_REASON_APPLICATION = 0;
  public static final int GO_TO_SLEEP_REASON_TIMEOUT = 2;
  public static final int GO_TO_SLEEP_REASON_LID_SWITCH = 3;
  public static final int GO_TO_SLEEP_REASON_POWER_BUTTON = 4;
  public static final int GO_TO_SLEEP_REASON_HDMI = 5;
  public static final int GO_TO_SLEEP_REASON_SLEEP_BUTTON = 6;
  public static final int GO_TO_SLEEP_REASON_ACCESSIBILITY = 7;
  public static final int GO_TO_SLEEP_REASON_FORCE_SUSPEND = 8;
  public static final int GO_TO_SLEEP_REASON_INATTENTIVE = 9;
  public static final int GO_TO_SLEEP_REASON_QUIESCENT = 10;
  public static final int GO_TO_SLEEP_REASON_MAX = 10;
  public static final int GO_TO_SLEEP_FLAG_NO_DOZE = 1;
  public void acquireWakeLock(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, android.os.WorkSource ws, java.lang.String historyTag, int displayId, android.os.IWakeLockCallback callback) throws android.os.RemoteException;
  public void acquireWakeLockWithUid(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, int uidtoblame, int displayId, android.os.IWakeLockCallback callback) throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage
  public void releaseWakeLock(android.os.IBinder lock, int flags) throws android.os.RemoteException;
  public void updateWakeLockUids(android.os.IBinder lock, int[] uids) throws android.os.RemoteException;
  public void setPowerBoost(int boost, int durationMs) throws android.os.RemoteException;
  public void setPowerMode(int mode, boolean enabled) throws android.os.RemoteException;
  // Functionally identical to setPowerMode, but returns whether the call was successful
  public boolean setPowerModeChecked(int mode, boolean enabled) throws android.os.RemoteException;
  public void updateWakeLockWorkSource(android.os.IBinder lock, android.os.WorkSource ws, java.lang.String historyTag) throws android.os.RemoteException;
  public void updateWakeLockCallback(android.os.IBinder lock, android.os.IWakeLockCallback callback) throws android.os.RemoteException;
  public boolean isWakeLockLevelSupported(int level) throws android.os.RemoteException;
  public void userActivity(int displayId, long time, int event, int flags) throws android.os.RemoteException;
  public void wakeUp(long time, int reason, java.lang.String details, java.lang.String opPackageName) throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 30, trackingBug = 170729553L)
  public void goToSleep(long time, int reason, int flags) throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 28)
  public void nap(long time) throws android.os.RemoteException;
  public float getBrightnessConstraint(int constraint) throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage
  public boolean isInteractive() throws android.os.RemoteException;
  public boolean isPowerSaveMode() throws android.os.RemoteException;
  public android.os.PowerSaveState getPowerSaveState(int serviceType) throws android.os.RemoteException;
  public boolean setPowerSaveModeEnabled(boolean mode) throws android.os.RemoteException;
  public android.os.BatterySaverPolicyConfig getFullPowerSavePolicy() throws android.os.RemoteException;
  public boolean setFullPowerSavePolicy(android.os.BatterySaverPolicyConfig config) throws android.os.RemoteException;
  public boolean setDynamicPowerSaveHint(boolean powerSaveHint, int disableThreshold) throws android.os.RemoteException;
  public boolean setAdaptivePowerSavePolicy(android.os.BatterySaverPolicyConfig config) throws android.os.RemoteException;
  public boolean setAdaptivePowerSaveEnabled(boolean enabled) throws android.os.RemoteException;
  public int getPowerSaveModeTrigger() throws android.os.RemoteException;
  public void setBatteryDischargePrediction(android.os.ParcelDuration timeRemaining, boolean isCustomized) throws android.os.RemoteException;
  public android.os.ParcelDuration getBatteryDischargePrediction() throws android.os.RemoteException;
  public boolean isBatteryDischargePredictionPersonalized() throws android.os.RemoteException;
  public boolean isDeviceIdleMode() throws android.os.RemoteException;
  public boolean isLightDeviceIdleMode() throws android.os.RemoteException;
  public boolean isLowPowerStandbySupported() throws android.os.RemoteException;
  public boolean isLowPowerStandbyEnabled() throws android.os.RemoteException;
  public void setLowPowerStandbyEnabled(boolean enabled) throws android.os.RemoteException;
  public void setLowPowerStandbyActiveDuringMaintenance(boolean activeDuringMaintenance) throws android.os.RemoteException;
  public void forceLowPowerStandbyActive(boolean active) throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage
  public void reboot(boolean confirm, java.lang.String reason, boolean wait) throws android.os.RemoteException;
  public void rebootSafeMode(boolean confirm, boolean wait) throws android.os.RemoteException;
  public void shutdown(boolean confirm, java.lang.String reason, boolean wait) throws android.os.RemoteException;
  public void crash(java.lang.String message) throws android.os.RemoteException;
  public int getLastShutdownReason() throws android.os.RemoteException;
  public int getLastSleepReason() throws android.os.RemoteException;
  public void setStayOnSetting(int val) throws android.os.RemoteException;
  public void boostScreenBrightness(long time) throws android.os.RemoteException;
  // Do not use, will be deprecated soon.  b/151831987
  public void acquireWakeLockAsync(android.os.IBinder lock, int flags, java.lang.String tag, java.lang.String packageName, android.os.WorkSource ws, java.lang.String historyTag) throws android.os.RemoteException;
  public void releaseWakeLockAsync(android.os.IBinder lock, int flags) throws android.os.RemoteException;
  public void updateWakeLockUidsAsync(android.os.IBinder lock, int[] uids) throws android.os.RemoteException;
  // --- deprecated ---
  public boolean isScreenBrightnessBoosted() throws android.os.RemoteException;
  // sets the attention light (used by phone app only)
  public void setAttentionLight(boolean on, int color) throws android.os.RemoteException;
  // controls whether PowerManager should doze after the screen turns off or not
  public void setDozeAfterScreenOff(boolean on) throws android.os.RemoteException;
  // returns whether ambient display is available on the device.
  public boolean isAmbientDisplayAvailable() throws android.os.RemoteException;
  // suppresses the current ambient display configuration and disables ambient display.
  public void suppressAmbientDisplay(java.lang.String token, boolean suppress) throws android.os.RemoteException;
  // returns whether ambient display is suppressed by the calling app with the given token.
  public boolean isAmbientDisplaySuppressedForToken(java.lang.String token) throws android.os.RemoteException;
  // returns whether ambient display is suppressed by any app with any token.
  public boolean isAmbientDisplaySuppressed() throws android.os.RemoteException;
  // returns whether ambient display is suppressed by the given app with the given token.
  public boolean isAmbientDisplaySuppressedForTokenByApp(java.lang.String token, int appUid) throws android.os.RemoteException;
  // Forces the system to suspend even if there are held wakelocks.
  public boolean forceSuspend() throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
