/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.os;
/** {@hide} */
public interface IThermalService extends android.os.IInterface
{
  /** Default implementation for IThermalService. */
  public static class Default implements android.os.IThermalService
  {
    /**
     * Register a listener for thermal events.
     * @param listener the IThermalEventListener to be notified.
     * {@hide}
     */
    @Override public boolean registerThermalEventListener(android.os.IThermalEventListener listener) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Register a listener for thermal events on given temperature type.
     * @param listener the IThermalEventListener to be notified.
     * @param type the temperature type IThermalEventListener to be notified.
     * @return true if registered successfully.
     * {@hide}
     */
    @Override public boolean registerThermalEventListenerWithType(android.os.IThermalEventListener listener, int type) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Unregister a previously-registered listener for thermal events.
     * @param listener the IThermalEventListener to no longer be notified.
     * @return true if unregistered successfully.
     * {@hide}
     */
    @Override public boolean unregisterThermalEventListener(android.os.IThermalEventListener listener) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Get current temperature with its throttling status.
     * @return list of {@link android.os.Temperature}.
     * {@hide}
     */
    @Override public android.os.Temperature[] getCurrentTemperatures() throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Get current temperature with its throttling status on given temperature type.
     * @param type the temperature type to query.
     * @return list of {@link android.os.Temperature}.
     * {@hide}
     */
    @Override public android.os.Temperature[] getCurrentTemperaturesWithType(int type) throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Register a listener for thermal status change.
     * @param listener the {@link android.os.IThermalStatusListener} to be notified.
     * @return true if registered successfully.
     * {@hide}
     */
    @Override public boolean registerThermalStatusListener(android.os.IThermalStatusListener listener) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Unregister a previously-registered listener for thermal status.
     * @param listener the {@link android.os.IThermalStatusListener} to no longer be notified.
     * @return true if unregistered successfully.
     * {@hide}
     */
    @Override public boolean unregisterThermalStatusListener(android.os.IThermalStatusListener listener) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Get current thermal status.
     * @return status defined in {@link android.os.Temperature}.
     * {@hide}
     */
    @Override public int getCurrentThermalStatus() throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Get current cooling devices.
     * @return list of {@link android.os.CoolingDevice}.
     * {@hide}
     */
    @Override public android.os.CoolingDevice[] getCurrentCoolingDevices() throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Get current cooling devices on given type.
     * @param type the cooling device type to query.
     * @return list of {@link android.os.CoolingDevice}.
     * {@hide}
     */
    @Override public android.os.CoolingDevice[] getCurrentCoolingDevicesWithType(int type) throws android.os.RemoteException
    {
      return null;
    }
    /**
     * @param forecastSeconds how many seconds ahead to forecast the provided headroom
     * @return forecasted thermal headroom, normalized such that 1.0 indicates that throttling will
     *     occur; returns NaN if the headroom or forecast is unavailable
     */
    @Override public float getThermalHeadroom(int forecastSeconds) throws android.os.RemoteException
    {
      return 0.0f;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.os.IThermalService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.os.IThermalService interface,
     * generating a proxy if needed.
     */
    public static android.os.IThermalService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.os.IThermalService))) {
        return ((android.os.IThermalService)iin);
      }
      return new android.os.IThermalService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_registerThermalEventListener:
        {
          android.os.IThermalEventListener _arg0;
          _arg0 = android.os.IThermalEventListener.Stub.asInterface(data.readStrongBinder());
          boolean _result = this.registerThermalEventListener(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_registerThermalEventListenerWithType:
        {
          android.os.IThermalEventListener _arg0;
          _arg0 = android.os.IThermalEventListener.Stub.asInterface(data.readStrongBinder());
          int _arg1;
          _arg1 = data.readInt();
          boolean _result = this.registerThermalEventListenerWithType(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_unregisterThermalEventListener:
        {
          android.os.IThermalEventListener _arg0;
          _arg0 = android.os.IThermalEventListener.Stub.asInterface(data.readStrongBinder());
          boolean _result = this.unregisterThermalEventListener(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getCurrentTemperatures:
        {
          android.os.Temperature[] _result = this.getCurrentTemperatures();
          reply.writeNoException();
          reply.writeTypedArray(_result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getCurrentTemperaturesWithType:
        {
          int _arg0;
          _arg0 = data.readInt();
          android.os.Temperature[] _result = this.getCurrentTemperaturesWithType(_arg0);
          reply.writeNoException();
          reply.writeTypedArray(_result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_registerThermalStatusListener:
        {
          android.os.IThermalStatusListener _arg0;
          _arg0 = android.os.IThermalStatusListener.Stub.asInterface(data.readStrongBinder());
          boolean _result = this.registerThermalStatusListener(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_unregisterThermalStatusListener:
        {
          android.os.IThermalStatusListener _arg0;
          _arg0 = android.os.IThermalStatusListener.Stub.asInterface(data.readStrongBinder());
          boolean _result = this.unregisterThermalStatusListener(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getCurrentThermalStatus:
        {
          int _result = this.getCurrentThermalStatus();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_getCurrentCoolingDevices:
        {
          android.os.CoolingDevice[] _result = this.getCurrentCoolingDevices();
          reply.writeNoException();
          reply.writeTypedArray(_result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getCurrentCoolingDevicesWithType:
        {
          int _arg0;
          _arg0 = data.readInt();
          android.os.CoolingDevice[] _result = this.getCurrentCoolingDevicesWithType(_arg0);
          reply.writeNoException();
          reply.writeTypedArray(_result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getThermalHeadroom:
        {
          int _arg0;
          _arg0 = data.readInt();
          float _result = this.getThermalHeadroom(_arg0);
          reply.writeNoException();
          reply.writeFloat(_result);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.os.IThermalService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Register a listener for thermal events.
       * @param listener the IThermalEventListener to be notified.
       * {@hide}
       */
      @Override public boolean registerThermalEventListener(android.os.IThermalEventListener listener) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(listener);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerThermalEventListener, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Register a listener for thermal events on given temperature type.
       * @param listener the IThermalEventListener to be notified.
       * @param type the temperature type IThermalEventListener to be notified.
       * @return true if registered successfully.
       * {@hide}
       */
      @Override public boolean registerThermalEventListenerWithType(android.os.IThermalEventListener listener, int type) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(listener);
          _data.writeInt(type);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerThermalEventListenerWithType, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Unregister a previously-registered listener for thermal events.
       * @param listener the IThermalEventListener to no longer be notified.
       * @return true if unregistered successfully.
       * {@hide}
       */
      @Override public boolean unregisterThermalEventListener(android.os.IThermalEventListener listener) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(listener);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterThermalEventListener, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Get current temperature with its throttling status.
       * @return list of {@link android.os.Temperature}.
       * {@hide}
       */
      @Override public android.os.Temperature[] getCurrentTemperatures() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Temperature[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getCurrentTemperatures, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createTypedArray(android.os.Temperature.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Get current temperature with its throttling status on given temperature type.
       * @param type the temperature type to query.
       * @return list of {@link android.os.Temperature}.
       * {@hide}
       */
      @Override public android.os.Temperature[] getCurrentTemperaturesWithType(int type) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Temperature[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(type);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getCurrentTemperaturesWithType, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createTypedArray(android.os.Temperature.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Register a listener for thermal status change.
       * @param listener the {@link android.os.IThermalStatusListener} to be notified.
       * @return true if registered successfully.
       * {@hide}
       */
      @Override public boolean registerThermalStatusListener(android.os.IThermalStatusListener listener) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(listener);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerThermalStatusListener, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Unregister a previously-registered listener for thermal status.
       * @param listener the {@link android.os.IThermalStatusListener} to no longer be notified.
       * @return true if unregistered successfully.
       * {@hide}
       */
      @Override public boolean unregisterThermalStatusListener(android.os.IThermalStatusListener listener) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(listener);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterThermalStatusListener, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Get current thermal status.
       * @return status defined in {@link android.os.Temperature}.
       * {@hide}
       */
      @Override public int getCurrentThermalStatus() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getCurrentThermalStatus, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Get current cooling devices.
       * @return list of {@link android.os.CoolingDevice}.
       * {@hide}
       */
      @Override public android.os.CoolingDevice[] getCurrentCoolingDevices() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.CoolingDevice[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getCurrentCoolingDevices, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createTypedArray(android.os.CoolingDevice.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Get current cooling devices on given type.
       * @param type the cooling device type to query.
       * @return list of {@link android.os.CoolingDevice}.
       * {@hide}
       */
      @Override public android.os.CoolingDevice[] getCurrentCoolingDevicesWithType(int type) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.CoolingDevice[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(type);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getCurrentCoolingDevicesWithType, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createTypedArray(android.os.CoolingDevice.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * @param forecastSeconds how many seconds ahead to forecast the provided headroom
       * @return forecasted thermal headroom, normalized such that 1.0 indicates that throttling will
       *     occur; returns NaN if the headroom or forecast is unavailable
       */
      @Override public float getThermalHeadroom(int forecastSeconds) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        float _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(forecastSeconds);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getThermalHeadroom, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readFloat();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    /** @hide */
    public static final java.lang.String DESCRIPTOR = "android.os.IThermalService";
    static final int TRANSACTION_registerThermalEventListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_registerThermalEventListenerWithType = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_unregisterThermalEventListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_getCurrentTemperatures = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_getCurrentTemperaturesWithType = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_registerThermalStatusListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_unregisterThermalStatusListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_getCurrentThermalStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_getCurrentCoolingDevices = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_getCurrentCoolingDevicesWithType = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_getThermalHeadroom = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
  }
  /**
   * Register a listener for thermal events.
   * @param listener the IThermalEventListener to be notified.
   * {@hide}
   */
  public boolean registerThermalEventListener(android.os.IThermalEventListener listener) throws android.os.RemoteException;
  /**
   * Register a listener for thermal events on given temperature type.
   * @param listener the IThermalEventListener to be notified.
   * @param type the temperature type IThermalEventListener to be notified.
   * @return true if registered successfully.
   * {@hide}
   */
  public boolean registerThermalEventListenerWithType(android.os.IThermalEventListener listener, int type) throws android.os.RemoteException;
  /**
   * Unregister a previously-registered listener for thermal events.
   * @param listener the IThermalEventListener to no longer be notified.
   * @return true if unregistered successfully.
   * {@hide}
   */
  public boolean unregisterThermalEventListener(android.os.IThermalEventListener listener) throws android.os.RemoteException;
  /**
   * Get current temperature with its throttling status.
   * @return list of {@link android.os.Temperature}.
   * {@hide}
   */
  public android.os.Temperature[] getCurrentTemperatures() throws android.os.RemoteException;
  /**
   * Get current temperature with its throttling status on given temperature type.
   * @param type the temperature type to query.
   * @return list of {@link android.os.Temperature}.
   * {@hide}
   */
  public android.os.Temperature[] getCurrentTemperaturesWithType(int type) throws android.os.RemoteException;
  /**
   * Register a listener for thermal status change.
   * @param listener the {@link android.os.IThermalStatusListener} to be notified.
   * @return true if registered successfully.
   * {@hide}
   */
  public boolean registerThermalStatusListener(android.os.IThermalStatusListener listener) throws android.os.RemoteException;
  /**
   * Unregister a previously-registered listener for thermal status.
   * @param listener the {@link android.os.IThermalStatusListener} to no longer be notified.
   * @return true if unregistered successfully.
   * {@hide}
   */
  public boolean unregisterThermalStatusListener(android.os.IThermalStatusListener listener) throws android.os.RemoteException;
  /**
   * Get current thermal status.
   * @return status defined in {@link android.os.Temperature}.
   * {@hide}
   */
  public int getCurrentThermalStatus() throws android.os.RemoteException;
  /**
   * Get current cooling devices.
   * @return list of {@link android.os.CoolingDevice}.
   * {@hide}
   */
  public android.os.CoolingDevice[] getCurrentCoolingDevices() throws android.os.RemoteException;
  /**
   * Get current cooling devices on given type.
   * @param type the cooling device type to query.
   * @return list of {@link android.os.CoolingDevice}.
   * {@hide}
   */
  public android.os.CoolingDevice[] getCurrentCoolingDevicesWithType(int type) throws android.os.RemoteException;
  /**
   * @param forecastSeconds how many seconds ahead to forecast the provided headroom
   * @return forecasted thermal headroom, normalized such that 1.0 indicates that throttling will
   *     occur; returns NaN if the headroom or forecast is unavailable
   */
  public float getThermalHeadroom(int forecastSeconds) throws android.os.RemoteException;
}
