/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.os;
/**
 * Listener for thermal status.
 * {@hide}
 */
public interface IThermalStatusListener extends android.os.IInterface
{
  /** Default implementation for IThermalStatusListener. */
  public static class Default implements android.os.IThermalStatusListener
  {
    /**
     * Called when overall thermal throttling status changed.
     * @param status defined in {@link android.os.Temperature#ThrottlingStatus}.
     */
    @Override public void onStatusChange(int status) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.os.IThermalStatusListener
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.os.IThermalStatusListener interface,
     * generating a proxy if needed.
     */
    public static android.os.IThermalStatusListener asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.os.IThermalStatusListener))) {
        return ((android.os.IThermalStatusListener)iin);
      }
      return new android.os.IThermalStatusListener.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onStatusChange:
        {
          int _arg0;
          _arg0 = data.readInt();
          this.onStatusChange(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.os.IThermalStatusListener
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Called when overall thermal throttling status changed.
       * @param status defined in {@link android.os.Temperature#ThrottlingStatus}.
       */
      @Override public void onStatusChange(int status) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(status);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onStatusChange, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onStatusChange = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "android.os.IThermalStatusListener";
  /**
   * Called when overall thermal throttling status changed.
   * @param status defined in {@link android.os.Temperature#ThrottlingStatus}.
   */
  public void onStatusChange(int status) throws android.os.RemoteException;
}
