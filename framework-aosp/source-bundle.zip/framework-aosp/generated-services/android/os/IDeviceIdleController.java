/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.os;
/** @hide */
public interface IDeviceIdleController extends android.os.IInterface
{
  /** Default implementation for IDeviceIdleController. */
  public static class Default implements android.os.IDeviceIdleController
  {
    @Override public void addPowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException
    {
    }
    @Override public int addPowerSaveWhitelistApps(java.util.List<java.lang.String> packageNames) throws android.os.RemoteException
    {
      return 0;
    }
    @Override public void removePowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException
    {
    }
    /**
     * Removes an app from the system whitelist. Calling restoreSystemPowerWhitelistApp will add
     * the app back into the system whitelist
     */
    @Override public void removeSystemPowerWhitelistApp(java.lang.String name) throws android.os.RemoteException
    {
    }
    @Override public void restoreSystemPowerWhitelistApp(java.lang.String name) throws android.os.RemoteException
    {
    }
    @Override public java.lang.String[] getRemovedSystemPowerWhitelistApps() throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String[] getSystemPowerWhitelistExceptIdle() throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String[] getSystemPowerWhitelist() throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String[] getUserPowerWhitelist() throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String[] getFullPowerWhitelistExceptIdle() throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String[] getFullPowerWhitelist() throws android.os.RemoteException
    {
      return null;
    }
    @Override public int[] getAppIdWhitelistExceptIdle() throws android.os.RemoteException
    {
      return null;
    }
    @Override public int[] getAppIdWhitelist() throws android.os.RemoteException
    {
      return null;
    }
    @Override public int[] getAppIdUserWhitelist() throws android.os.RemoteException
    {
      return null;
    }
    @Override public int[] getAppIdTempWhitelist() throws android.os.RemoteException
    {
      return null;
    }
    @Override public boolean isPowerSaveWhitelistExceptIdleApp(java.lang.String name) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean isPowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException
    {
      return false;
    }
    @Override public void addPowerSaveTempWhitelistApp(java.lang.String name, long duration, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
    {
    }
    @Override public long addPowerSaveTempWhitelistAppForMms(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
    {
      return 0L;
    }
    @Override public long addPowerSaveTempWhitelistAppForSms(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
    {
      return 0L;
    }
    @Override public long whitelistAppTemporarily(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
    {
      return 0L;
    }
    @Override public void exitIdle(java.lang.String reason) throws android.os.RemoteException
    {
    }
    @Override public int setPreIdleTimeoutMode(int Mode) throws android.os.RemoteException
    {
      return 0;
    }
    @Override public void resetPreIdleTimeoutMode() throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.os.IDeviceIdleController
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.os.IDeviceIdleController interface,
     * generating a proxy if needed.
     */
    public static android.os.IDeviceIdleController asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.os.IDeviceIdleController))) {
        return ((android.os.IDeviceIdleController)iin);
      }
      return new android.os.IDeviceIdleController.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_addPowerSaveWhitelistApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.addPowerSaveWhitelistApp(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_addPowerSaveWhitelistApps:
        {
          java.util.List<java.lang.String> _arg0;
          _arg0 = data.createStringArrayList();
          int _result = this.addPowerSaveWhitelistApps(_arg0);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_removePowerSaveWhitelistApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.removePowerSaveWhitelistApp(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_removeSystemPowerWhitelistApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.removeSystemPowerWhitelistApp(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_restoreSystemPowerWhitelistApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.restoreSystemPowerWhitelistApp(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_getRemovedSystemPowerWhitelistApps:
        {
          java.lang.String[] _result = this.getRemovedSystemPowerWhitelistApps();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getSystemPowerWhitelistExceptIdle:
        {
          java.lang.String[] _result = this.getSystemPowerWhitelistExceptIdle();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getSystemPowerWhitelist:
        {
          java.lang.String[] _result = this.getSystemPowerWhitelist();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getUserPowerWhitelist:
        {
          java.lang.String[] _result = this.getUserPowerWhitelist();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getFullPowerWhitelistExceptIdle:
        {
          java.lang.String[] _result = this.getFullPowerWhitelistExceptIdle();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getFullPowerWhitelist:
        {
          java.lang.String[] _result = this.getFullPowerWhitelist();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getAppIdWhitelistExceptIdle:
        {
          int[] _result = this.getAppIdWhitelistExceptIdle();
          reply.writeNoException();
          reply.writeIntArray(_result);
          break;
        }
        case TRANSACTION_getAppIdWhitelist:
        {
          int[] _result = this.getAppIdWhitelist();
          reply.writeNoException();
          reply.writeIntArray(_result);
          break;
        }
        case TRANSACTION_getAppIdUserWhitelist:
        {
          int[] _result = this.getAppIdUserWhitelist();
          reply.writeNoException();
          reply.writeIntArray(_result);
          break;
        }
        case TRANSACTION_getAppIdTempWhitelist:
        {
          int[] _result = this.getAppIdTempWhitelist();
          reply.writeNoException();
          reply.writeIntArray(_result);
          break;
        }
        case TRANSACTION_isPowerSaveWhitelistExceptIdleApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.isPowerSaveWhitelistExceptIdleApp(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isPowerSaveWhitelistApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.isPowerSaveWhitelistApp(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_addPowerSaveTempWhitelistApp:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          long _arg1;
          _arg1 = data.readLong();
          int _arg2;
          _arg2 = data.readInt();
          int _arg3;
          _arg3 = data.readInt();
          java.lang.String _arg4;
          _arg4 = data.readString();
          this.addPowerSaveTempWhitelistApp(_arg0, _arg1, _arg2, _arg3, _arg4);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_addPowerSaveTempWhitelistAppForMms:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          int _arg1;
          _arg1 = data.readInt();
          int _arg2;
          _arg2 = data.readInt();
          java.lang.String _arg3;
          _arg3 = data.readString();
          long _result = this.addPowerSaveTempWhitelistAppForMms(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_addPowerSaveTempWhitelistAppForSms:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          int _arg1;
          _arg1 = data.readInt();
          int _arg2;
          _arg2 = data.readInt();
          java.lang.String _arg3;
          _arg3 = data.readString();
          long _result = this.addPowerSaveTempWhitelistAppForSms(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_whitelistAppTemporarily:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          int _arg1;
          _arg1 = data.readInt();
          int _arg2;
          _arg2 = data.readInt();
          java.lang.String _arg3;
          _arg3 = data.readString();
          long _result = this.whitelistAppTemporarily(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_exitIdle:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.exitIdle(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_setPreIdleTimeoutMode:
        {
          int _arg0;
          _arg0 = data.readInt();
          int _result = this.setPreIdleTimeoutMode(_arg0);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_resetPreIdleTimeoutMode:
        {
          this.resetPreIdleTimeoutMode();
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.os.IDeviceIdleController
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void addPowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addPowerSaveWhitelistApp, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public int addPowerSaveWhitelistApps(java.util.List<java.lang.String> packageNames) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringList(packageNames);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addPowerSaveWhitelistApps, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void removePowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removePowerSaveWhitelistApp, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      /**
       * Removes an app from the system whitelist. Calling restoreSystemPowerWhitelistApp will add
       * the app back into the system whitelist
       */
      @Override public void removeSystemPowerWhitelistApp(java.lang.String name) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeSystemPowerWhitelistApp, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void restoreSystemPowerWhitelistApp(java.lang.String name) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          boolean _status = mRemote.transact(Stub.TRANSACTION_restoreSystemPowerWhitelistApp, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public java.lang.String[] getRemovedSystemPowerWhitelistApps() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getRemovedSystemPowerWhitelistApps, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String[] getSystemPowerWhitelistExceptIdle() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getSystemPowerWhitelistExceptIdle, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String[] getSystemPowerWhitelist() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getSystemPowerWhitelist, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String[] getUserPowerWhitelist() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getUserPowerWhitelist, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String[] getFullPowerWhitelistExceptIdle() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getFullPowerWhitelistExceptIdle, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String[] getFullPowerWhitelist() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getFullPowerWhitelist, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int[] getAppIdWhitelistExceptIdle() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getAppIdWhitelistExceptIdle, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createIntArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int[] getAppIdWhitelist() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getAppIdWhitelist, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createIntArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int[] getAppIdUserWhitelist() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getAppIdUserWhitelist, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createIntArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int[] getAppIdTempWhitelist() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getAppIdTempWhitelist, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createIntArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isPowerSaveWhitelistExceptIdleApp(java.lang.String name) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isPowerSaveWhitelistExceptIdleApp, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean isPowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isPowerSaveWhitelistApp, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void addPowerSaveTempWhitelistApp(java.lang.String name, long duration, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          _data.writeLong(duration);
          _data.writeInt(userId);
          _data.writeInt(reasonCode);
          _data.writeString(reason);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addPowerSaveTempWhitelistApp, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public long addPowerSaveTempWhitelistAppForMms(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          _data.writeInt(userId);
          _data.writeInt(reasonCode);
          _data.writeString(reason);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addPowerSaveTempWhitelistAppForMms, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public long addPowerSaveTempWhitelistAppForSms(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          _data.writeInt(userId);
          _data.writeInt(reasonCode);
          _data.writeString(reason);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addPowerSaveTempWhitelistAppForSms, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public long whitelistAppTemporarily(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          _data.writeInt(userId);
          _data.writeInt(reasonCode);
          _data.writeString(reason);
          boolean _status = mRemote.transact(Stub.TRANSACTION_whitelistAppTemporarily, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void exitIdle(java.lang.String reason) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(reason);
          boolean _status = mRemote.transact(Stub.TRANSACTION_exitIdle, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public int setPreIdleTimeoutMode(int Mode) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(Mode);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setPreIdleTimeoutMode, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void resetPreIdleTimeoutMode() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_resetPreIdleTimeoutMode, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    /** @hide */
    public static final java.lang.String DESCRIPTOR = "android.os.IDeviceIdleController";
    static final int TRANSACTION_addPowerSaveWhitelistApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_addPowerSaveWhitelistApps = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_removePowerSaveWhitelistApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_removeSystemPowerWhitelistApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_restoreSystemPowerWhitelistApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_getRemovedSystemPowerWhitelistApps = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_getSystemPowerWhitelistExceptIdle = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_getSystemPowerWhitelist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_getUserPowerWhitelist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_getFullPowerWhitelistExceptIdle = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_getFullPowerWhitelist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
    static final int TRANSACTION_getAppIdWhitelistExceptIdle = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
    static final int TRANSACTION_getAppIdWhitelist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
    static final int TRANSACTION_getAppIdUserWhitelist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
    static final int TRANSACTION_getAppIdTempWhitelist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
    static final int TRANSACTION_isPowerSaveWhitelistExceptIdleApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
    static final int TRANSACTION_isPowerSaveWhitelistApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
    static final int TRANSACTION_addPowerSaveTempWhitelistApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
    static final int TRANSACTION_addPowerSaveTempWhitelistAppForMms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
    static final int TRANSACTION_addPowerSaveTempWhitelistAppForSms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
    static final int TRANSACTION_whitelistAppTemporarily = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
    static final int TRANSACTION_exitIdle = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
    static final int TRANSACTION_setPreIdleTimeoutMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
    static final int TRANSACTION_resetPreIdleTimeoutMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
  }
  public void addPowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException;
  public int addPowerSaveWhitelistApps(java.util.List<java.lang.String> packageNames) throws android.os.RemoteException;
  public void removePowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException;
  /**
   * Removes an app from the system whitelist. Calling restoreSystemPowerWhitelistApp will add
   * the app back into the system whitelist
   */
  public void removeSystemPowerWhitelistApp(java.lang.String name) throws android.os.RemoteException;
  public void restoreSystemPowerWhitelistApp(java.lang.String name) throws android.os.RemoteException;
  public java.lang.String[] getRemovedSystemPowerWhitelistApps() throws android.os.RemoteException;
  public java.lang.String[] getSystemPowerWhitelistExceptIdle() throws android.os.RemoteException;
  public java.lang.String[] getSystemPowerWhitelist() throws android.os.RemoteException;
  public java.lang.String[] getUserPowerWhitelist() throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 30, trackingBug = 170729553L)
  public java.lang.String[] getFullPowerWhitelistExceptIdle() throws android.os.RemoteException;
  public java.lang.String[] getFullPowerWhitelist() throws android.os.RemoteException;
  public int[] getAppIdWhitelistExceptIdle() throws android.os.RemoteException;
  public int[] getAppIdWhitelist() throws android.os.RemoteException;
  public int[] getAppIdUserWhitelist() throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 30, trackingBug = 170729553L)
  public int[] getAppIdTempWhitelist() throws android.os.RemoteException;
  public boolean isPowerSaveWhitelistExceptIdleApp(java.lang.String name) throws android.os.RemoteException;
  public boolean isPowerSaveWhitelistApp(java.lang.String name) throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 30, publicAlternatives = "Use SystemApi {@code PowerExemptionManager#addToTemporaryAllowList(String, int, int, String)}.")
  public void addPowerSaveTempWhitelistApp(java.lang.String name, long duration, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException;
  public long addPowerSaveTempWhitelistAppForMms(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException;
  public long addPowerSaveTempWhitelistAppForSms(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException;
  public long whitelistAppTemporarily(java.lang.String name, int userId, int reasonCode, java.lang.String reason) throws android.os.RemoteException;
  public void exitIdle(java.lang.String reason) throws android.os.RemoteException;
  public int setPreIdleTimeoutMode(int Mode) throws android.os.RemoteException;
  public void resetPreIdleTimeoutMode() throws android.os.RemoteException;
}
