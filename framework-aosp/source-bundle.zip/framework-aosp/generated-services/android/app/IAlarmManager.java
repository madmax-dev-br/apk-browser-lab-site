/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.app;
/**
 * System private API for talking with the alarm manager service.
 * 
 * {@hide}
 */
public interface IAlarmManager extends android.os.IInterface
{
  /** Default implementation for IAlarmManager. */
  public static class Default implements android.app.IAlarmManager
  {
    /** windowLength == 0 means exact; windowLength < 0 means the let the OS decide */
    @Override public void set(java.lang.String callingPackage, int type, long triggerAtTime, long windowLength, long interval, int flags, android.app.PendingIntent operation, android.app.IAlarmListener listener, java.lang.String listenerTag, android.os.WorkSource workSource, android.app.AlarmManager.AlarmClockInfo alarmClock) throws android.os.RemoteException
    {
    }
    @Override public boolean setTime(long millis) throws android.os.RemoteException
    {
      return false;
    }
    @Override public void setTimeZone(java.lang.String zone) throws android.os.RemoteException
    {
    }
    @Override public void remove(android.app.PendingIntent operation, android.app.IAlarmListener listener) throws android.os.RemoteException
    {
    }
    @Override public long getNextWakeFromIdleTime() throws android.os.RemoteException
    {
      return 0L;
    }
    @Override public android.app.AlarmManager.AlarmClockInfo getNextAlarmClock(int userId) throws android.os.RemoteException
    {
      return null;
    }
    @Override public long currentNetworkTimeMillis() throws android.os.RemoteException
    {
      return 0L;
    }
    @Override public boolean canScheduleExactAlarms(java.lang.String packageName) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean hasScheduleExactAlarm(java.lang.String packageName, int userId) throws android.os.RemoteException
    {
      return false;
    }
    @Override public int getConfigVersion() throws android.os.RemoteException
    {
      return 0;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.app.IAlarmManager
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.app.IAlarmManager interface,
     * generating a proxy if needed.
     */
    public static android.app.IAlarmManager asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.app.IAlarmManager))) {
        return ((android.app.IAlarmManager)iin);
      }
      return new android.app.IAlarmManager.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_set:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          int _arg1;
          _arg1 = data.readInt();
          long _arg2;
          _arg2 = data.readLong();
          long _arg3;
          _arg3 = data.readLong();
          long _arg4;
          _arg4 = data.readLong();
          int _arg5;
          _arg5 = data.readInt();
          android.app.PendingIntent _arg6;
          _arg6 = _Parcel.readTypedObject(data, android.app.PendingIntent.CREATOR);
          android.app.IAlarmListener _arg7;
          _arg7 = android.app.IAlarmListener.Stub.asInterface(data.readStrongBinder());
          java.lang.String _arg8;
          _arg8 = data.readString();
          android.os.WorkSource _arg9;
          _arg9 = _Parcel.readTypedObject(data, android.os.WorkSource.CREATOR);
          android.app.AlarmManager.AlarmClockInfo _arg10;
          _arg10 = _Parcel.readTypedObject(data, android.app.AlarmManager.AlarmClockInfo.CREATOR);
          this.set(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_setTime:
        {
          long _arg0;
          _arg0 = data.readLong();
          boolean _result = this.setTime(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setTimeZone:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.setTimeZone(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_remove:
        {
          android.app.PendingIntent _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.app.PendingIntent.CREATOR);
          android.app.IAlarmListener _arg1;
          _arg1 = android.app.IAlarmListener.Stub.asInterface(data.readStrongBinder());
          this.remove(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_getNextWakeFromIdleTime:
        {
          long _result = this.getNextWakeFromIdleTime();
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_getNextAlarmClock:
        {
          int _arg0;
          _arg0 = data.readInt();
          android.app.AlarmManager.AlarmClockInfo _result = this.getNextAlarmClock(_arg0);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_currentNetworkTimeMillis:
        {
          long _result = this.currentNetworkTimeMillis();
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_canScheduleExactAlarms:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.canScheduleExactAlarms(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_hasScheduleExactAlarm:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          int _arg1;
          _arg1 = data.readInt();
          boolean _result = this.hasScheduleExactAlarm(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getConfigVersion:
        {
          int _result = this.getConfigVersion();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.app.IAlarmManager
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /** windowLength == 0 means exact; windowLength < 0 means the let the OS decide */
      @Override public void set(java.lang.String callingPackage, int type, long triggerAtTime, long windowLength, long interval, int flags, android.app.PendingIntent operation, android.app.IAlarmListener listener, java.lang.String listenerTag, android.os.WorkSource workSource, android.app.AlarmManager.AlarmClockInfo alarmClock) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(callingPackage);
          _data.writeInt(type);
          _data.writeLong(triggerAtTime);
          _data.writeLong(windowLength);
          _data.writeLong(interval);
          _data.writeInt(flags);
          _Parcel.writeTypedObject(_data, operation, 0);
          _data.writeStrongInterface(listener);
          _data.writeString(listenerTag);
          _Parcel.writeTypedObject(_data, workSource, 0);
          _Parcel.writeTypedObject(_data, alarmClock, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_set, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public boolean setTime(long millis) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(millis);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setTime, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void setTimeZone(java.lang.String zone) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(zone);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setTimeZone, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void remove(android.app.PendingIntent operation, android.app.IAlarmListener listener) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, operation, 0);
          _data.writeStrongInterface(listener);
          boolean _status = mRemote.transact(Stub.TRANSACTION_remove, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public long getNextWakeFromIdleTime() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getNextWakeFromIdleTime, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public android.app.AlarmManager.AlarmClockInfo getNextAlarmClock(int userId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.app.AlarmManager.AlarmClockInfo _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(userId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getNextAlarmClock, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.app.AlarmManager.AlarmClockInfo.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public long currentNetworkTimeMillis() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_currentNetworkTimeMillis, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean canScheduleExactAlarms(java.lang.String packageName) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(packageName);
          boolean _status = mRemote.transact(Stub.TRANSACTION_canScheduleExactAlarms, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean hasScheduleExactAlarm(java.lang.String packageName, int userId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(packageName);
          _data.writeInt(userId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_hasScheduleExactAlarm, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int getConfigVersion() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getConfigVersion, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    /** @hide */
    public static final java.lang.String DESCRIPTOR = "android.app.IAlarmManager";
    static final int TRANSACTION_set = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_setTime = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_setTimeZone = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_remove = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_getNextWakeFromIdleTime = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_getNextAlarmClock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_currentNetworkTimeMillis = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_canScheduleExactAlarms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_hasScheduleExactAlarm = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_getConfigVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
  }
  /** windowLength == 0 means exact; windowLength < 0 means the let the OS decide */
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 30, trackingBug = 170729553L)
  public void set(java.lang.String callingPackage, int type, long triggerAtTime, long windowLength, long interval, int flags, android.app.PendingIntent operation, android.app.IAlarmListener listener, java.lang.String listenerTag, android.os.WorkSource workSource, android.app.AlarmManager.AlarmClockInfo alarmClock) throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 30, trackingBug = 170729553L)
  public boolean setTime(long millis) throws android.os.RemoteException;
  public void setTimeZone(java.lang.String zone) throws android.os.RemoteException;
  public void remove(android.app.PendingIntent operation, android.app.IAlarmListener listener) throws android.os.RemoteException;
  public long getNextWakeFromIdleTime() throws android.os.RemoteException;
  @android.compat.annotation.UnsupportedAppUsage(maxTargetSdk = 30, trackingBug = 170729553L)
  public android.app.AlarmManager.AlarmClockInfo getNextAlarmClock(int userId) throws android.os.RemoteException;
  public long currentNetworkTimeMillis() throws android.os.RemoteException;
  public boolean canScheduleExactAlarms(java.lang.String packageName) throws android.os.RemoteException;
  public boolean hasScheduleExactAlarm(java.lang.String packageName, int userId) throws android.os.RemoteException;
  public int getConfigVersion() throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
