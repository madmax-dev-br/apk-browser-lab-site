// Compile-only declaration of a hidden Android/libcore API that the pinned java.time sources reference; excluded from framework.dex. At run time any call into it
// fails explicitly (the Android implementation is ICU4J-backed locale data, which the browser VM does not provide).
package dalvik.annotation.codegen; import java.lang.annotation.*; @Retention(RetentionPolicy.CLASS) @Target(ElementType.METHOD) public @interface CovariantReturnType { Class<?> returnType(); int presentAfter(); @Retention(RetentionPolicy.CLASS) @Target(ElementType.METHOD) @interface UnderrideReturnType {} }
