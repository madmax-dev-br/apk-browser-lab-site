// Compile-only declaration of a hidden Android/libcore API that the pinned java.time sources reference; excluded from framework.dex. At run time any call into it
// fails explicitly (the Android implementation is ICU4J-backed locale data, which the browser VM does not provide).
package com.android.icu.util; public class ExtendedTimeZone { public static ExtendedTimeZone getInstance(String id){throw new AssertionError();} public java.time.zone.ZoneRules createZoneRules(){throw new AssertionError();} }
