// Compile-only marker annotation; excluded from framework.dex.
package sun.reflect; import java.lang.annotation.*; @Retention(RetentionPolicy.RUNTIME) @Target({ElementType.METHOD}) public @interface CallerSensitive {}
