// Compile-only declaration; excluded from framework.dex. No runtime implementation: such calls fail explicitly.
package sun.reflect.misc; public class ReflectUtil { public static void checkPackageAccess(Class<?> c){throw new AssertionError();} public static boolean needsPackageAccessCheck(ClassLoader from,ClassLoader to){throw new AssertionError();} }
