// Compile-only declaration (caller-sensitive checks in ObjectStreamField.getType); excluded from framework.dex. No runtime implementation: such calls fail explicitly.
package sun.reflect; public class Reflection { public static Class<?> getCallerClass(){throw new AssertionError();} }
