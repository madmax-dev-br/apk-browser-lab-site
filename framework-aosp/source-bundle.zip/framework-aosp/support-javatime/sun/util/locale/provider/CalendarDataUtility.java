// Compile-only declaration of a hidden Android/libcore API that the pinned java.time sources reference; excluded from framework.dex. At run time any call into it
// fails explicitly (the Android implementation is ICU4J-backed locale data, which the browser VM does not provide).
package sun.util.locale.provider; import java.util.Locale; import java.util.Map;
public class CalendarDataUtility { public static String retrieveJavaTimeFieldValueName(String id,int field,int value,int style,Locale locale){throw new AssertionError();}
 public static Map<String,Integer> retrieveJavaTimeFieldValueNames(String id,int field,int style,Locale locale){throw new AssertionError();}
 public static Locale findRegionOverride(Locale l){throw new AssertionError();} }
