// Compile-only declaration of a hidden Android/libcore API that the pinned java.time sources reference; excluded from framework.dex. At run time any call into it
// fails explicitly (the Android implementation is ICU4J-backed locale data, which the browser VM does not provide).
package sun.util.locale.provider; public class LocaleResources { public java.util.ResourceBundle getJavaTimeFormatData(){throw new AssertionError();} }
