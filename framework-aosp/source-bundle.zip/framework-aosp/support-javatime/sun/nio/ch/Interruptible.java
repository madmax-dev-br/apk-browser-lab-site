// Compile-only mirror of the pinned sun.nio.ch.Interruptible so the java.lang.Thread stub can declare the hidden blockedOn(Interruptible); excluded from framework.dex (the pinned original is compiled into it).
package sun.nio.ch; public interface Interruptible { void interrupt(Thread target); }
