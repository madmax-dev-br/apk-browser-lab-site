// Compile-only mirror of the pipe sink channel named by FileChannelImpl.transferToTrustedChannel's instanceof test; excluded from framework.dex.
package sun.nio.ch; public abstract class SinkChannelImpl extends java.nio.channels.spi.AbstractInterruptibleChannel implements java.nio.channels.WritableByteChannel { }
