// Compile-only mirror of the async file channel FileLockImpl.release() distinguishes; excluded from framework.dex.
package sun.nio.ch; public abstract class AsynchronousFileChannelImpl { public abstract void release(java.nio.channels.FileLock fli) throws java.io.IOException; }
