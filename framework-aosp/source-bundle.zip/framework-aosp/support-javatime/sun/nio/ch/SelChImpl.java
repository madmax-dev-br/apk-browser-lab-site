// Compile-only mirror: the pinned FileChannelImpl tests transfer targets with instanceof/cast against the selector-channel contract. The selector/pipe/socket channel stack is not part of this framework build; excluded from framework.dex.
package sun.nio.ch; public interface SelChImpl extends java.io.Closeable { java.io.FileDescriptor getFD(); int getFDVal(); }
