// Compile-only declaration (javac emits $deserializeLambda$ for Serializable lambdas); excluded from framework.dex. Android has no SerializedLambda; deserializing a lambda never runs here.
package java.lang.invoke; public final class SerializedLambda implements java.io.Serializable {
 public String getCapturingClass(){throw new AssertionError();} public String getFunctionalInterfaceClass(){throw new AssertionError();} public String getFunctionalInterfaceMethodName(){throw new AssertionError();}
 public String getFunctionalInterfaceMethodSignature(){throw new AssertionError();} public String getImplClass(){throw new AssertionError();} public String getImplMethodName(){throw new AssertionError();}
 public String getImplMethodSignature(){throw new AssertionError();} public int getImplMethodKind(){throw new AssertionError();} public final String getInstantiatedMethodType(){throw new AssertionError();}
 public int getCapturedArgCount(){throw new AssertionError();} public Object getCapturedArg(int i){throw new AssertionError();} }
