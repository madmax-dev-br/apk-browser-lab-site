// Compile-only Java lambda bootstrap signatures; D8 desugars source lambdas into classes. altMetafactory is javac's bootstrap for Serializable/marker lambdas.
package java.lang.invoke; public class LambdaMetafactory {
 public static native CallSite metafactory(MethodHandles.Lookup caller,String name,MethodType factoryType,MethodType samMethodType,MethodHandle implMethod,MethodType instantiatedMethodType) throws LambdaConversionException;
 public static native CallSite altMetafactory(MethodHandles.Lookup caller,String name,MethodType factoryType,Object... args) throws LambdaConversionException;
}
