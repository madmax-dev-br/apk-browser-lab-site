// Compile-only subset of java.util.TimeZone plus the hidden createGmtOffsetString(boolean,boolean,int) of android-13.0.0_r1 libcore; excluded from framework.dex.
package java.util; public abstract class TimeZone implements java.io.Serializable, Cloneable {
 public static final int SHORT = 0, LONG = 1;
 public static TimeZone getDefault(){throw new AssertionError();} public static TimeZone getTimeZone(String id){throw new AssertionError();} public static TimeZone getTimeZone(java.time.ZoneId zone){throw new AssertionError();}
 public String getID(){throw new AssertionError();} public java.time.ZoneId toZoneId(){throw new AssertionError();} public abstract int getRawOffset(); public int getDSTSavings(){throw new AssertionError();}
 public int getOffset(long date){throw new AssertionError();} public boolean useDaylightTime(){throw new AssertionError();} public boolean inDaylightTime(Date date){throw new AssertionError();} public static String[] getAvailableIDs(){throw new AssertionError();}
 public static String createGmtOffsetString(boolean includeGmt, boolean includeMinuteSeparator, int offsetMillis){throw new AssertionError();} }
