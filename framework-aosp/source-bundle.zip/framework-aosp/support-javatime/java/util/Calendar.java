// Compile-only subset of java.util.Calendar plus the hidden getJapaneseImperialInstance of android-13.0.0_r1 libcore; excluded from framework.dex.
package java.util; public abstract class Calendar implements java.io.Serializable, Cloneable, Comparable<Calendar> {
 public static final int ERA = 0, YEAR = 1, MONTH = 2, DAY_OF_YEAR = 6, DAY_OF_WEEK = 7, AM_PM = 9,
  SUNDAY = 1, MONDAY = 2, TUESDAY = 3, WEDNESDAY = 4, THURSDAY = 5, FRIDAY = 6, SATURDAY = 7, JANUARY = 0, DECEMBER = 11,
  ALL_STYLES = 0, SHORT = 1, LONG = 2, NARROW_FORMAT = 4, NARROW_STANDALONE = 32772, SHORT_FORMAT = 1, LONG_FORMAT = 2, STANDALONE_MASK = 0x8000, SHORT_STANDALONE = 32769, LONG_STANDALONE = 32770;
 public static Calendar getInstance(TimeZone zone, Locale locale){throw new AssertionError();} public static Calendar getInstance(){throw new AssertionError();}
 public static Calendar getJapaneseImperialInstance(TimeZone zone, Locale aLocale){throw new AssertionError();}
 public int get(int field){throw new AssertionError();} public final void set(int year,int month,int date){throw new AssertionError();} public final void clear(){throw new AssertionError();} public final Date getTime(){throw new AssertionError();} public long getTimeInMillis(){throw new AssertionError();}
 public int getActualMaximum(int field){throw new AssertionError();} public int compareTo(Calendar o){throw new AssertionError();} public boolean isLenient(){throw new AssertionError();} public void setLenient(boolean b){throw new AssertionError();}
 public abstract int getMaximum(int field); public abstract int getLeastMaximum(int field); public abstract int getGreatestMinimum(int field); public abstract int getMinimum(int field); public final void set(int field,int value){throw new AssertionError();} }
