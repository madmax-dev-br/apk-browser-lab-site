// Compile-only subset of java.util.LinkedHashMap plus hidden eldest() of android-13.0.0_r1 libcore; excluded from framework.dex.
package java.util; public class LinkedHashMap<K,V> extends HashMap<K,V> { public LinkedHashMap(int capacity,float loadFactor,boolean accessOrder){super(capacity,loadFactor);} public LinkedHashMap(){super();} public LinkedHashMap(Map<? extends K,? extends V> m){super(m);}
 protected boolean removeEldestEntry(Map.Entry<K,V> eldest){throw new AssertionError();} public Map.Entry<K,V> eldest(){throw new AssertionError();} }
