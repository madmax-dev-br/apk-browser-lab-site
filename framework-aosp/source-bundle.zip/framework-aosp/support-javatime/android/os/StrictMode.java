// Compile-only stub: the hidden StrictMode members android.os.Parcel (android-13.0.0_r1) calls. Not compiled into framework.dex; the runtime implements them in src/parcel-native.js.
package android.os;
public final class StrictMode {
  private StrictMode() {}
  public static boolean hasGatheredViolations() { throw new AssertionError(); }
  public static void clearGatheredViolations() { throw new AssertionError(); }
  public static void writeGatheredViolationsToParcel(Parcel p) { throw new AssertionError(); }
  public static void readAndHandleBinderCallViolations(Parcel p) { throw new AssertionError(); }
}
