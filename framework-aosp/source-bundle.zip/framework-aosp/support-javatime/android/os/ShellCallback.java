// Compile-only stub: IBinder.shellCommand names this hidden class in its signature. Not compiled into framework.dex.
package android.os;
public class ShellCallback {}
