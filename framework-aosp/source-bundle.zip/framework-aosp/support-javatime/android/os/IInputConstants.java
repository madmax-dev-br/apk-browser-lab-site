// Compile-only stub of the AIDL-generated constants interface android.os.IInputConstants (values inlined by javac; nothing of it is needed at run time).
package android.os;
public interface IInputConstants {
  int INPUT_EVENT_FLAG_IS_ACCESSIBILITY_EVENT = 0x800;
  int INVALID_INPUT_DEVICE_ID = -2;
  int DEFAULT_POINTER_ACCELERATION = 3;
}
