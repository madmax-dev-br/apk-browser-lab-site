// Compile-only declaration (javatime-stubs): the hidden WorkSource members the pinned android.location.LocationRequest uses. WorkSource is provided by the lab's host (src/misc-platform-host.js); never packaged.
package android.os;
public class WorkSource implements Parcelable {
    public WorkSource() { }
    public WorkSource(WorkSource other) { }
    public boolean isEmpty() { return true; }
    public int describeContents() { return 0; }
    public void writeToParcel(Parcel dest, int flags) { }
    public static final Parcelable.Creator<WorkSource> CREATOR = null;
}
