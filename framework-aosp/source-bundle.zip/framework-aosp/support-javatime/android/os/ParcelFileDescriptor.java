// Compile-only stub: the hidden constructor android.os.Parcel.readFileDescriptor uses. Not compiled into framework.dex.
package android.os;
public class ParcelFileDescriptor {
  public ParcelFileDescriptor(java.io.FileDescriptor fd) { throw new AssertionError(); }
  public java.io.FileDescriptor getFileDescriptor() { throw new AssertionError(); }
}
