// Compile-only platform/IPC metadata; excluded from runtime.
package android.compat.annotation; public @interface EnabledAfter { int targetSdkVersion(); }
