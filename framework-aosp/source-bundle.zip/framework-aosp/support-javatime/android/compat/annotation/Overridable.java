// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package android.compat.annotation; public @interface Overridable {}
