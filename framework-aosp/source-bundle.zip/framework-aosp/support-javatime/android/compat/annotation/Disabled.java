// Compile-only annotation metadata; excluded from framework.dex.
package android.compat.annotation; import java.lang.annotation.*; @Retention(RetentionPolicy.CLASS) @Target({ElementType.TYPE,ElementType.FIELD,ElementType.METHOD,ElementType.CONSTRUCTOR}) public @interface Disabled {  }
