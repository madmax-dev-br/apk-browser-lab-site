// Compile-only annotation declaration. Never packaged into the executable boot DEX.
package android.compat.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE_USE,ElementType.TYPE,ElementType.FIELD,ElementType.METHOD,ElementType.PARAMETER,ElementType.CONSTRUCTOR,ElementType.LOCAL_VARIABLE,ElementType.ANNOTATION_TYPE})
public @interface UnsupportedAppUsage { int maxTargetSdk() default Integer.MAX_VALUE; long trackingBug() default 0; String expectedSignature() default ""; String implicitMember() default ""; String publicAlternatives() default ""; }
