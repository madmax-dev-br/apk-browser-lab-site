// Compile-only annotation declaration. Never packaged into the executable boot DEX.
package android.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.METHOD,ElementType.CONSTRUCTOR,ElementType.TYPE})
public @interface WorkerThread {  }
