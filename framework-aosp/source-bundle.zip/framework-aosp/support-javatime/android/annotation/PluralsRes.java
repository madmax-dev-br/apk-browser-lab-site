// Compile-only: android.annotation.PluralsRes (resource-type lint annotation, retention SOURCE); nothing of it reaches the DEX.
package android.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.SOURCE) @Target({ElementType.METHOD, ElementType.PARAMETER, ElementType.FIELD, ElementType.LOCAL_VARIABLE})
public @interface PluralsRes {}
