// Compile-only stub: hidden AppOpsManager members android.os.Parcel calls around transactions. Not compiled into framework.dex.
package android.app;
public class AppOpsManager {
  public static void prefixParcelWithAppOpsIfNeeded(android.os.Parcel p) { throw new AssertionError(); }
  public static void readAndLogNotedAppops(android.os.Parcel p) { throw new AssertionError(); }
}
