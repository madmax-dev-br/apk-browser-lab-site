// Compile-only declaration of a hidden Android/libcore API that the pinned java.time sources reference; excluded from framework.dex. At run time any call into it
// fails explicitly (the Android implementation is ICU4J-backed locale data, which the browser VM does not provide).
package libcore.icu; public final class TimeZoneNames { public static void getDisplayNames(android.icu.text.TimeZoneNames names,String id,android.icu.text.TimeZoneNames.NameType[] types,long date,String[] dest,int offset){throw new AssertionError();} }
