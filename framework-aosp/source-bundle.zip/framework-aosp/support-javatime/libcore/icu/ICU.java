// Compile-only declaration of a hidden Android/libcore API that the pinned java.time sources reference; excluded from framework.dex. At run time any call into it
// fails explicitly (the Android implementation is ICU4J-backed locale data, which the browser VM does not provide).
package libcore.icu; public final class ICU { public static com.android.icu.util.ExtendedCalendar getExtendedCalendar(java.util.Locale l,String type){throw new AssertionError();}
 public static String transformIcuDateTimePattern_forJavaTime(String p){throw new AssertionError();} public static String convertToTzId(String id){throw new AssertionError();} }
