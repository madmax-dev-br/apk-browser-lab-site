package android.app;

import android.content.Context;

/** Lab-authored: AlarmManager's constructor is package-private (SystemServiceRegistry sits in android.app), so the lab's SystemServiceRegistry equivalent builds it from here. */
public final class LabAlarmManagerFactory {
    private LabAlarmManagerFactory() {}

    public static AlarmManager create(IAlarmManager service, Context context) { return new AlarmManager(service, context); }
}
