package dev.apkweb.services;

import android.os.RemoteException;
import dev.apkweb.services.refusals.RefusingDeviceIdleController;

/**
 * IDeviceIdleController of the virtual device (android-13.0.0_r1 DeviceIdleController): the app is not on the power-save allowlist, so battery optimizations apply to it
 * (PowerManager.isIgnoringBatteryOptimizations is false). Changing the allowlist, temporary allowlisting and idle control are refused naming the interface method.
 */
final class LabDeviceIdleService extends RefusingDeviceIdleController {
    @Override public boolean isPowerSaveWhitelistApp(String name) throws RemoteException { return false; }

    @Override public boolean isPowerSaveWhitelistExceptIdleApp(String name) throws RemoteException { return false; }
}
