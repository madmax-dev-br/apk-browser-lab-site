package dev.apkweb.services;

import android.app.AlarmManager;
import android.app.IAlarmManager;
import android.app.LabAlarmManagerFactory;
import android.content.Context;
import android.os.DeviceIdleManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.IDeviceIdleController;
import android.os.IPowerManager;
import android.os.IThermalService;
import android.os.PowerExemptionManager;
import android.os.PowerManager;

/**
 * What android.app.SystemServiceRegistry does on a phone for the services the lab serves from Java: Context.getSystemService(name) builds the ORIGINAL manager class around the
 * IBinder the ServiceManager returns for it (here the registry in {@link LabServiceManager}). The page keeps one manager per name per VM (src/java-services-host.js caches it) and
 * asks for the names listed in {@link #NAMES}; the class of each is the same index of {@link #CLASSES} (getSystemService(Class) resolves through it).
 */
public final class LabSystemServices {
    private LabSystemServices() {}

    /** Context.*_SERVICE names served by Java managers, in the same order as {@link #CLASSES}. */
    public static final String[] NAMES = { "power", "alarm", "deviceidle", "power_exemption" };

    /** The original manager class of each name. */
    public static final String[] CLASSES = { "android.os.PowerManager", "android.app.AlarmManager", "android.os.DeviceIdleManager", "android.os.PowerExemptionManager" };

    private static IBinder binder(String name) {
        IBinder binder = LabServiceManager.getService(name);
        if (binder == null) throw new IllegalStateException("system service " + name + " is not registered in the lab's system_server");
        return binder;
    }

    /** The manager for a Context.*_SERVICE name, or null when this class does not serve it. */
    public static Object manager(Context context, String name) {
        if (name.equals("power")) return new PowerManager(context, IPowerManager.Stub.asInterface(binder("power")), IThermalService.Stub.asInterface(binder("thermalservice")), new Handler(context.getMainLooper()));
        if (name.equals("alarm")) return LabAlarmManagerFactory.create(IAlarmManager.Stub.asInterface(binder("alarm")), context);
        if (name.equals("deviceidle")) return new DeviceIdleManager(context, IDeviceIdleController.Stub.asInterface(binder("deviceidle")));
        if (name.equals("power_exemption")) return new PowerExemptionManager(context);
        return null;
    }
}
