package dev.apkweb.services;

/**
 * The web boundary of the in-process system_server: the few facts about the installed app and the virtual device that only the page knows (src/services-native.js binds each
 * native by its key `Ldev/apkweb/services/Host;-><name><descriptor>`). Time is NOT here: the services read System.currentTimeMillis, SystemClock and the main-thread Handler,
 * which all run on the VM's virtual clock and scheduler. Nothing in this class decides an answer; it only reports what the platform holds.
 */
public final class Host {
    private Host() {}

    /** The installed app's package name (the calling package of every binder call: the VM is one process, one app). */
    public static native String packageName();

    /** The app's Linux uid inside the virtual device. */
    public static native int uid();

    /** android:targetSdkVersion of the installed app (1 when the manifest has none, like the platform default). */
    public static native int targetSdk();

    /** True when the app declared `permission` and the device granted it (the same answer Context.checkSelfPermission gives). */
    public static native boolean holdsPermission(String permission);

    /** A line in the VM trace (what the JS hosts recorded with runtime.record), e.g. "ALARM fired 3". */
    public static native void record(String line);
}
