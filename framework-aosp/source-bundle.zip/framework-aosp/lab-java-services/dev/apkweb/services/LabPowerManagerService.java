package dev.apkweb.services;

import android.os.IBinder;
import android.os.IWakeLockCallback;
import android.os.PowerSaveState;
import android.os.RemoteException;
import android.os.WorkSource;
import dev.apkweb.services.refusals.RefusingPowerManager;
import java.util.HashMap;
import java.util.Map;

/**
 * IPowerManager of the virtual device (android-13.0.0_r1 PowerManagerService, as far as a phone with the screen on, no battery saver and no thermal HAL answers): the device is awake
 * and interactive, there is no battery saver, doze or low-power standby, and holding a wake lock has no further effect. The reference counting and the timeouts of a wake lock
 * are the original PowerManager.WakeLock in the manager; the service only keeps which tokens are held. Everything the device does not do (goToSleep, setPowerSaveModeEnabled,
 * ambient display, ...) is refused by {@link RefusingPowerManager} naming the interface method.
 */
final class LabPowerManagerService extends RefusingPowerManager {
    private static final class Held {
        final int flags; final String tag; final String packageName;
        Held(int flags, String tag, String packageName) { this.flags = flags; this.tag = tag; this.packageName = packageName; }
    }

    private final Map<IBinder, Held> held = new HashMap<IBinder, Held>();

    @Override public void acquireWakeLock(IBinder lock, int flags, String tag, String packageName, WorkSource ws, String historyTag, int displayId, IWakeLockCallback callback) throws RemoteException {
        synchronized (held) { held.put(lock, new Held(flags, tag, packageName)); }
    }

    @Override public void releaseWakeLock(IBinder lock, int flags) throws RemoteException {
        synchronized (held) { held.remove(lock); }
    }

    /** PARTIAL (1), SCREEN_DIM (6), SCREEN_BRIGHT (10), FULL (26) and DRAW (128) are supported; there is no proximity sensor and no doze. */
    @Override public boolean isWakeLockLevelSupported(int level) throws RemoteException {
        return level == 1 || level == 6 || level == 10 || level == 26 || level == 128;
    }

    @Override public boolean isInteractive() throws RemoteException { return true; }
    @Override public boolean isPowerSaveMode() throws RemoteException { return false; }
    @Override public boolean isDeviceIdleMode() throws RemoteException { return false; }
    @Override public boolean isLightDeviceIdleMode() throws RemoteException { return false; }
    @Override public boolean isLowPowerStandbySupported() throws RemoteException { return false; }
    @Override public boolean isLowPowerStandbyEnabled() throws RemoteException { return false; }
    @Override public boolean isBatteryDischargePredictionPersonalized() throws RemoteException { return false; }
    @Override public android.os.ParcelDuration getBatteryDischargePrediction() throws RemoteException { return null; }   // no battery model: null is the documented "unknown"

    /** Battery saver off: PowerSaveState with saver disabled, the unchanged location mode and the default brightness factor. */
    @Override public PowerSaveState getPowerSaveState(int serviceType) throws RemoteException {
        return new PowerSaveState.Builder().setBatterySaverEnabled(false).setGlobalBatterySaverEnabled(false).setLocationMode(0).setBrightnessFactor(0.5f).build();
    }

    @Override public void reboot(boolean confirm, String reason, boolean wait) throws RemoteException {
        throw new SecurityException("Neither user " + Host.uid() + " nor current process has android.permission.REBOOT.");
    }
}
