package dev.apkweb.services;

import android.os.Handler;
import android.os.IThermalStatusListener;
import android.os.Looper;
import android.os.RemoteException;
import dev.apkweb.services.refusals.RefusingThermalService;
import java.util.ArrayList;
import java.util.List;

/**
 * IThermalService of the virtual device (android-13.0.0_r1 ThermalManagerService with no thermal HAL): the status is THERMAL_STATUS_NONE, there is no headroom forecast (NaN, which
 * the API documents for "not available") and a status listener hears the current status once, on the main thread, right after it registers, like the service's own
 * post-registration callback. Temperatures, cooling devices and event listeners are refused naming the interface method.
 */
final class LabThermalService extends RefusingThermalService {
    private static final int THERMAL_STATUS_NONE = 0;

    private final List<IThermalStatusListener> statusListeners = new ArrayList<IThermalStatusListener>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public boolean registerThermalStatusListener(final IThermalStatusListener listener) throws RemoteException {
        synchronized (statusListeners) {
            if (statusListeners.contains(listener)) return false;
            statusListeners.add(listener);
        }
        handler.post(new Runnable() {
            @Override public void run() {
                synchronized (statusListeners) { if (!statusListeners.contains(listener)) return; }
                try { listener.onStatusChange(THERMAL_STATUS_NONE); } catch (RemoteException ignored) { }
            }
        });
        return true;
    }

    @Override public boolean unregisterThermalStatusListener(IThermalStatusListener listener) throws RemoteException {
        synchronized (statusListeners) { return statusListeners.remove(listener); }
    }

    @Override public int getCurrentThermalStatus() throws RemoteException { return THERMAL_STATUS_NONE; }

    @Override public float getThermalHeadroom(int forecastSeconds) throws RemoteException { return Float.NaN; }
}
