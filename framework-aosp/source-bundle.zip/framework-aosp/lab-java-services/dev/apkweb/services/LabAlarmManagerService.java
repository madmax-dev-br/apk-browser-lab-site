package dev.apkweb.services;

import android.app.AlarmManager;
import android.app.IAlarmCompleteListener;
import android.app.IAlarmListener;
import android.app.PendingIntent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.os.SystemClock;
import android.os.WorkSource;
import dev.apkweb.services.refusals.RefusingAlarmCompleteListener;
import dev.apkweb.services.refusals.RefusingAlarmManager;
import java.util.ArrayList;
import java.util.List;

/**
 * IAlarmManager of the virtual device (android-13.0.0_r1 AlarmManagerService, reduced to what a phone without Doze, standby buckets or batching does for one app): an alarm fires
 * when the VM clock reaches it (RTC types on the wall clock, ELAPSED types on the monotonic one), as PendingIntent.send() or, for the listener variants, IAlarmListener.doAlarm;
 * it is delivered on the main thread through the same Handler/Looper the app runs on, so it follows the virtual clock and the scheduler without any native. Setting an alarm for
 * the same PendingIntent or listener replaces the previous one, repeat intervals are raised to 60 s, an exact alarm of an app targeting API 31+ needs SCHEDULE_EXACT_ALARM or
 * USE_EXACT_ALARM, and a cancelled PendingIntent drops the alarm. Setting the clock or the time zone, and the other administrative calls, are refused by
 * {@link RefusingAlarmManager} naming the interface method.
 */
final class LabAlarmManagerService extends RefusingAlarmManager {
    private static final long MIN_INTERVAL = 60000L;   // AlarmManagerService.Constants.MIN_INTERVAL
    private static final long WINDOW_EXACT = 0L;       // AlarmManager.WINDOW_EXACT
    private static final int RTC_WAKEUP = 0, RTC = 1, ELAPSED_REALTIME_WAKEUP = 2, ELAPSED_REALTIME = 3;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Alarm> alarms = new ArrayList<Alarm>();
    private int nextId = 1;

    private final class Alarm implements Runnable {
        final int id = nextId++;
        final int type; long trigger; final long interval;
        final PendingIntent operation; final IAlarmListener listener; final AlarmManager.AlarmClockInfo clock;
        Alarm(int type, long trigger, long interval, PendingIntent operation, IAlarmListener listener, AlarmManager.AlarmClockInfo clock) {
            this.type = type; this.trigger = trigger; this.interval = interval; this.operation = operation; this.listener = listener; this.clock = clock;
        }
        @Override public void run() { fire(this); }
    }

    private static long now(int type) { return type == RTC_WAKEUP || type == RTC ? System.currentTimeMillis() : SystemClock.elapsedRealtime(); }

    private void arm(Alarm alarm) { handler.postDelayed(alarm, Math.max(1L, alarm.trigger - now(alarm.type))); }

    private void fire(Alarm alarm) {
        synchronized (alarms) { if (!alarms.contains(alarm)) return; }
        if (alarm.trigger - now(alarm.type) > 5) { arm(alarm); return; }   // the VM clock may not have reached it yet
        synchronized (alarms) { if (alarm.interval > 0) alarm.trigger += alarm.interval; else alarms.remove(alarm); }
        try {
            if (alarm.operation != null) alarm.operation.send();
            else alarm.listener.doAlarm(new Completion());
        } catch (PendingIntent.CanceledException e) {
            synchronized (alarms) { alarms.remove(alarm); }
            return;
        } catch (RemoteException e) {
            synchronized (alarms) { alarms.remove(alarm); }
            return;
        }
        Host.record("ALARM fired " + alarm.id);
        boolean again; synchronized (alarms) { again = alarm.interval > 0 && alarms.contains(alarm); }
        if (again) arm(alarm);
    }

    /** AlarmManagerService's IAlarmCompleteListener: the lab does not hold a wake lock for the duration of a listener alarm, so completion needs nothing. */
    private static final class Completion extends RefusingAlarmCompleteListener {
        @Override public void alarmComplete(IBinder who) throws RemoteException { }
    }

    private boolean exactAllowed() {
        return Host.targetSdk() < 31 || Host.holdsPermission("android.permission.SCHEDULE_EXACT_ALARM") || Host.holdsPermission("android.permission.USE_EXACT_ALARM");
    }

    @Override public void set(String callingPackage, int type, long triggerAtTime, long windowLength, long interval, int flags, PendingIntent operation, IAlarmListener listener,
            String listenerTag, WorkSource workSource, AlarmManager.AlarmClockInfo alarmClock) throws RemoteException {
        if (type < RTC_WAKEUP || type > ELAPSED_REALTIME) throw new IllegalArgumentException("Invalid alarm type " + type);
        if (operation == null && listener == null) return;   // "Alarm not scheduled because no operation or receiver"
        if ((windowLength == WINDOW_EXACT || alarmClock != null) && !exactAllowed()) {
            throw new SecurityException("Caller " + callingPackage + " needs to hold android.permission.SCHEDULE_EXACT_ALARM or android.permission.USE_EXACT_ALARM to set exact alarms.");
        }
        if (interval > 0 && interval < MIN_INTERVAL) interval = MIN_INTERVAL;   // the platform raises intervals below 60 s
        Alarm alarm = new Alarm(type, triggerAtTime, interval, operation, listener, alarmClock);
        synchronized (alarms) { removeMatching(operation, listener); alarms.add(alarm); }
        arm(alarm);
    }

    /** A new alarm replaces the previous one for the same PendingIntent (or listener). Caller holds the lock. */
    private void removeMatching(PendingIntent operation, IAlarmListener listener) {
        for (int i = alarms.size() - 1; i >= 0; i--) {
            Alarm alarm = alarms.get(i);
            boolean same = (operation != null && alarm.operation != null && alarm.operation.equals(operation)) || (listener != null && alarm.listener == listener);
            if (same) { handler.removeCallbacks(alarm); alarms.remove(i); }
        }
    }

    @Override public void remove(PendingIntent operation, IAlarmListener listener) throws RemoteException {
        synchronized (alarms) { removeMatching(operation, listener); }
    }

    /** The earliest pending AlarmClockInfo (AlarmManager.setAlarmClock), or null. */
    @Override public AlarmManager.AlarmClockInfo getNextAlarmClock(int userId) throws RemoteException {
        synchronized (alarms) {
            AlarmManager.AlarmClockInfo next = null;
            for (Alarm alarm : alarms) if (alarm.clock != null && (next == null || alarm.clock.getTriggerTime() < next.getTriggerTime())) next = alarm.clock;
            return next;
        }
    }

    @Override public boolean canScheduleExactAlarms(String packageName) throws RemoteException { return exactAllowed(); }
}
