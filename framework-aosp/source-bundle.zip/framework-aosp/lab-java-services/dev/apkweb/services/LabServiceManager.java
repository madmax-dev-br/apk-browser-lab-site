package dev.apkweb.services;

import android.os.IBinder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The registry of the virtual device's in-process system_server: name -> IBinder, what the native servicemanager process is on a phone. android.os.ServiceManager (a host class,
 * see src/java-services-host.js and docs/SERVICES.md) answers getService / checkService / waitForService / isDeclared / listServices from here. Every service is the lab's Java
 * implementation of the original AIDL interface (the generated Stub of framework-aosp/generated-services); the VM is one process, so the Binder is local and a manager's
 * IPowerManager.Stub.asInterface(binder) is the service object itself.
 *
 * A service is created the first time its name is asked for (the registry itself when the VM first touches it), so a page that never asks pays nothing. Adding a service = one line
 * in the static block below plus its class (docs/SERVICES.md, "Como adicionar o próximo serviço").
 */
public final class LabServiceManager {
    private LabServiceManager() {}

    /** Creates a service on first use. */
    public interface Factory { IBinder create(); }

    private static final Map<String, Object> entries = new LinkedHashMap<String, Object>();   // name -> IBinder | Factory

    static {
        register("power", new Factory() { public IBinder create() { return new LabPowerManagerService(); } });
        register("thermalservice", new Factory() { public IBinder create() { return new LabThermalService(); } });
        register("alarm", new Factory() { public IBinder create() { return new LabAlarmManagerService(); } });
        register("deviceidle", new Factory() { public IBinder create() { return new LabDeviceIdleService(); } });
        register("android.system.keystore2.IKeystoreService/default", new Factory() { public IBinder create() { return dev.apkweb.keystore.LabKeystore.service(); } });
    }

    private static void register(String name, Factory factory) { entries.put(name, factory); }

    /** ServiceManager.getService / checkService / waitForService: the service, or null when the device has none of that name. */
    public static synchronized IBinder getService(String name) {
        if (name == null) return null;
        Object entry = entries.get(name);
        if (entry instanceof Factory) { IBinder binder = ((Factory) entry).create(); entries.put(name, binder); return binder; }
        return (IBinder) entry;
    }

    /** ServiceManager.isDeclared. */
    public static synchronized boolean isDeclared(String name) { return name != null && entries.containsKey(name); }

    /** ServiceManager.listServices: the names in registration order. */
    public static synchronized String[] listServices() {
        List<String> names = new ArrayList<String>(entries.keySet());
        return names.toArray(new String[0]);
    }
}
