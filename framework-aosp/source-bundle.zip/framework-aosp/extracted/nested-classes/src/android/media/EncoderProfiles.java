/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.media;
import android.annotation.IntDef;
import android.annotation.NonNull;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
// Compilation shell only: the enclosing class files are excluded from the DEX.
public final class EncoderProfiles {
    public final static class AudioProfile {
        /**
         * The audio encoder being used for the audio track.
         * @see android.media.MediaRecorder.AudioEncoder
         */
        public @MediaRecorder.AudioEncoderValues int getCodec() {
            return codec;
        }

        /**
         * The media type of the audio encoder being used for the video track
         * @see android.media.MediaFormat#KEY_MIME
         */
        public @NonNull String getMediaType() {
            if (codec == MediaRecorder.AudioEncoder.AMR_NB) {
                return MediaFormat.MIMETYPE_AUDIO_AMR_NB;
            } else if (codec == MediaRecorder.AudioEncoder.AMR_WB) {
                return MediaFormat.MIMETYPE_AUDIO_AMR_WB;
            } else if (codec == MediaRecorder.AudioEncoder.AAC
                    || codec == MediaRecorder.AudioEncoder.HE_AAC
                    || codec == MediaRecorder.AudioEncoder.AAC_ELD) {
                return MediaFormat.MIMETYPE_AUDIO_AAC;
            } else if (codec == MediaRecorder.AudioEncoder.VORBIS) {
                return MediaFormat.MIMETYPE_AUDIO_VORBIS;
            } else if (codec == MediaRecorder.AudioEncoder.OPUS) {
                return MediaFormat.MIMETYPE_AUDIO_OPUS;
            }
            // we should never be here
            throw new RuntimeException("Unknown codec");
        }

        /**
         * The target audio output bitrate in bits per second
         */
        public int getBitrate() {
            return bitrate;
        }

        /**
         * The audio sampling rate used for the audio track
         */
        public int getSampleRate() {
            return sampleRate;
        }

        /**
         * The number of audio channels used for the audio track
         */
        public int getChannels() {
            return channels;
        }

        /**
         * The audio encoder profile being used for the audio track
         * <p>
         * This value is negative if there is no profile defined for the audio codec.
         * @see MediaFormat#KEY_PROFILE
         */
        public int getProfile() {
            if (codec == MediaRecorder.AudioEncoder.AAC) {
                return MediaCodecInfo.CodecProfileLevel.AACObjectMain;
            } else if (codec == MediaRecorder.AudioEncoder.HE_AAC) {
                return MediaCodecInfo.CodecProfileLevel.AACObjectHE;
            } else if (codec == MediaRecorder.AudioEncoder.AAC_ELD) {
                return MediaCodecInfo.CodecProfileLevel.AACObjectELD;
            }
            return profile;
        }


        // Constructor called by JNI and CamcorderProfile
        /* package private */ AudioProfile(
                int codec,
                int channels,
                int sampleRate,
                int bitrate,
                int profile) {
            this.codec = codec;
            this.channels = channels;
            this.sampleRate = sampleRate;
            this.bitrate = bitrate;
            this.profile = profile;
        }

        private int codec;
        private int channels;
        private int sampleRate;
        private int bitrate;
        private int profile;  // this contains the profile if codec itself does not
    }
}
