// Compile-only hidden API declarations; excluded from framework.dex. No runtime implementation.
package java.util; public class LinkedHashMap<K,V> extends HashMap<K,V> {
 public LinkedHashMap(){super();}
 public LinkedHashMap(int capacity,float loadFactor,boolean accessOrder){super(capacity,loadFactor);}
 public LinkedHashMap(Map<? extends K,? extends V> other){super(other);}
 public Map.Entry<K,V> eldest(){throw new AssertionError("compile-only declaration");}
 }
