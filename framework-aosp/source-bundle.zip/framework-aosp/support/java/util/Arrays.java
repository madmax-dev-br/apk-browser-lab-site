// Compile-only hidden API declarations; excluded from framework.dex. No runtime implementation.
package java.util; public class Arrays { public static native long[] copyOf(long[] a,int count); public static native void fill(long[] a,int f,int t,long v); public static native void fill(int[] a,int f,int t,int v); public static native void fill(char[] a,int from,int to,char value); public static native void fill(float[] a,int from,int to,float value); public static native void sort(float[] a,int from,int to); public static native void fill(Object[] a,int from,int to,Object value); public static native int binarySearch(int[] a,int key); public static native boolean equals(byte[] a,byte[] b); public static native boolean deepEquals(Object[] a,Object[] b); public static native boolean equals(Object[] a,Object[] b); public static native boolean equals(boolean[] a,boolean[] b); public static native int hashCode(boolean[] a); public static native <T> List<T> asList(T... a); public static native float[] copyOf(float[] a,int size); public static native boolean equals(float[] a,float[] b); public static native int hashCode(float[] a); public static native boolean equals(int[] a,int[] b); public static native void fill(int[] a,int value);
 public static boolean deepEquals0(Object left,Object right){throw new AssertionError("compile-only declaration");}
 public static int hashCode(Object[] values){throw new AssertionError("compile-only declaration");}
 public static void sort(Object[] values){throw new AssertionError("compile-only declaration");}
 
public static int[] copyOf(int[] values,int length){throw new AssertionError("compile-only declaration");}
public static <T> T[] copyOf(T[] values,int length){throw new AssertionError("compile-only declaration");}
public static <T,U> T[] copyOfRange(U[] values,int from,int to,Class<? extends T[]> type){throw new AssertionError("compile-only declaration");}
public static void fill(Object[] a,Object v){throw new AssertionError("compile-only declaration");}
public static byte[] copyOf(byte[] a,int n){throw new AssertionError("compile-only declaration");}
public static <T> T[] copyOfRange(T[] a,int f,int t){throw new AssertionError("compile-only declaration");}
public static <T> void sort(T[] a,Comparator<? super T> c){throw new AssertionError("compile-only declaration");}
public static String deepToString(Object[] values){throw new AssertionError("compile-only declaration");}
public static String toString(boolean[] values){throw new AssertionError("compile-only declaration");}
public static String toString(byte[] values){throw new AssertionError("compile-only declaration");}
public static String toString(char[] values){throw new AssertionError("compile-only declaration");}
public static String toString(double[] values){throw new AssertionError("compile-only declaration");}
public static String toString(float[] values){throw new AssertionError("compile-only declaration");}
public static String toString(int[] values){throw new AssertionError("compile-only declaration");}
public static String toString(long[] values){throw new AssertionError("compile-only declaration");}
public static String toString(short[] values){throw new AssertionError("compile-only declaration");}
public static String toString(Object[] values){throw new AssertionError("compile-only declaration");}
}
