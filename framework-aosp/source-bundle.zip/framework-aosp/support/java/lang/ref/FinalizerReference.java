// Compile-only hidden runtime contract. Not a runtime implementation; excluded from framework.dex.
package java.lang.ref; public class FinalizerReference { public static native void finalizeAllEnqueued(long timeout) throws InterruptedException; }
