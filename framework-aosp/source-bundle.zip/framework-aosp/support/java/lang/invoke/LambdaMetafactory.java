// Compile-only Java lambda bootstrap signature; D8 desugars source lambdas into classes.
package java.lang.invoke; public class LambdaMetafactory {
 public static native CallSite metafactory(MethodHandles.Lookup caller,String name,MethodType factoryType,MethodType samMethodType,MethodHandle implMethod,MethodType instantiatedMethodType) throws LambdaConversionException;
}
