// Compile-only Cleaner API declaration; excluded from all D8 inputs. Automatic GC/Cleaner dispatch is not supplied by this contract.
package sun.misc; public class Cleaner extends java.lang.ref.PhantomReference<Object> {private Cleaner(){super(null,null);}public native void clean();}
