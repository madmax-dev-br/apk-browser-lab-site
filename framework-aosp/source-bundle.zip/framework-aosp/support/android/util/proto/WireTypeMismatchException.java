// Compile-only graphics/service/API metadata; never a runtime implementation.
package android.util.proto; public class WireTypeMismatchException extends java.io.IOException {}
