// Compile-only declaration of the hidden DebugUtils.sizeValueToString; the runtime class is the lab excerpt in framework-aosp/lab-java.
package android.util;
public class DebugUtils { public static native String sizeValueToString(long number, StringBuilder outBuilder); }
