// Compile-only IO/service/protocol metadata; no implementation is packaged.
package android.util; public class TimeUtils { public static final long NANOS_PER_MS=1000000; public static native String logTimeOfDay(long millis); }
