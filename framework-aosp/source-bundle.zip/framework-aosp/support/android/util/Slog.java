// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package android.util; public class Slog { public static native int wtf(String tag,String message); }
