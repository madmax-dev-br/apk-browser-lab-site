// Compile-only external display service metadata; never packaged.
package android.util; public class DisplayUtils { public static native int getDisplayUniqueIdConfigIndex(android.content.res.Resources resources,String uniqueId); public static native float getPhysicalPixelDisplaySizeRatio(int physicalWidth,int physicalHeight,int currentWidth,int currentHeight); }
