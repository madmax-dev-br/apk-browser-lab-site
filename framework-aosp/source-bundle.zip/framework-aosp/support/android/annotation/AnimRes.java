package android.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Compile-only lint annotation (source retention in AOSP). */
@Retention(RetentionPolicy.SOURCE)
public @interface AnimRes { }
