// Compile-only annotation declaration. Never packaged into the executable boot DEX.
package android.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.ANNOTATION_TYPE})
public @interface StringDef { String[] value() default {}; String[] prefix() default {}; String[] suffix() default {}; boolean open() default false; }
