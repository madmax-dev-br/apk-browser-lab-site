// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package android.annotation; public @interface TestApi {}
