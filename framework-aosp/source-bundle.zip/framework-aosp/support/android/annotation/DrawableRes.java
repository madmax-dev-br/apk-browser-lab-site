package android.annotation; public @interface DrawableRes {}
