// Compile-only graphics/service/API metadata; never a runtime implementation.
package android.annotation; public @interface CheckResult { String suggest() default ""; }
