// Compile-only declaration (SDK build annotation the NFC originals use); excluded from framework.dex.
package android.annotation; import java.lang.annotation.*; @Retention(RetentionPolicy.SOURCE) @Target({ElementType.PARAMETER}) public @interface CallbackExecutor { }
