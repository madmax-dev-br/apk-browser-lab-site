// Compile-only annotation declaration. Never packaged into the executable boot DEX.
package android.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.TYPE,ElementType.METHOD,ElementType.CONSTRUCTOR})
public @interface RequiresFeature { String value(); }
