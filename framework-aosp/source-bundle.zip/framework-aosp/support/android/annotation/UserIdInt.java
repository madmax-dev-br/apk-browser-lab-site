// Compile-only platform/IPC metadata; excluded from runtime.
package android.annotation; public @interface UserIdInt {}
