// Compile-only API declaration; never packaged as runtime implementation.
package android.annotation; public @interface StyleRes {}
