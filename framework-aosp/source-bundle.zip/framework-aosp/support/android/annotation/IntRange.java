// Compile-only annotation declaration. Never packaged into the executable boot DEX.
package android.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE_USE,ElementType.TYPE,ElementType.FIELD,ElementType.METHOD,ElementType.PARAMETER,ElementType.CONSTRUCTOR,ElementType.LOCAL_VARIABLE,ElementType.ANNOTATION_TYPE})
public @interface IntRange { long from() default Long.MIN_VALUE; long to() default Long.MAX_VALUE; }
