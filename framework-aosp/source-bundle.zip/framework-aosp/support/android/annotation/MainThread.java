package android.annotation; public @interface MainThread {}
