// Compile-only annotation declaration. Never packaged into the executable boot DEX.
package android.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.ANNOTATION_TYPE,ElementType.METHOD,ElementType.CONSTRUCTOR,ElementType.FIELD,ElementType.PARAMETER})
public @interface RequiresPermission { String value() default ""; String[] allOf() default {}; String[] anyOf() default {}; boolean conditional() default false;
  @Target({ElementType.FIELD,ElementType.METHOD,ElementType.PARAMETER}) @interface Read { RequiresPermission value() default @RequiresPermission; }
  @Target({ElementType.FIELD,ElementType.METHOD,ElementType.PARAMETER}) @interface Write { RequiresPermission value() default @RequiresPermission; } }
