// Compile-only system/context contract; no implementation enters boot.
package android.app; public class AppGlobals { public static native int getIntCoreSetting(String key,int fallback); }
