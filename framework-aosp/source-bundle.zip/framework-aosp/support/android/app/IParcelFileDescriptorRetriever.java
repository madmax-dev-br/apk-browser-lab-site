// Compile-only declaration of the hidden AIDL interface android.app.ApplicationExitInfo (android-13.0.0_r1) holds; excluded from framework.dex.
package android.app;
public interface IParcelFileDescriptorRetriever extends android.os.IInterface {
    android.os.ParcelFileDescriptor getPfd() throws android.os.RemoteException;
    abstract class Stub extends android.os.Binder implements IParcelFileDescriptorRetriever { public static IParcelFileDescriptorRetriever asInterface(android.os.IBinder binder) { return null; } }
}
