// Compile-only declaration of the generated proto field ids ApplicationExitInfo.dumpDebug (android-13.0.0_r1) writes with; excluded from framework.dex.
package android.app;
public final class ApplicationExitInfoProto {
    public static final long CONNECTION_GROUP = 1L;
    public static final long DEFINING_UID = 2L;
    public static final long DESCRIPTION = 3L;
    public static final long IMPORTANCE = 4L;
    public static final long PACKAGE_UID = 5L;
    public static final long PID = 6L;
    public static final long PROCESS_NAME = 7L;
    public static final long PSS = 8L;
    public static final long REAL_UID = 9L;
    public static final long REASON = 10L;
    public static final long RSS = 11L;
    public static final long STATE = 12L;
    public static final long STATUS = 13L;
    public static final long SUB_REASON = 14L;
    public static final long TIMESTAMP = 15L;
    public static final long TRACE_FILE = 16L;
}
