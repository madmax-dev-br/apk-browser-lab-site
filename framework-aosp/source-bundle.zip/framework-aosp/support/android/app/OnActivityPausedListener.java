// Compile-only declaration (hidden or generated API the NFC originals reference); excluded from framework.dex. The lab has no NFC service or adapter.
package android.app; public interface OnActivityPausedListener { void onPaused(Activity activity); }
