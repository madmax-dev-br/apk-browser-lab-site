// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package android.app.compat; public class CompatChanges { public static native boolean isChangeEnabled(long change); public static native boolean isChangeEnabled(long change,String packageName,android.os.UserHandle user); }
