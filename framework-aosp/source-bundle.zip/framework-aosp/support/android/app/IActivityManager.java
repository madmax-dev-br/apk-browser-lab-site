// Compile-only declaration (hidden API android.os.StrictMode reaches); excluded from framework.dex. The VM supplies the runtime contract (src/strictmode-host.js).
package android.app; public interface IActivityManager { void handleApplicationStrictModeViolation(android.os.IBinder app, int penaltyMask, android.os.Parcelable info) throws android.os.RemoteException; }
