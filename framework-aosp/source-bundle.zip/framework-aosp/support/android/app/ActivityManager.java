// Compile-only hidden-API declaration; excluded from framework.dex.
package android.app; public class ActivityManager { public static native boolean isLowRamDeviceStatic(); }
