// Compile-only hidden-API declaration; excluded from framework.dex.
package android.app; public class ActivityManager { public static native boolean isLowRamDeviceStatic();
 public static class RunningAppProcessInfo { @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE) public @interface Importance {} } }
