// Compile-only declaration of the hidden AIDL interface android.app.ApplicationExitInfo (android-13.0.0_r1) holds; excluded from framework.dex.
package android.app;
public interface IAppTraceRetriever extends android.os.IInterface {
    android.os.ParcelFileDescriptor getTraceFileDescriptor(String packageName, int uid, int pid) throws android.os.RemoteException;
    abstract class Stub extends android.os.Binder implements IAppTraceRetriever { public static IAppTraceRetriever asInterface(android.os.IBinder binder) { return null; } }
}
