// Compile-only system/context contract; no implementation enters boot.
package android.app; public class WindowConfiguration { public native android.graphics.Rect getMaxBounds(); }
