// Compile-only declaration: the symbols android.media.Image (android-13.0.0_r1) names from the hidden android.hardware.DataSpace. It is not a D8 input.
package android.hardware;

public final class DataSpace {
    public static final int DATASPACE_UNKNOWN = 0;
    private DataSpace() {}

    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
    public @interface NamedDataSpace {}
}
