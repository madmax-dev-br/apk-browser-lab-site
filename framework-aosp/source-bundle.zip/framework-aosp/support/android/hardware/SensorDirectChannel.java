// Compile-only declaration: the annotation types android.hardware.Sensor (android-13.0.0_r1) names from SensorDirectChannel. It is not a D8 input.
package android.hardware;

public abstract class SensorDirectChannel {
    public static final int RATE_STOP = 0;
    public static final int RATE_NORMAL = 1;
    public static final int RATE_FAST = 2;
    public static final int RATE_VERY_FAST = 3;
    public static final int TYPE_MEMORY_FILE = 1;
    public static final int TYPE_HARDWARE_BUFFER = 2;

    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
    public @interface MemoryType {}

    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
    public @interface RateLevel {}
}
