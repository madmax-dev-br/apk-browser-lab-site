// Compile-only declaration: the hidden android.hardware.input.InputSensorInfo getters android.hardware.Sensor (android-13.0.0_r1) reads in its @hide constructor. It is not a D8 input.
package android.hardware.input;

public class InputSensorInfo {
    public String getName() { return null; }
    public String getVendor() { return null; }
    public int getVersion() { return 0; }
    public int getHandle() { return 0; }
    public int getType() { return 0; }
    public float getMaxRange() { return 0; }
    public float getResolution() { return 0; }
    public float getPower() { return 0; }
    public int getMinDelay() { return 0; }
    public int getFifoReservedEventCount() { return 0; }
    public int getFifoMaxEventCount() { return 0; }
    public String getStringType() { return null; }
    public String getRequiredPermission() { return null; }
    public int getMaxDelay() { return 0; }
    public int getFlags() { return 0; }
    public int getId() { return 0; }
}
