// Compile-only declaration: the hidden android.hardware.SyncFence members android.media.Image (android-13.0.0_r1) calls. It is not a D8 input.
package android.hardware;

public final class SyncFence implements AutoCloseable {
    private SyncFence() {}
    public static SyncFence createEmpty() { return null; }
    public boolean isValid() { return false; }
    @Override public void close() {}
}
