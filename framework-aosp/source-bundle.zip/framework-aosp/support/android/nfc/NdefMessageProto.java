// Compile-only declaration (hidden or generated API the NFC originals reference); excluded from framework.dex. The lab has no NFC service or adapter.
package android.nfc; public final class NdefMessageProto { public static final long NDEF_RECORDS = 1; }
