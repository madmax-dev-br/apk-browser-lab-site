// Compile-only declaration (the activity-lifecycle helper behind NfcAdapter's foreground dispatch / reader mode / Beam; reachable only through an adapter, which the lab never has); excluded from framework.dex.
package android.nfc; import android.app.Activity; import android.os.Bundle; import android.net.Uri;
public final class NfcActivityManager { public NfcActivityManager(Object adapter) { } public void setNdefPushContentUri(Activity activity, Uri[] uris) { } public void setNdefPushContentUriCallback(Activity activity, Object callback) { }
 public void setNdefPushMessage(Activity activity, Object message, int flags) { } public void setNdefPushMessageCallback(Activity activity, Object callback, int flags) { } public void setOnNdefPushCompleteCallback(Activity activity, Object callback) { }
 public void enableReaderMode(Activity activity, Object callback, int flags, Bundle extras) { } public void disableReaderMode(Activity activity) { } }
