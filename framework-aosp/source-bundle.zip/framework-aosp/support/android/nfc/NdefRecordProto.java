// Compile-only declaration (hidden or generated API the NFC originals reference); excluded from framework.dex. The lab has no NFC service or adapter.
package android.nfc; public final class NdefRecordProto { public static final long TYPE = 1, ID = 2, PAYLOAD = 3, PAYLOAD_BYTES = 4; }
