// Compile-only IO/service/protocol metadata; no implementation is packaged.
package android.content; public class ClipDataProto { public static long DESCRIPTION,ICON,ITEMS; public static class Item { public static long HTML_TEXT,TEXT,URI,INTENT,NOTHING; } public static class Icon { public static long WIDTH,HEIGHT; } }
