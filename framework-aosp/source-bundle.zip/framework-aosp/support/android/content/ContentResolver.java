// Compile-only platform/IPC metadata; excluded from runtime.
package android.content; public class ContentResolver { public native void unregisterContentObserver(android.database.ContentObserver observer); public native void registerContentObserver(android.net.Uri uri,boolean descendants,android.database.ContentObserver observer); public native void registerContentObserver(android.net.Uri uri,boolean descendants,android.database.ContentObserver observer,int userHandle);
public native int getUserId(); public native void notifyChange(android.net.Uri uri,android.database.ContentObserver observer); public static native void onDbCorruption(String tag,String message,Throwable stacktrace);
public static final String SCHEME_ANDROID_RESOURCE="android.resource",SCHEME_CONTENT="content",SCHEME_FILE="file";
public native android.content.res.AssetFileDescriptor openTypedAssetFileDescriptor(android.net.Uri uri,String type,android.os.Bundle options) throws java.io.FileNotFoundException;
public native String[] getStreamTypes(android.net.Uri uri,String filter); public native String getType(android.net.Uri uri); public @interface NotifyFlags {} }
