// Compile-only IO/service/protocol metadata; no implementation is packaged.
package android.content; public class ClipDescriptionProto { public static long MIME_TYPES,LABEL,EXTRAS,TIMESTAMP_MS; }
