// Compile-only service/annotation contract; no implementation in boot.
package android.content; public class Intent implements android.os.Parcelable {
public static final int URI_INTENT_SCHEME=1,FLAG_GRANT_READ_URI_PERMISSION=1; public static android.os.Parcelable.Creator<Intent> CREATOR;
public native String toUri(int flags); public native void toShortString(StringBuilder out,boolean secure,boolean comp,boolean extras,boolean clip);
public native void dumpDebug(android.util.proto.ProtoOutputStream stream,long id,boolean secure,boolean comp,boolean extras,boolean clip);
public native void prepareToLeaveProcess(boolean leave); public native void prepareToEnterProcess(boolean protectedComponent,AttributionSource source); public native void fixUris(int user);
public native android.net.Uri getData(); public native Intent setData(android.net.Uri data); public native ClipData getClipData();
public native void writeToParcel(android.os.Parcel dest,int flags); public native int describeContents(); public @interface Flags {} public static int FLAG_RECEIVER_OFFLOAD; }
