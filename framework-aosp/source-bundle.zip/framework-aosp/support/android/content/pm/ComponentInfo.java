// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package android.content.pm; public class ComponentInfo extends PackageItemInfo {
public static int DUMP_FLAG_ALL,DUMP_FLAG_DETAILS;
public ApplicationInfo applicationInfo; public String processName,splitName; public int descriptionRes; public boolean enabled,exported,directBootAware;
public ComponentInfo(){} public ComponentInfo(ComponentInfo other){} public ComponentInfo(android.os.Parcel source){}
protected native void dumpFront(android.util.Printer printer,String prefix); protected native void dumpBack(android.util.Printer printer,String prefix,int flags);
public native void writeToParcel(android.os.Parcel dest,int flags);
}
