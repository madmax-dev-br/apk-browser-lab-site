// Compile-only service/annotation contract; no implementation in boot.
package android.content.pm; public abstract class PackageManager { public @interface PermissionResult {} public @interface PackageInfoFlagsBits {} public static final int PERMISSION_GRANTED=0; public static int MATCH_HIDDEN_UNTIL_INSTALLED_COMPONENTS; }
