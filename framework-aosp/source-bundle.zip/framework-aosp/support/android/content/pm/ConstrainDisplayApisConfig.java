// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package android.content.pm; public class ConstrainDisplayApisConfig { public native boolean getNeverConstrainDisplayApis(ApplicationInfo app); public native boolean getAlwaysConstrainDisplayApis(ApplicationInfo app); }
