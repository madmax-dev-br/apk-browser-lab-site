// Compile-only declaration (hidden or generated API the NFC originals reference); excluded from framework.dex. The lab has no NFC service or adapter.
package android.content.pm; public interface IPackageManager { boolean hasSystemFeature(String name, int version) throws android.os.RemoteException; }
