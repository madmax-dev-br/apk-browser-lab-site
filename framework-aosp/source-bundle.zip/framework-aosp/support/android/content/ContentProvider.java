// Compile-only IO/service/protocol metadata; no implementation is packaged.
package android.content; public class ContentProvider { public static native android.net.Uri maybeAddUserId(android.net.Uri uri,int userId); }
