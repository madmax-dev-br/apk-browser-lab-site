// Compile-only annotation/constants metadata generated verbatim from pinned original Configuration.java.
package android.content.res; public class Configuration { public Configuration(){} public Configuration(Configuration other){} public @interface NativeConfig {} public android.app.WindowConfiguration windowConfiguration; public native boolean isLayoutSizeAtLeast(int size); public static native boolean needNewResources(int configChanges,int changes);
public static final int SCREENLAYOUT_SIZE_XLARGE = 0x04;
public static final int NATIVE_CONFIG_MCC = 0x0001;
public static final int NATIVE_CONFIG_MNC = 0x0002;
public static final int NATIVE_CONFIG_LOCALE = 0x0004;
public static final int NATIVE_CONFIG_TOUCHSCREEN = 0x0008;
public static final int NATIVE_CONFIG_KEYBOARD = 0x0010;
public static final int NATIVE_CONFIG_KEYBOARD_HIDDEN = 0x0020;
public static final int NATIVE_CONFIG_NAVIGATION = 0x0040;
public static final int NATIVE_CONFIG_ORIENTATION = 0x0080;
public static final int NATIVE_CONFIG_DENSITY = 0x0100;
public static final int NATIVE_CONFIG_SCREEN_SIZE = 0x0200;
public static final int NATIVE_CONFIG_VERSION = 0x0400;
public static final int NATIVE_CONFIG_SCREEN_LAYOUT = 0x0800;
public static final int NATIVE_CONFIG_UI_MODE = 0x1000;
public static final int NATIVE_CONFIG_SMALLEST_SCREEN_SIZE = 0x2000;
public static final int NATIVE_CONFIG_LAYOUTDIR = 0x4000;
public static final int NATIVE_CONFIG_COLOR_MODE = 0x10000;
}
