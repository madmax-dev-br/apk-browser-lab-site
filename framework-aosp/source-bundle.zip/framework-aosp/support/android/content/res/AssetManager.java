// Compile-only API declaration; never packaged as runtime implementation.
package android.content.res; public class AssetManager { public native CharSequence getPooledStringForCookie(int cookie,int index); }
