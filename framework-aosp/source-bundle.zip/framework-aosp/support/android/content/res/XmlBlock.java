// Compile-only API declaration; never packaged as runtime implementation.
package android.content.res; public class XmlBlock { public static class Parser { public native CharSequence getPooledString(int index); public native String getPositionDescription(); } }
