// Compile-only API declarations; never D8 implementation inputs.
package android.widget; public class TextView extends android.view.View { public native android.graphics.Paint getPaint(); public native android.text.Layout getLayout(); public native android.text.method.WordIterator getWordIterator(); }
