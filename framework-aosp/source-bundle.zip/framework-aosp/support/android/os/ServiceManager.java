// Compile-only declaration (hidden or generated API the NFC originals reference); excluded from framework.dex. The lab has no NFC service or adapter.
package android.os; public final class ServiceManager { public static native IBinder getService(String name); }
