// Compile-only subset of android.os.Build used by the pinned runtime sources, plus the hidden IS_DEBUGGABLE flag; excluded from framework.dex.
// VERSION_CODES values are the public constants of android-13.0.0_r1.
package android.os; public class Build { public static final boolean IS_DEBUGGABLE = false;
 public static class VERSION { public static final int SDK_INT = 0; }
 public static class VERSION_CODES { public static final int BASE = 1, GINGERBREAD = 9, HONEYCOMB = 11, HONEYCOMB_MR1 = 12, HONEYCOMB_MR2 = 13, ICE_CREAM_SANDWICH = 14, ICE_CREAM_SANDWICH_MR1 = 15, JELLY_BEAN = 16, JELLY_BEAN_MR1 = 17, JELLY_BEAN_MR2 = 18, KITKAT = 19, LOLLIPOP = 21, LOLLIPOP_MR1 = 22, M = 23, N = 24, N_MR1 = 25, O = 26, O_MR1 = 27, P = 28, Q = 29, R = 30, S = 31, S_V2 = 32, TIRAMISU = 33, CUR_DEVELOPMENT = 10000; } }
