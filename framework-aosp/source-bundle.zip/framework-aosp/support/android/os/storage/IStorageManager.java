// Compile-only declaration (hidden API android.os.StrictMode reaches); excluded from framework.dex. The VM supplies the runtime contract (src/strictmode-host.js).
package android.os.storage; public interface IStorageManager { boolean isUserKeyUnlocked(int userId) throws android.os.RemoteException; }
