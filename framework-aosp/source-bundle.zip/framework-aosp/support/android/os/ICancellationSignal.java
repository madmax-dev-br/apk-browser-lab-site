// Compile-only declaration of the hidden AIDL interface behind CancellationSignal's binder transport; excluded from framework.dex.
package android.os;
public interface ICancellationSignal extends IInterface {
    void cancel() throws RemoteException;
    abstract class Stub extends Binder implements ICancellationSignal {
        public static ICancellationSignal asInterface(IBinder obj) { throw new AssertionError("compile-only declaration"); }
        public IBinder asBinder() { throw new AssertionError("compile-only declaration"); }
    }
}
