// Compile-only declaration (hidden API android.os.StrictMode reaches); excluded from framework.dex. The VM supplies the runtime contract (src/strictmode-host.js).
package android.os; public interface INetworkManagementService { void setUidCleartextNetworkPolicy(int uid, int policy) throws RemoteException; }
