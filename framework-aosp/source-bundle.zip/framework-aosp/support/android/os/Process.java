// Compile-only process boundary; constant data verbatim from pinned original Process.java.
package android.os; public class Process {
public static final int SYSTEM_UID = 1000;
public static final int FIRST_APPLICATION_CACHE_GID = 20000;
public static final int FIRST_APPLICATION_UID = 10000;
public static final int FIRST_APP_ZYGOTE_ISOLATED_UID = 90000;
public static final int FIRST_ISOLATED_UID = 99000;
public static final int FIRST_SHARED_APPLICATION_GID = 50000;
public static final int LAST_APPLICATION_UID = 19999;
public static final int ROOT_UID = 0;
public static final int SHARED_USER_GID = 9997;
public static native int myUid(); public static native int myPid(); public static native void killProcess(int pid); public static native boolean isIsolated(int uid);
}
