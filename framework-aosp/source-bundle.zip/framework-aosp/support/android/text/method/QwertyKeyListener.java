// Compile-only API declarations; never D8 implementation inputs.
package android.text.method; public abstract class QwertyKeyListener extends BaseKeyListener { public static native QwertyKeyListener getInstance(boolean auto,TextKeyListener.Capitalize cap); public static native QwertyKeyListener getInstanceForFullKeyboard(); public static class Replaced implements android.text.NoCopySpan {} }
