// Compile-only API declarations; never D8 implementation inputs.
package android.text.method; public class WordIterator { public WordIterator(){} public native void setCharSequence(CharSequence text,int start,int end); public native int preceding(int offset); public native int following(int offset); }
