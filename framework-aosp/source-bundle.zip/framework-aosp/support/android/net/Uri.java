// Compile-only URI/security boundary signatures, excluded from D8 inputs.
package android.net; public abstract class Uri implements android.os.Parcelable {
 public static android.os.Parcelable.Creator<Uri> CREATOR;
 public static native Uri parse(String text); public native String getScheme();
 public native void checkFileUriExposed(String location); public native void checkContentUriWithoutPermission(String location,int flags);
 public native String toString(); public native int describeContents(); public native void writeToParcel(android.os.Parcel out,int flags);
}
