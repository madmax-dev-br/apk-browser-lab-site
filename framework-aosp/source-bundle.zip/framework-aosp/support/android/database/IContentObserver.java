// Compile-only platform/IPC metadata; excluded from runtime.
package android.database; public interface IContentObserver { abstract class Stub implements IContentObserver { public abstract void onChange(boolean selfChange,android.net.Uri uri,int userId); public abstract void onChangeEtc(boolean selfChange,android.net.Uri[] uris,int flags,int userId); } }
