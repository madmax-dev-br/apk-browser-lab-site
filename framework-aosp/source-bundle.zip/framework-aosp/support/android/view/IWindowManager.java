// Compile-only system/context contract; no implementation enters boot.
package android.view; public interface IWindowManager { boolean hasNavigationBar(int displayId) throws android.os.RemoteException; }
