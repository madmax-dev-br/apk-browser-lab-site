// Compile-only system/context contract; no implementation enters boot.
package android.view; public class WindowManagerGlobal { public static native IWindowManager getWindowManagerService(); }
