// Compile-only API metadata.
package android.view; public class View { public @interface AutofillType {} public static final int AUTOFILL_TYPE_TEXT=1,AUTOFILL_TYPE_TOGGLE=2,AUTOFILL_TYPE_LIST=3,AUTOFILL_TYPE_DATE=4; public native android.graphics.drawable.Drawable getBackground(); public native int getWidth(); public native int getHeight(); public native int getPaddingLeft(); public native int getPaddingRight(); public native int getPaddingTop(); public native int getPaddingBottom();
public static final int NO_ID=-1,VISIBLE=0,INVISIBLE=4,GONE=8;
public native void setLayoutParams(ViewGroup.LayoutParams params); public native android.content.Context getContext();
public native boolean restoreDefaultFocus(); protected native void onFinishInflate(); public native void setTag(int key,Object value);
public native void setId(int id); public native void setVisibility(int visibility); public native void invalidate(); public interface OnApplyWindowInsetsListener { WindowInsets onApplyWindowInsets(View view,WindowInsets insets); } public @interface ResolvedLayoutDir {} public static final int LAYOUT_DIRECTION_LTR=0,LAYOUT_DIRECTION_RTL=1; }
