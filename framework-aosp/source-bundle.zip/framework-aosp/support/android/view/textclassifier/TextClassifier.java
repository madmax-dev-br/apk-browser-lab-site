// Compile-only IO/service/protocol metadata; no implementation is packaged.
package android.view.textclassifier; public interface TextClassifier { @interface EntityType {} }
