// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package android.view; public interface WindowManager { public static class LayoutParams { public @interface SoftInputModeFlags {} } }
