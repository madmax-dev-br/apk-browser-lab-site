// Compile-only external display service metadata; never packaged.
package android.view; public class DisplayCutout { public static DisplayCutout NO_CUTOUT; public native boolean isEmpty(); public native DisplayCutout inset(int l,int t,int r,int b); public native android.graphics.Rect getSafeInsets(); }
