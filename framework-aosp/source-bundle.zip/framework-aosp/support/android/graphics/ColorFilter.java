// Compile-only graphics/service/API metadata; never a runtime implementation.
package android.graphics; public class ColorFilter { public ColorFilter(){} public native long getNativeInstance(); }
