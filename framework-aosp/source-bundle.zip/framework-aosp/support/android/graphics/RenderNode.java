// Compile-only hardware recording ABI, excluded from D8.
package android.graphics; public class RenderNode { public native void registerVectorDrawableAnimator(android.view.NativeVectorDrawableAnimator animator); public native int getLeft(); public native int getTop(); public native boolean stretch(float x,float y,float maxX,float maxY); public native boolean isAttached(); }
