// Compile-only RenderThread API declaration; excluded from D8.
package android.graphics.animation; public class FallbackLUTInterpolator { public static native long createNativeInterpolator(android.animation.TimeInterpolator value,long duration); }
