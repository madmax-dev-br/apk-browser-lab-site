// Compile-only graphics boundary/format metadata, never packaged runtime code.
package android.graphics.drawable; public class NinePatchDrawable extends Drawable { public NinePatchDrawable(){}
public NinePatchDrawable(android.content.res.Resources res,android.graphics.Bitmap bitmap,byte[] chunk,android.graphics.Rect padding,android.graphics.Rect layout,String name){}public native void draw(android.graphics.Canvas canvas); public native void setAlpha(int alpha); public native void setColorFilter(android.graphics.ColorFilter filter); public native int getOpacity();
}
