// Compile-only color management API; no color-space implementation enters boot.
package android.graphics; public class ColorSpace {
public static final int MIN_ID=-1;
public static class Named { public static Named SRGB; }
public static class Model { public static Model RGB; public native int getComponentCount(); }
public static class Rgb extends ColorSpace { public native java.util.function.DoubleUnaryOperator getEotf(); }
public static class Connector { public native float[] transform(float[] c); public native float[] transform(float r,float g,float b); public native ColorSpace getDestination(); }
public static native ColorSpace get(int id); public static native ColorSpace get(Named named);
public static native Connector connect(ColorSpace source); public static native Connector connect(ColorSpace source,ColorSpace destination);
public native int getId(); public native Model getModel(); public native String getName(); public native int getComponentCount(); public native boolean isSrgb(); public native boolean isWideGamut();
}
