// Compile-only graphics boundary declarations; excluded from D8.
package android.graphics; public class BaseCanvas { public native void drawText(char[] text,int start,int count,float x,float y,Paint paint); public native void drawTextRun(char[] text,int index,int count,int contextIndex,int contextCount,float x,float y,boolean rtl,Paint paint); }
