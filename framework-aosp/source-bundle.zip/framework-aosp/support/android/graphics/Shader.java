// Compile-only graphics/service/API metadata; never a runtime implementation.
package android.graphics; public class Shader { public native void setLocalMatrix(Matrix matrix); public enum TileMode { CLAMP, REPEAT, MIRROR, DECAL } public native long getNativeInstance(); }
