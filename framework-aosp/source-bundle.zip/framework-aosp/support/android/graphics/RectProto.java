// Compile-only graphics boundary/format metadata, never packaged runtime code.
package android.graphics; public class RectProto { public static final long LEFT=1120986464257L,TOP=1120986464258L,RIGHT=1120986464259L,BOTTOM=1120986464260L; }
