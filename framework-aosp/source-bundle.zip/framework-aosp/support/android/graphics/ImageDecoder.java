// Compile-only graphics boundary/format metadata, never packaged runtime code.
package android.graphics; public class ImageDecoder {
public static final int ALLOCATOR_SOFTWARE=1; public static class Source {} public static class ImageInfo {}
public static class DecodeException extends java.io.IOException { public static final int SOURCE_INCOMPLETE=2; public native int getError(); }
public interface OnHeaderDecodedListener { void onHeaderDecoded(ImageDecoder decoder,ImageInfo info,Source source); }
public interface OnPartialImageListener { boolean onPartialImage(DecodeException e); }
public native void setAllocator(int allocator); public native void setOnPartialImageListener(OnPartialImageListener listener);
public static native Source createSource(android.content.res.Resources res,java.io.InputStream input,int density);
public static native Source createSource(android.content.res.Resources res,java.io.InputStream input);
public static native Bitmap decodeBitmap(Source source,OnHeaderDecodedListener listener) throws java.io.IOException;
public static native android.graphics.drawable.Drawable decodeDrawable(Source source,OnHeaderDecodedListener listener) throws java.io.IOException;
}
