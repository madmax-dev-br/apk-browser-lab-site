// Compile-only declaration of libcore dalvik.system.BlockGuard; excluded from framework.dex. The VM supplies the runtime contract.
package dalvik.system; public final class BlockGuard { public interface Policy { void onWriteToDisk(); void onReadFromDisk(); } public static native Policy getThreadPolicy(); }
