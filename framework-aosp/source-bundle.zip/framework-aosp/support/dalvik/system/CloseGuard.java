// Compile-only declaration of libcore's dalvik.system.CloseGuard; excluded from framework.dex. The VM supplies the runtime contract (src/system-services-host.js).
package dalvik.system;
public final class CloseGuard {
    public static CloseGuard get() { throw new AssertionError("compile-only declaration"); }
    public void open(String closer) { throw new AssertionError("compile-only declaration"); }
    public void close() { throw new AssertionError("compile-only declaration"); }
    public void warnIfOpen() { throw new AssertionError("compile-only declaration"); }
    public static void setEnabled(boolean enabled) { throw new AssertionError("compile-only declaration"); }
}
