// Compile-only declaration (hidden API android.os.StrictMode reaches); excluded from framework.dex. The VM supplies the runtime contract (src/strictmode-host.js).
package dalvik.system; public final class VMDebug { public static native long countInstancesOfClass(Class<?> klass, boolean assignable); public static native long[] countInstancesOfClasses(Class<?>[] classes, boolean assignable); }
