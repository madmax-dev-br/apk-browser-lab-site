// Compile-only API declaration; never packaged as runtime implementation.
package com.android.internal.util; public class XmlUtils { public static native boolean convertValueToBoolean(CharSequence value,boolean fallback); public static native int convertValueToInt(CharSequence value,int fallback); }
