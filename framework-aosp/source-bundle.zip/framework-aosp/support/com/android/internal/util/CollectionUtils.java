// Compile-only contract; no runtime implementation. Configuration constants are verbatim from pinned original source.
package com.android.internal.util; public class CollectionUtils { public static native <T> java.util.List<T> emptyIfNull(java.util.List<T> list); }
