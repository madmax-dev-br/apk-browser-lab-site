package com.android.internal.annotations; public @interface VisibleForTesting { int visibility() default 0; public interface Visibility { int PACKAGE=3; } }
