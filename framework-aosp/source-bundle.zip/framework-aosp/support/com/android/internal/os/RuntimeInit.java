// Compile-only declaration (hidden API android.os.StrictMode reaches); excluded from framework.dex. The VM supplies the runtime contract (src/strictmode-host.js).
package com.android.internal.os; public class RuntimeInit { public static native android.os.IBinder getApplicationObject(); }
