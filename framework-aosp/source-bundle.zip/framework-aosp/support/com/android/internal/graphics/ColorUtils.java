// Compile-only graphics/service/API metadata; never a runtime implementation.
package com.android.internal.graphics; public class ColorUtils { public static native com.android.internal.graphics.cam.Cam colorToCAM(int color); public static native int CAMToColor(float hue,float chroma,float lStar); }
