// Compile-only graphics/service/API metadata; never a runtime implementation.
package com.android.internal.graphics.cam; public class Cam { public native float getHue(); public native float getChroma(); }
