// Compile-only IO/service/protocol metadata; no implementation is packaged.
package libcore.io; public class IoUtils { public static native void closeQuietly(AutoCloseable value); }
