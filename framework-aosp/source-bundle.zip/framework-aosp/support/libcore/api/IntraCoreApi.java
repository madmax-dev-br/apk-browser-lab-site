// Compile-only annotation metadata; excluded from framework.dex.
package libcore.api; import java.lang.annotation.*; @Retention(RetentionPolicy.CLASS) @Target({ElementType.TYPE,ElementType.FIELD,ElementType.METHOD,ElementType.CONSTRUCTOR}) public @interface IntraCoreApi {  }
