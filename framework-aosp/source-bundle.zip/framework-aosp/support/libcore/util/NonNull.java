// Compile-only metadata, never packaged.
package libcore.util; import java.lang.annotation.*; @Target({ElementType.TYPE_USE,ElementType.FIELD,ElementType.METHOD,ElementType.PARAMETER}) @Retention(RetentionPolicy.CLASS) public @interface NonNull {}
