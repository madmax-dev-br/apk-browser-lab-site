// Compile-only VM native-lifetime boundary contract; no fake GC or executable implementation.
package libcore.util; public class NativeAllocationRegistry { public static native NativeAllocationRegistry createMalloced(ClassLoader loader,long finalizer); public native Runnable registerNativeAllocation(Object referent,long handle); }
