package dev.apkweb.measureprobe.test;
import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.security.MessageDigest;
import org.json.JSONArray;
import org.json.JSONObject;
/** Native Android platform traversal; application bytecode is unchanged. */
public final class MeasureInstrumentation extends Instrumentation {
 private final JSONArray checks=new JSONArray();private final JSONObject report=new JSONObject();private Activity activity;private ViewGroup panel;private File output;
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 private void check(boolean ok,String label){if(!ok)throw new AssertionError(label);checks.put(label);}
 private int field(String name){try{return panel.getClass().getField(name).getInt(panel);}catch(Exception e){throw new RuntimeException(e);}}
 private void idle(){waitForIdleSync();SystemClock.sleep(120);waitForIdleSync();}
 private JSONObject geometry(String phase){final JSONObject data=new JSONObject();runOnMainSync(()->{try{
  int[] xy=new int[2];panel.getLocationOnScreen(xy);data.put("screenBounds",new JSONArray(new int[]{xy[0],xy[1],panel.getWidth(),panel.getHeight()}));
  data.put("measuredWidth",panel.getMeasuredWidth());data.put("measuredHeight",panel.getMeasuredHeight());data.put("measureCalls",field("measureCalls"));data.put("layoutCalls",field("layoutCalls"));data.put("clicks",field("clicks"));
  check(field("measureCalls")>0,phase+": app onMeasure executed");check(field("layoutCalls")>0,phase+": app onLayout executed");check(panel.getChildCount()==2,phase+": exactly two app-created children");
  check(panel.getMeasuredWidth()==panel.getWidth()&&panel.getWidth()>0,phase+": actual width measured and laid out");check(panel.getMeasuredHeight()==panel.getHeight()&&panel.getHeight()>0,phase+": actual height measured and laid out");
  JSONArray children=new JSONArray();int y=0;
  for(int i=0;i<panel.getChildCount();i++){View child=panel.getChildAt(i);check(child.isLaidOut(),phase+": child "+i+" native laid out");check(child.getTop()==y,phase+": child "+i+" follows app vertical layout");check(child.getLeft()==0&&child.getWidth()==child.getMeasuredWidth(),phase+": child "+i+" actual width");check(child.getHeight()==child.getMeasuredHeight()&&child.getHeight()>0,phase+": child "+i+" actual height");JSONObject c=new JSONObject();c.put("className",child.getClass().getName());c.put("bounds",new JSONArray(new int[]{child.getLeft(),child.getTop(),child.getRight(),child.getBottom()}));c.put("measured",new JSONArray(new int[]{child.getMeasuredWidth(),child.getMeasuredHeight()}));children.put(c);y+=child.getMeasuredHeight()+4;}
  check(y==panel.getHeight(),phase+": parent matches app sum of measured child heights and gaps");data.put("children",children);
 }catch(Exception e){throw new RuntimeException(e);}});return data;}
 private void capture(String name)throws Exception{Bitmap image=getUiAutomation().takeScreenshot();check(image!=null,"Android screenshot "+name);try(FileOutputStream out=new FileOutputStream(new File(output,name+".png"))){check(image.compress(Bitmap.CompressFormat.PNG,100,out),"PNG "+name);}report.put(name+"Screen",new JSONArray(new int[]{image.getWidth(),image.getHeight()}));image.recycle();}
 private void clickAndAwait(int expected){final int[] before=new int[2];runOnMainSync(()->{before[0]=field("measureCalls");before[1]=field("layoutCalls");check(((Button)panel.getChildAt(1)).performClick(),"real Android performClick "+expected);});
  for(int attempt=0;attempt<20;attempt++){idle();final boolean[] ready=new boolean[1];runOnMainSync(()->ready[0]=field("measureCalls")>before[0]&&field("layoutCalls")>before[1]);if(ready[0])break;}
  runOnMainSync(()->{check(field("clicks")==expected,"actual app click counter "+expected);check(field("measureCalls")>before[0],"requestLayout invokes app onMeasure "+expected);check(field("layoutCalls")>before[1],"requestLayout invokes app onLayout "+expected);check(("Medir novamente "+expected).contentEquals(((Button)panel.getChildAt(1)).getText()),"actual button text "+expected);});}
 private String apkHash()throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(FileInputStream in=new FileInputStream(getTargetContext().getApplicationInfo().sourceDir)){byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte b:d.digest())s.append(String.format("%02x",b&255));return s.toString();}
 @Override public void onStart(){Bundle result=new Bundle();try{
  output=new File(getTargetContext().getFilesDir(),"measure-android");check(output.mkdirs()||output.isDirectory(),"output directory");
  activity=startActivitySync(new Intent().setClassName("dev.apkweb.measureprobe","dev.apkweb.measureprobe.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));idle();
  runOnMainSync(()->{try{panel=(ViewGroup)activity.getClass().getField("panel").get(activity);check(panel!=null,"actual app ProbeLayout instance");}catch(Exception e){throw new RuntimeException(e);}});
  report.put("initial",geometry("initial"));capture("android-measure-initial");clickAndAwait(1);clickAndAwait(2);report.put("edited",geometry("edited"));capture("android-measure-edited");
  report.put("passed",true);report.put("assertions",checks);report.put("assertionCount",checks.length());report.put("apkSha256",apkHash());report.put("sdk",android.os.Build.VERSION.SDK_INT);report.put("density",getTargetContext().getResources().getDisplayMetrics().density);report.put("source","Real Android emulator platform traversal, unchanged signed application APK");
  try(FileOutputStream out=new FileOutputStream(new File(output,"report.json"))){out.write(report.toString(2).getBytes("UTF-8"));}
  result.putString("stream","PASS: app onMeasure/onLayout, actual consecutive child bounds and two requestLayout clicks; "+checks.length()+" assertions\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","FAIL: "+android.util.Log.getStackTraceString(e));finish(Activity.RESULT_CANCELED,result);}}
}
