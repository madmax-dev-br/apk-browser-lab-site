package dev.apkweb.measureprobe;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;
/** All children and measurement/layout callbacks are actual app bytecode. */
public class ProbeLayout extends ViewGroup implements View.OnClickListener {
 public int measureCalls,layoutCalls,clicks;
 public Button button;
 public ProbeLayout(Context context,AttributeSet attrs){
  super(context,attrs);TextView title=new TextView(context);title.setText("Filho criado no DEX");addView(title);
  button=new Button(context);button.setText("Medir novamente");button.setOnClickListener(this);addView(button);
 }
 @Override protected void onMeasure(int widthSpec,int heightSpec){
  measureCalls++;int width=View.resolveSizeAndState(240,widthSpec,0)&View.MEASURED_SIZE_MASK;int total=0;
  for(int i=0;i<getChildCount();i++){View child=getChildAt(i);child.measure(MeasureSpec.makeMeasureSpec(width,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(64,MeasureSpec.AT_MOST));total+=child.getMeasuredHeight()+4;}
  setMeasuredDimension(View.resolveSizeAndState(width,widthSpec,0),View.resolveSizeAndState(total,heightSpec,0));
 }
 @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom){
  layoutCalls++;int y=0;for(int i=0;i<getChildCount();i++){View child=getChildAt(i);int height=child.getMeasuredHeight();child.layout(0,y,child.getMeasuredWidth(),y+height);y+=height+4;}
 }
 @Override public void onClick(View view){clicks++;button.setText("Medir novamente "+clicks);requestLayout();}
}
