package dev.apkweb.measureprobe;
import android.app.Activity;
import android.os.Bundle;
public class MainActivity extends Activity {
 public ProbeLayout panel;
 @Override public void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.main);panel=(ProbeLayout)findViewById(R.id.probe);}
}
