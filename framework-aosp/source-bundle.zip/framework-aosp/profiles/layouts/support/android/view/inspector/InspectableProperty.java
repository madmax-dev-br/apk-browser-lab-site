// Profile-only compile contracts. No bodies from this directory are D8 inputs.
package android.view.inspector; public @interface InspectableProperty { EnumEntry[] enumMapping() default {}; public @interface EnumEntry { int value(); String name(); } String name() default ""; int attributeId() default 0; ValueType valueType() default ValueType.INFERRED; enum ValueType { INFERRED,GRAVITY } }
