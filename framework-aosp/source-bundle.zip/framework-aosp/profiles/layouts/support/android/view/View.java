// Profile-only compile contracts. No bodies from this directory are D8 inputs.
package android.view;
public class View {
protected static boolean sPreserveMarginParamsInLayoutParamConversion;
protected int mTop,mBottom,mLeft,mRight;
public @interface ResolvedLayoutDir {}
protected int mPaddingLeft,mPaddingTop,mPaddingRight,mPaddingBottom;
public static final int MEASURED_SIZE_MASK=0x00ffffff,MEASURED_STATE_MASK=0xff000000,LAYOUT_DIRECTION_RTL=1,LAYOUT_DIRECTION_UNDEFINED=-1,VISIBLE=0,INVISIBLE=4,GONE=8,MEASURED_HEIGHT_STATE_SHIFT=16;
public native void setWillNotDraw(boolean b); public native void invalidate(); protected native void onDraw(android.graphics.Canvas canvas); public native int getTop(); public native int getBottom(); public native int getLeft(); public native int getRight(); public native int getWidth(); public native int getHeight(); public native int getPaddingLeft(); public native int getPaddingRight(); public native int getPaddingTop(); public native int getPaddingBottom(); public native boolean isLayoutRtl(); public native int getBaseline(); public native void onRtlPropertiesChanged(int dir);
public View(){} public native android.content.Context getContext(); public native void requestLayout();
public native ViewGroup.LayoutParams getLayoutParams(); public native int getVisibility(); public native int getMeasuredWidth(); public native int getMeasuredHeight(); public native int getMeasuredState();
public native int getLayoutDirection(); public native void measure(int width,int height); public native void layout(int l,int t,int r,int b);
public native int getForegroundGravity(); public native void setForegroundGravity(int gravity); public native android.graphics.drawable.Drawable getForeground(); protected native boolean isForegroundInsidePadding();
protected native void setMeasuredDimension(int width,int height); protected native int getSuggestedMinimumWidth(); protected native int getSuggestedMinimumHeight();
protected native void saveAttributeDataForStyleable(android.content.Context context,int[] attrs,android.util.AttributeSet set,android.content.res.TypedArray a,int defStyleAttr,int defStyleRes);
protected native void onMeasure(int width,int height); protected native void onLayout(boolean changed,int left,int top,int right,int bottom);
public native boolean shouldDelayChildPressedState(); public native CharSequence getAccessibilityClassName(); protected native void encodeProperties(ViewHierarchyEncoder encoder);
public static native int combineMeasuredStates(int oldState,int state); public static native int resolveSizeAndState(int size,int spec,int state);
public static class MeasureSpec { public static final int EXACTLY=0x40000000,AT_MOST=0x80000000,UNSPECIFIED=0; public static native int makeSafeMeasureSpec(int size,int mode); public static native int getMode(int spec); public static native int getSize(int spec); public static native int makeMeasureSpec(int size,int mode); }
}
