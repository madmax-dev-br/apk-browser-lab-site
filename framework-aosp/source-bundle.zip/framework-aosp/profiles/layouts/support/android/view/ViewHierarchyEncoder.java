// Profile-only compile contracts. No bodies from this directory are D8 inputs.
package android.view; public class ViewHierarchyEncoder { public native void addProperty(String name,float value); public native void addProperty(String key,boolean value); public native void addProperty(String key,int value); }
