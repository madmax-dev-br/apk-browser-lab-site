// Profile-only compile contracts. No bodies from this directory are D8 inputs.
package android.view; public abstract class ViewGroup extends View {
public ViewGroup(android.content.Context c){}
public ViewGroup(android.content.Context c,android.util.AttributeSet a,int style,int res){}
public native int getChildCount(); public native View getChildAt(int index); protected native void measureChildWithMargins(View child,int width,int widthUsed,int height,int heightUsed);
protected native LayoutParams generateDefaultLayoutParams(); public native LayoutParams generateLayoutParams(android.util.AttributeSet attrs); protected native LayoutParams generateLayoutParams(LayoutParams old); protected native boolean checkLayoutParams(LayoutParams old);
public static native int getChildMeasureSpec(int spec,int padding,int dimension);
public static class LayoutParams { public static final int MATCH_PARENT=-1,WRAP_CONTENT=-2; public int width,height; protected static native String sizeToString(int size); public native String debug(String out); protected native void encodeProperties(ViewHierarchyEncoder e); public LayoutParams(int w,int h){} public LayoutParams(LayoutParams other){} public LayoutParams(android.content.Context c,android.util.AttributeSet a){} }
public static class MarginLayoutParams extends LayoutParams { public int leftMargin,topMargin,rightMargin,bottomMargin; public MarginLayoutParams(int w,int h){super(w,h);} public MarginLayoutParams(LayoutParams old){super(old);} public MarginLayoutParams(MarginLayoutParams old){super(old);} public MarginLayoutParams(android.content.Context c,android.util.AttributeSet a){super(c,a);} }
}
