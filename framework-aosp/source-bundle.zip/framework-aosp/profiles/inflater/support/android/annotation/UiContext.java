// Profile-only compile metadata; not an implementation or boot input.
package android.annotation; public @interface UiContext {}
