// Compile-only API metadata.
package android.view; public class View {
public static final int NO_ID=-1,VISIBLE=0,INVISIBLE=4,GONE=8;
public native void setLayoutParams(ViewGroup.LayoutParams params); public native android.content.Context getContext();
public native boolean restoreDefaultFocus(); protected native void onFinishInflate();
public native void setTag(int key,Object value); public native void setId(int id); public native void setVisibility(int visibility); public native void invalidate(); public @interface ResolvedLayoutDir {} public static final int LAYOUT_DIRECTION_LTR=0,LAYOUT_DIRECTION_RTL=1; }
