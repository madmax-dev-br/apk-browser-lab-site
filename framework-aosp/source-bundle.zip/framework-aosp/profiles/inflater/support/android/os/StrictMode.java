// Compile-only API declaration; never packaged as runtime implementation.
package android.os; public class StrictMode { public static native void assertConfigurationContext(android.content.Context context,String method); public static native void noteResourceMismatch(Object value); }
