// Profile-only compile metadata; not an implementation or boot input.
package android.content.pm; public class ApplicationInfo extends PackageItemInfo { public int targetSdkVersion,uid,theme; public native boolean isEmbeddedDexUsed(); public native boolean isPrivilegedApp(); }
