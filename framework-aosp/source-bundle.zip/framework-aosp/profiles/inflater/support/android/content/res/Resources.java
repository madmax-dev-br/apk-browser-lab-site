// Compile-only API declaration; never packaged as runtime implementation.
package android.content.res;
public class Resources { public Resources() {} public static final int ID_NULL=0;
public static native int getAttributeSetSourceResId(android.util.AttributeSet attrs);
public native XmlResourceParser getLayout(int id);
public native String getResourceName(int id); public native String getResourcePackageName(int id); public native String getResourceEntryName(int id);
public native int getIdentifier(String name,String type,String packageName); public static native TypedArray obtainAttributes(Resources resources,Theme theme,android.util.AttributeSet attrs,int[] styleable); public native XmlResourceParser getXml(int id); public native android.graphics.drawable.DrawableInflater getDrawableInflater(); public native TypedArray obtainAttributes(android.util.AttributeSet set,int[] attrs);
public android.util.Pools.SynchronizedPool<TypedArray> mTypedArrayPool;
public class Theme { public Theme(){} public native boolean resolveAttribute(int id,android.util.TypedValue value,boolean resolve); public native Resources getResources(); public native TypedArray obtainStyledAttributes(android.util.AttributeSet set,int[] attrs,int defStyleAttr,int defStyleRes); public native TypedArray resolveAttributes(int[] values,int[] attrs); } 
public native android.util.DisplayMetrics getDisplayMetrics(); public native AssetManager getAssets();
public native ColorStateList loadColorStateList(android.util.TypedValue v,int id,Theme theme);
public native ComplexColor loadComplexColor(android.util.TypedValue v,int id,Theme theme);
public native void getValueForDensity(int id,int density,android.util.TypedValue value,boolean resolve);
public native android.graphics.drawable.Drawable loadDrawable(android.util.TypedValue v,int id,int density,Theme theme);
public native android.graphics.Typeface getFont(android.util.TypedValue v,int id);
public native CharSequence[] getTextArray(int id);
}
