// Profile-only compile contracts. No bodies from this directory are D8 inputs.
package android.annotation; public @interface StyleRes {}
