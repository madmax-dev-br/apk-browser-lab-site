// Compile-only context/system boundary signatures; not packaged as implementation.
package android.content; public abstract class Context { public native ContentResolver getContentResolver(); public native android.content.res.TypedArray obtainStyledAttributes(android.util.AttributeSet set,int[] attrs);
 public native android.content.res.TypedArray obtainStyledAttributes(android.util.AttributeSet set,int[] attrs,int style,int res);
 public static final String LAYOUT_INFLATER_SERVICE="layout_inflater";
 public native int getDisplayId(); public native android.content.res.Resources getResources();
 public native android.content.res.Resources.Theme getTheme(); public native android.content.pm.ApplicationInfo getApplicationInfo();
 public native ClassLoader getClassLoader(); public native String getPackageName(); public native Object getSystemService(String name);
 public native java.io.File getCodeCacheDir(); public native boolean isUiContext();
}
