// Compile-only stub of the lab host that backs the software Keystore 2 service (src/jca-host.js); excluded from framework.dex.
package dev.apkweb.keystore;
public final class Host {
  public static native String packageName();
  public static native void commit();
}
