package org.apache.harmony.xml;

import com.android.org.kxml2.io.KXmlParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.AttributesImpl;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/**
 * Lab-authored replacement for libcore's Expat-backed org.apache.harmony.xml.ExpatReader (a JNI wrapper around the Expat C library, which the virtual device does not run).
 * It is a SAX2 XMLReader over the original KXmlParser: the same namespace features (namespaces on, namespace-prefixes off by default), the same ContentHandler / LexicalHandler
 * event order (startPrefixMapping before startElement, endPrefixMapping after endElement) and fatal errors reported as SAXParseException with the parser's line and column.
 * DTD declarations and external entities are not processed (KXmlParser reports the DOCDECL text only).
 */
public class ExpatReader implements XMLReader {
    private static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
    private static final String NAMESPACE_PREFIXES = "http://xml.org/sax/features/namespace-prefixes";
    private static final String LEXICAL_HANDLER = "http://xml.org/sax/properties/lexical-handler";

    private ContentHandler contentHandler;
    private DTDHandler dtdHandler;
    private EntityResolver entityResolver;
    private ErrorHandler errorHandler;
    private LexicalHandler lexicalHandler;
    private boolean processNamespaces = true;
    private boolean processNamespacePrefixes = false;

    @Override public boolean getFeature(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
        if (name == null) throw new NullPointerException("name == null");
        if (name.equals(NAMESPACES)) return processNamespaces;
        if (name.equals(NAMESPACE_PREFIXES)) return processNamespacePrefixes;
        if (name.equals("http://xml.org/sax/features/validation") || name.equals("http://xml.org/sax/features/external-general-entities")
                || name.equals("http://xml.org/sax/features/external-parameter-entities")) return false;
        throw new SAXNotRecognizedException(name);
    }

    @Override public void setFeature(String name, boolean value) throws SAXNotRecognizedException, SAXNotSupportedException {
        if (name == null) throw new NullPointerException("name == null");
        if (name.equals(NAMESPACES)) processNamespaces = value;
        else if (name.equals(NAMESPACE_PREFIXES)) processNamespacePrefixes = value;
        else if (name.equals("http://xml.org/sax/features/validation") || name.equals("http://xml.org/sax/features/external-general-entities")
                || name.equals("http://xml.org/sax/features/external-parameter-entities")) { if (value) throw new SAXNotSupportedException(name); }
        else throw new SAXNotRecognizedException(name);
    }

    @Override public Object getProperty(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
        if (name == null) throw new NullPointerException("name == null");
        if (name.equals(LEXICAL_HANDLER)) return lexicalHandler;
        throw new SAXNotRecognizedException(name);
    }

    @Override public void setProperty(String name, Object value) throws SAXNotRecognizedException, SAXNotSupportedException {
        if (name == null) throw new NullPointerException("name == null");
        if (name.equals(LEXICAL_HANDLER)) {
            if (value != null && !(value instanceof LexicalHandler)) throw new SAXNotSupportedException("value doesn't implement " + LexicalHandler.class.getName());
            lexicalHandler = (LexicalHandler) value;
        } else throw new SAXNotRecognizedException(name);
    }

    @Override public void setEntityResolver(EntityResolver resolver) { entityResolver = resolver; }
    @Override public EntityResolver getEntityResolver() { return entityResolver; }
    @Override public void setDTDHandler(DTDHandler handler) { dtdHandler = handler; }
    @Override public DTDHandler getDTDHandler() { return dtdHandler; }
    @Override public void setContentHandler(ContentHandler handler) { contentHandler = handler; }
    @Override public ContentHandler getContentHandler() { return contentHandler; }
    @Override public void setErrorHandler(ErrorHandler handler) { errorHandler = handler; }
    @Override public ErrorHandler getErrorHandler() { return errorHandler; }

    @Override public void parse(String systemId) throws IOException, SAXException {
        parse(new InputSource(systemId));
    }

    @Override public void parse(InputSource input) throws IOException, SAXException {
        if (input == null) throw new NullPointerException("input == null");
        final KXmlParser parser = new KXmlParser();
        try {
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, processNamespaces);
            Reader characters = input.getCharacterStream();
            if (characters != null) parser.setInput(characters);
            else {
                InputStream bytes = input.getByteStream();
                if (bytes == null && input.getSystemId() != null) bytes = new URL(input.getSystemId()).openStream();
                if (bytes == null) throw new IllegalStateException("InputSource has no character stream, byte stream or system id");
                parser.setInput(bytes, input.getEncoding());
            }
        } catch (XmlPullParserException e) {
            throw new SAXException(e);
        }
        final String systemId = input.getSystemId(), publicId = input.getPublicId();
        Locator locator = new Locator() {
            @Override public String getPublicId() { return publicId; }
            @Override public String getSystemId() { return systemId; }
            @Override public int getLineNumber() { return parser.getLineNumber(); }
            @Override public int getColumnNumber() { return parser.getColumnNumber(); }
        };
        try {
            if (contentHandler != null) contentHandler.setDocumentLocator(locator);
            if (contentHandler != null) contentHandler.startDocument();
            int event = parser.nextToken();
            while (event != XmlPullParser.END_DOCUMENT) {
                switch (event) {
                    case XmlPullParser.START_TAG: startElement(parser); break;
                    case XmlPullParser.END_TAG: endElement(parser); break;
                    case XmlPullParser.TEXT: case XmlPullParser.ENTITY_REF: {
                        char[] text = parser.getText().toCharArray();
                        if (contentHandler != null && text.length > 0) contentHandler.characters(text, 0, text.length);
                        break;
                    }
                    case XmlPullParser.IGNORABLE_WHITESPACE: {
                        char[] text = parser.getText().toCharArray();
                        if (contentHandler != null) contentHandler.ignorableWhitespace(text, 0, text.length);
                        break;
                    }
                    case XmlPullParser.CDSECT: {
                        char[] text = parser.getText().toCharArray();
                        if (lexicalHandler != null) lexicalHandler.startCDATA();
                        if (contentHandler != null && text.length > 0) contentHandler.characters(text, 0, text.length);
                        if (lexicalHandler != null) lexicalHandler.endCDATA();
                        break;
                    }
                    case XmlPullParser.COMMENT: {
                        char[] text = parser.getText().toCharArray();
                        if (lexicalHandler != null) lexicalHandler.comment(text, 0, text.length);
                        break;
                    }
                    case XmlPullParser.PROCESSING_INSTRUCTION: {
                        String text = parser.getText(); int split = 0;
                        while (split < text.length() && !Character.isWhitespace(text.charAt(split))) split++;
                        int data = split; while (data < text.length() && Character.isWhitespace(text.charAt(data))) data++;
                        if (contentHandler != null) contentHandler.processingInstruction(text.substring(0, split), text.substring(data));
                        break;
                    }
                    default: break;   // START_DOCUMENT, DOCDECL
                }
                event = parser.nextToken();
            }
            if (contentHandler != null) contentHandler.endDocument();
        } catch (XmlPullParserException e) {
            SAXParseException error = new SAXParseException(e.getMessage(), publicId, systemId, parser.getLineNumber(), parser.getColumnNumber(), e);
            if (errorHandler != null) errorHandler.fatalError(error);
            throw error;
        }
    }

    private void startElement(KXmlParser parser) throws SAXException {
        int depth = parser.getDepth();
        int namespaces = parser.getNamespaceCount(depth);
        if (processNamespaces && contentHandler != null) {
            for (int i = parser.getNamespaceCount(depth - 1); i < namespaces; i++) {
                String prefix = parser.getNamespacePrefix(i);
                contentHandler.startPrefixMapping(prefix == null ? "" : prefix, parser.getNamespaceUri(i));
            }
        }
        AttributesImpl attributes = new AttributesImpl();
        if (processNamespaces && processNamespacePrefixes) {
            for (int i = parser.getNamespaceCount(depth - 1); i < namespaces; i++) {
                String prefix = parser.getNamespacePrefix(i);
                attributes.addAttribute("", prefix == null ? "xmlns" : prefix, prefix == null ? "xmlns" : "xmlns:" + prefix, "CDATA", parser.getNamespaceUri(i));
            }
        }
        for (int i = 0; i < parser.getAttributeCount(); i++) {
            String prefix = parser.getAttributePrefix(i), local = parser.getAttributeName(i);
            if (processNamespaces) {
                String uri = parser.getAttributeNamespace(i);
                attributes.addAttribute(uri == null ? "" : uri, local, prefix == null || prefix.isEmpty() ? local : prefix + ":" + local, parser.getAttributeType(i), parser.getAttributeValue(i));
            } else {
                attributes.addAttribute("", "", local, parser.getAttributeType(i), parser.getAttributeValue(i));
            }
        }
        if (contentHandler == null) return;
        String prefix = parser.getPrefix(), name = parser.getName();
        if (processNamespaces) {
            String uri = parser.getNamespace();
            contentHandler.startElement(uri == null ? "" : uri, name, prefix == null || prefix.isEmpty() ? name : prefix + ":" + name, attributes);
        } else {
            contentHandler.startElement("", "", name, attributes);
        }
    }

    private void endElement(KXmlParser parser) throws SAXException {
        if (contentHandler == null) return;
        String prefix = parser.getPrefix(), name = parser.getName();
        if (processNamespaces) {
            String uri = parser.getNamespace();
            contentHandler.endElement(uri == null ? "" : uri, name, prefix == null || prefix.isEmpty() ? name : prefix + ":" + name);
            int depth = parser.getDepth();
            for (int i = parser.getNamespaceCount(depth) - 1; i >= parser.getNamespaceCount(depth - 1); i--) {
                String p = parser.getNamespacePrefix(i);
                contentHandler.endPrefixMapping(p == null ? "" : p);
            }
        } else {
            contentHandler.endElement("", "", name);
        }
    }
}
