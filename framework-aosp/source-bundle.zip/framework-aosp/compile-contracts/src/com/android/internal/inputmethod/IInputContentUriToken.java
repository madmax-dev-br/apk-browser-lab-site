package com.android.internal.inputmethod;
/** Compile-only declaration of the hidden binder interface InputContentInfo keeps for the content-URI permission token; never packaged. */
public interface IInputContentUriToken extends android.os.IInterface {
    void take() throws android.os.RemoteException;
    void release() throws android.os.RemoteException;
    abstract class Stub extends android.os.Binder implements IInputContentUriToken {
        public static IInputContentUriToken asInterface(android.os.IBinder binder) { return null; }
    }
}
