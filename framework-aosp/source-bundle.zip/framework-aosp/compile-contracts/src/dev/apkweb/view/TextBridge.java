package dev.apkweb.view;
/** Compile-only declaration of the lab host that mirrors an Editable's edits into the TextView the page draws; never packaged. */
public final class TextBridge {
    private TextBridge() {}
    public static native void changed(android.widget.TextView view, CharSequence before, CharSequence after, int start);
}
