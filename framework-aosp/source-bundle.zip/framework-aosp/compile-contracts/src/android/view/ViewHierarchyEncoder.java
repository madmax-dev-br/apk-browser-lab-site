package android.view;
/** Compile-only declaration (hidden class): the encoder passed to View.encodeProperties. Never an implementation input. */
public class ViewHierarchyEncoder {
    public native void beginObject(Object o); public native void endObject();
    public native void addProperty(String name, boolean value); public native void addProperty(String name, short value); public native void addProperty(String name, int value);
    public native void addProperty(String name, float value); public native void addProperty(String name, String value); public native void addProperty(String name, long value);
    public native void addPropertyKey(String name); public native void addPropertyKey(Object o);
}
