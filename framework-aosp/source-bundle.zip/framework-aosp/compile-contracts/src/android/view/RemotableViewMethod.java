package android.view;
/** Compile-only: hidden marker annotation (RemoteViews method whitelist). */
public @interface RemotableViewMethod { String asyncImpl() default ""; }
