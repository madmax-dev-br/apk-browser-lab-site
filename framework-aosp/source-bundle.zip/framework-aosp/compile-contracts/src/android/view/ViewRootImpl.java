package android.view;
/** Compile-only declaration of the hidden ViewRootImpl members the original list widgets and MediaController call. Never an implementation input. */
public final class ViewRootImpl { public android.content.Context mContext; public native android.window.WindowOnBackInvokedDispatcher getOnBackInvokedDispatcher(); public native boolean isLayoutRequested(); public native View getAccessibilityFocusedHost(); public native android.view.accessibility.AccessibilityNodeInfo getAccessibilityFocusedVirtualView(); }
