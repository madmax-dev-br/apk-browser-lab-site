package android.view;
/** Compile-only declaration of the hidden ViewRootImpl members the original list widgets call. Never an implementation input. */
public final class ViewRootImpl { public native boolean isLayoutRequested(); public native View getAccessibilityFocusedHost(); public native android.view.accessibility.AccessibilityNodeInfo getAccessibilityFocusedVirtualView(); }
