package android.view.inspector;
/** Compile-only: hidden Layout Inspector annotation. */
public @interface InspectableProperty {
    String name() default ""; int attributeId() default 0; boolean hasAttributeId() default true; ValueType valueType() default ValueType.INFERRED;
    EnumEntry[] enumMapping() default {}; FlagEntry[] flagMapping() default {};
    @interface EnumEntry { String name(); int value(); }
    @interface FlagEntry { String name(); int target(); int mask() default 0; }
    enum ValueType { INFERRED, NONE, INT_ENUM, INT_FLAG, COLOR, GRAVITY, RESOURCE_ID }
}
