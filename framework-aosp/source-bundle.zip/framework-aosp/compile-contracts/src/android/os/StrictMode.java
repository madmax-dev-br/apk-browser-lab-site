package android.os;
/** Compile-only: the hidden critical-span API AbsListView reports scrolls and flings with. Shadows the SDK StrictMode for the list-widget compilation only. */
public final class StrictMode { public static class Span { public native void finish(); } public static native Span enterCriticalSpan(String name); }
