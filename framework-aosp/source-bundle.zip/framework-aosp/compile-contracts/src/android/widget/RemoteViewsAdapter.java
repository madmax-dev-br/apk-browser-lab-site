package android.widget;
import android.content.Context;
import android.content.Intent;
/** Compile-only declaration of the hidden RemoteViewsAdapter members AbsListView references (remote adapters are an app-widget feature the browser VM does not host). */
public class RemoteViewsAdapter extends BaseAdapter {
    public interface RemoteAdapterConnectionCallback { boolean onRemoteAdapterConnected(); void onRemoteAdapterDisconnected(); void deferNotifyDataSetChanged(); void setRemoteViewsAdapter(Intent intent, boolean isAsync); }
    public static class AsyncRemoteAdapterAction implements Runnable { public AsyncRemoteAdapterAction(RemoteAdapterConnectionCallback callback, Intent intent) { } public native void run(); }
    public RemoteViewsAdapter(Context context, Intent intent, RemoteAdapterConnectionCallback callback, boolean useAsyncLoader) { }
    public native void saveRemoteViewsCache(); public native Intent getRemoteViewsServiceIntent(); public native boolean isDataReady();
    public native void setRemoteViewsInteractionHandler(RemoteViews.InteractionHandler handler); public native void superNotifyDataSetChanged(); public native void setVisibleRangeHint(int lowerBound, int upperBound);
    public native int getCount(); public native Object getItem(int position); public native long getItemId(int position); public native android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent);
}
