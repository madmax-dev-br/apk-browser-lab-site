package android.widget;
/** Compile-only declaration: FastScroller asks whether an adapter is an ExpandableListConnector (ExpandableListView is not hosted by the lab). */
public class ExpandableListConnector extends BaseAdapter {
    public native ExpandableListAdapter getAdapter();
    public native int getCount(); public native Object getItem(int position); public native long getItemId(int position); public native android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent);
}
