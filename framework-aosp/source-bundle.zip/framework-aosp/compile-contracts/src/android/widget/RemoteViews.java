package android.widget;
/** Compile-only: the nested hidden types AbsListView / ListView use. Shadows the SDK RemoteViews for this compilation only. */
public class RemoteViews { public interface InteractionHandler { } @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) public @interface RemoteView { } }
