package dev.apkweb.aosp;
import android.app.Activity;
import android.os.Bundle;
import android.util.Pair;
import android.widget.TextView;
public class ShadowActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);TextView text=new TextView(this);text.setText(new Pair<String,Integer>("AOSP",7).toString());setContentView(text);
    }
}
