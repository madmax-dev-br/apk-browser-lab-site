package dev.apkweb.aosp;
import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Pair;
import android.util.Pools;
import android.util.TypedValue;
import android.util.LruCache;
import android.widget.TextView;
public class BootProbeActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        DisplayMetrics metrics=new DisplayMetrics();metrics.setToDefaults();
        int pixels=(int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,2f,metrics);
        int complex=TypedValue.complexToDimensionPixelSize(0x1801,metrics);
        Pools.SimplePool<String> pool=new Pools.SimplePool<String>(2);
        pool.release("pooled");String value=pool.acquire();
        Pair<String,Integer> pair=new Pair<String,Integer>("AOSP",7);
        TextView label=new TextView(this);
        label.setText(pair.toString()+" | density="+metrics.densityDpi+" | dp2="+pixels+" | complex="+complex+" | pool="+value);
        setContentView(label);
    }
    public static int sourceProof() {
        Pair<String,Integer> a=Pair.create("same",1),b=Pair.create("same",1);
        return a.equals(b) && a.hashCode()==b.hashCode() ? 1 : 0;
    }
    public static int poolExceptionProof() {
        Pools.SimplePool<Object> pool=new Pools.SimplePool<Object>(1);Object value=new Object();pool.release(value);
        try { pool.release(value); return 0; } catch(IllegalStateException expected) { return 1; }
    }
    public static int lruProof() {
        LruCache<String,Integer> cache=new LruCache<String,Integer>(2);
        cache.put("a",1);cache.put("b",2);cache.get("a");cache.put("c",3);
        return cache.get("b")==null && cache.get("a").intValue()==1 && cache.size()==2 ? 1:0;
    }
}
