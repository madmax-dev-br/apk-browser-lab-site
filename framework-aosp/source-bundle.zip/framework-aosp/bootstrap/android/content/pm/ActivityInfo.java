// Forward metadata for the annotation used while compiling cyclic framework APIs.
// The selected original ActivityInfo.java is separately compiled into the runtime jar.
package android.content.pm; public class ActivityInfo { public @interface Config {} }
