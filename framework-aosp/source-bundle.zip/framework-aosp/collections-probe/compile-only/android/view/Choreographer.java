// Compile-only hidden API signature; excluded from the consuming APK and boot layer.
package android.view; public class Choreographer {
 public interface FrameCallback { void doFrame(long frameTimeNanos); }
 public static native Choreographer getInstance(); public native long getFrameTimeNanos();
}
