package dev.apkweb.aospcollections;
import android.app.Activity;
import android.os.Bundle;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import android.util.LongSparseArray;
import android.widget.TextView;
public class CollectionsActivity extends Activity implements android.text.TextWatcher, android.text.SpanWatcher, android.content.ComponentCallbacks2, android.view.ViewTreeObserver.OnScrollChangedListener, android.view.ViewTreeObserver.OnGlobalLayoutListener, android.view.ViewTreeObserver.OnPreDrawListener, android.view.ViewTreeObserver.OnDrawListener, android.view.ViewTreeObserver.OnWindowAttachListener, android.view.Choreographer.FrameCallback, android.view.View.OnApplyWindowInsetsListener, android.view.accessibility.AccessibilityManager.AccessibilityStateChangeListener, android.view.accessibility.AccessibilityManager.TouchExplorationStateChangeListener, android.view.View.OnFocusChangeListener, android.content.ClipboardManager.OnPrimaryClipChangedListener, Runnable {
 public int layoutCalls,secondaryCalls,preDrawCalls,drawCalls,attachCalls,detachCalls,frameCommitCalls;
 public int focusCalls,clipboardCalls; public boolean lastFocus;
 @Override public void onFocusChange(android.view.View view,boolean hasFocus){focusCalls++;lastFocus=hasFocus;}
 @Override public void onPrimaryClipChanged(){clipboardCalls++;}
 public int accessibilityCalls,touchCalls; public boolean lastAccessibilityEnabled,lastTouchEnabled;
 @Override public void onAccessibilityStateChanged(boolean enabled){accessibilityCalls++;lastAccessibilityEnabled=enabled;}
 @Override public void onTouchExplorationStateChanged(boolean enabled){touchCalls++;lastTouchEnabled=enabled;}
 public int insetsCalls,lastInsetTop,lastInsetBottom;
 @Override public android.view.WindowInsets onApplyWindowInsets(android.view.View view,android.view.WindowInsets insets){insetsCalls++;lastInsetTop=insets.getSystemWindowInsetTop();lastInsetBottom=insets.getSystemWindowInsetBottom();return insets.consumeSystemWindowInsets();}
 public int textBeforeCalls,textChangedCalls,textAfterCalls,spanAddedCalls,spanRemovedCalls,spanChangedCalls;
 public String lastEditableText;
 @Override public void beforeTextChanged(CharSequence text,int start,int count,int after){textBeforeCalls++;}
 @Override public void onTextChanged(CharSequence text,int start,int before,int count){textChangedCalls++;}
 @Override public void afterTextChanged(android.text.Editable text){textAfterCalls++;lastEditableText=text.toString();}
 @Override public void onSpanAdded(android.text.Spannable text,Object what,int start,int end){spanAddedCalls++;}
 @Override public void onSpanRemoved(android.text.Spannable text,Object what,int start,int end){spanRemovedCalls++;}
 @Override public void onSpanChanged(android.text.Spannable text,Object what,int oldStart,int oldEnd,int newStart,int newEnd){spanChangedCalls++;}
 public int componentConfigCalls,componentLowMemoryCalls,componentTrimCalls,componentLastTrim;
 @Override public void onConfigurationChanged(android.content.res.Configuration config){componentConfigCalls++;}
 @Override public void onLowMemory(){componentLowMemoryCalls++;}
 @Override public void onTrimMemory(int level){componentTrimCalls++;componentLastTrim=level;}
 public int scrollCalls;
 @Override public void onScrollChanged(){scrollCalls++;}
 public int onFrameCalls; public long frameTime; public boolean sameFrameTime;
 @Override public void doFrame(long time){onFrameCalls++;frameTime=time;sameFrameTime=android.view.Choreographer.getInstance().getFrameTimeNanos()==time;}
 public boolean mutate;
 public android.view.ViewTreeObserver observer;
 @Override public void onGlobalLayout(){
  layoutCalls++;
  if(mutate){ observer.removeOnGlobalLayoutListener(this);observer.addOnGlobalLayoutListener(new SecondaryListener(this)); }
 }
 public static class SecondaryListener implements android.view.ViewTreeObserver.OnGlobalLayoutListener {
  private final CollectionsActivity parent;
  public SecondaryListener(CollectionsActivity activity){parent=activity;}
  @Override public void onGlobalLayout(){parent.secondaryCalls++;}
 }
 @Override public boolean onPreDraw(){preDrawCalls++;return false;}
 @Override public void onDraw(){drawCalls++;}
 @Override public void onWindowAttached(){attachCalls++;}
 @Override public void onWindowDetached(){detachCalls++;}
 @Override public void run(){frameCommitCalls++;}
 @Override public void onCreate(Bundle state) {
  super.onCreate(state); TextView label=new TextView(this);
  label.setText("AOSP sparse="+sparseProof()+" boolean="+booleanProof()+" int="+intProof()+" long="+longProof());setContentView(label);
 }
 public static class ChangeObserver extends android.database.ContentObserver {
  public int changes; public String lastUri; public boolean lastSelf;
  public ChangeObserver(android.os.Handler handler){super(handler);}
  @Override public void onChange(boolean selfChange,android.net.Uri uri){changes++;lastSelf=selfChange;lastUri=uri==null ? "null":uri.toString();}
 }
 public static int sparseLongProof(){
  android.util.SparseLongArray a=new android.util.SparseLongArray(0);a.put(7,8589934592L);a.put(2,-9L);a.put(4,Long.MAX_VALUE);a.delete(7);a.append(9,4294967296L);
  android.util.SparseLongArray b=a.clone();return b.size()==3 && b.keyAt(0)==2 && b.get(4)==Long.MAX_VALUE && b.get(7,-1L)==-1L && b.valueAt(2)==4294967296L ? 1:0;
 }
 public static int mapSourceProof(){
  android.util.ArrayMap<String,Integer> map=new android.util.ArrayMap<String,Integer>();map.put("beta",2);map.put("alpha",1);map.put("beta",7);map.remove("alpha");
  android.util.ArraySet<String> set=new android.util.ArraySet<String>();set.add("x");set.add("x");set.add("y");set.remove("y");
  return map.size()==1 && map.get("beta").intValue()==7 && set.size()==1 && set.contains("x") ? 1:0;
 }
 public static int sparseProof(){
  SparseArray<String> a=new SparseArray<String>(0);a.put(40,"forty");a.put(10,"ten");a.put(30,"thirty");a.delete(30);a.append(50,"fifty");
  SparseArray<String> copy=a.clone();a.clear();
  return copy.size()==3 && copy.keyAt(0)==10 && copy.keyAt(1)==40 && "fifty".equals(copy.get(50)) && a.size()==0 ? 1:0;
 }
 public static int booleanProof(){
  SparseBooleanArray a=new SparseBooleanArray(0);a.put(9,true);a.put(3,false);a.put(5,true);a.delete(5);a.append(12,true);
  SparseBooleanArray b=a.clone();b.put(9,false);
  return a.size()==3 && a.keyAt(0)==3 && a.valueAt(1) && !b.get(9) && a.indexOfKey(12)==2 ? 1:0;
 }
 public static int intProof(){
  SparseIntArray a=new SparseIntArray(0);for(int i=20;i>=0;i--)a.put(i,i*3);a.delete(7);a.put(4,99);
  SparseIntArray b=a.clone();a.clear();return b.size()==20 && b.get(4)==99 && b.get(7,-1)==-1 && b.keyAt(0)==0 && b.get(20)==60 ? 1:0;
 }
 public static int longProof(){
  LongSparseArray<String> a=new LongSparseArray<String>(0);a.put(8589934592L,"large");a.put(1L,"small");a.put(4294967296L,"middle");a.delete(4294967296L);a.append(17179869184L,"last");
  LongSparseArray<String> b=a.clone();return b.size()==3 && b.keyAt(1)==8589934592L && "last".equals(b.get(17179869184L)) && b.indexOfKey(4294967296L)<0 ? 1:0;
 }
 public static class CancelProbeView extends android.view.View {
  public int cancelCalls;
  public boolean skipSuper;
  public CancelProbeView(android.content.Context context){super(context);}
  @Override public void onCancelPendingInputEvents(){cancelCalls++;if(!skipSuper)super.onCancelPendingInputEvents();}
 }

 public static class StateProbeView extends android.view.View {
  public int value,saveCalls,restoreCalls;
  public boolean skipSaveSuper,skipRestoreSuper;
  public StateProbeView(android.content.Context context){super(context);}
  @Override protected android.os.Parcelable onSaveInstanceState(){
   saveCalls++;
   android.os.Bundle state=new android.os.Bundle();state.putInt("value",value);
   state.putParcelable("super",skipSaveSuper?null:super.onSaveInstanceState());return state;
  }
  @Override protected void onRestoreInstanceState(android.os.Parcelable state){
   restoreCalls++;android.os.Bundle bundle=(android.os.Bundle)state;value=bundle.getInt("value");
   if(!skipRestoreSuper)super.onRestoreInstanceState(bundle.getParcelable("super"));
  }
 }

}
