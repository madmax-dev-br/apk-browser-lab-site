#!/usr/bin/env bash
# The speech profile (framework-aosp/profiles/speech, BUILD.txt there): the original android.speech.tts classes of android-13.0.0_r1 and the AIDL interfaces they talk to,
# loaded next to the default framework DEX when an APK's DEX references android.speech.tts (the default DEX has no room left under the 64K method-reference limit).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="$(python3 "$ROOT/scripts/fetch-android-all.py")"   # AOSP-built android-all jar: compile-time declarations only (framework-aosp/android-all.json)
ANDROID_DECL="$ANDROID_ALL:$ANDROID_JAR"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="$ROOT/framework-aosp/build"
PROFILE="$ROOT/framework-aosp/profiles/speech"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" || { echo 'Build the default framework first.' >&2; exit 1; }
python3 "$ROOT/scripts/generate-service-aidl.py" --sources speech-aidl-sources.txt --out profiles/speech/generated --no-refusals
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/speech'
rows=json.loads((base/'upstream-sources.json').read_text())
names=[p for p in (base/'speech-sources.txt').read_text().splitlines() if p]+[p for p in (base/'speech-aidl-sources.txt').read_text().splitlines() if p]
for name in names:   # every original is compiled (or, for .aidl, generated) unchanged: no source transform
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
java=[base/'upstream'/p for p in (base/'speech-sources.txt').read_text().splitlines() if p]+sorted((profile/'generated').rglob('*.java'))
(profile/'build/sources.list').write_text('\n'.join('"'+str(p)+'"' for p in java)+'\n')
PY
BOOT="$BASE/framework-classes.jar:$BASE/compile-only:$ANDROID_DECL"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -bootclasspath "$BOOT" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 24 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/speech';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
names={p for f in ['speech-sources.txt','speech-aidl-sources.txt'] for p in (base/f).read_text().splitlines() if p}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
assert classes and all(c.startswith('Landroid/speech/tts/') for c in classes),'unexpected class in the speech profile'
default=json.loads((base/'framework-provenance.json').read_text())
assert not any(c.startswith('Landroid/speech/') for c in default['classes']),'android.speech classes are in the default DEX and in the profile'
generated=json.loads((profile/'generated/provenance.json').read_text())
manifest={'schemaVersion':1,'profile':'speech','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':[],
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'generatedSources':{'tool':generated['tool'],'interfaces':generated['interfaces'],'files':[{'localPath':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((profile/'generated').rglob('*.java'))]},
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'Original android.speech.tts client classes; the virtual device has no text-to-speech engine, so the original code finds none and reports ERROR as on such a device',
 'activationPolicy':'APK DEX references a type of android.speech.tts (or explicit loader option)','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]+sorted((profile/'generated').rglob('*'))
sources=[p for p in sources if p.is_file()]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'speech-sources.txt',base/'speech-aidl-sources.txt',root/'scripts/build-aosp-speech-profile.sh',root/'scripts/generate-service-aidl.py']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP speech profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
