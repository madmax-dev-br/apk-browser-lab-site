/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.speech.tts;
/**
 * Interface for TextToSpeech to talk to TextToSpeechService.
 * 
 * {@hide}
 */
public interface ITextToSpeechService extends android.os.IInterface
{
  /** Default implementation for ITextToSpeechService. */
  public static class Default implements android.speech.tts.ITextToSpeechService
  {
    /**
     * Tells the engine to synthesize some speech and play it back.
     * 
     * @param callingInstance a binder representing the identity of the calling
     *        TextToSpeech object.
     * @param text The text to synthesize.
     * @param queueMode Determines what to do to requests already in the queue.
     * @param param Request parameters.
     * @param utteranceId Unique identifier of synthesized utterance.
     */
    @Override public int speak(android.os.IBinder callingInstance, java.lang.CharSequence text, int queueMode, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Tells the engine to synthesize some speech and write it to a file.
     * 
     * @param callingInstance a binder representing the identity of the calling
     *        TextToSpeech object.
     * @param text The text to synthesize.
     * @param fileDescriptor The file descriptor to write the synthesized audio to. Has to be
     * writable.
     * @param utteranceId Unique identifier of synthesized utterance.
     * @param param Request parameters.
     */
    @Override public int synthesizeToFileDescriptor(android.os.IBinder callingInstance, java.lang.CharSequence text, android.os.ParcelFileDescriptor fileDescriptor, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Plays an existing audio resource.
     * 
     * @param callingInstance a binder representing the identity of the calling
     *        TextToSpeech object.
     * @param audioUri URI for the audio resource (a file or android.resource URI)
     * @param queueMode Determines what to do to requests already in the queue.
     * @param utteranceId Unique identifier of synthesized utterance.
     * @param param Request parameters.
     */
    @Override public int playAudio(android.os.IBinder callingInstance, android.net.Uri audioUri, int queueMode, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Plays silence.
     * 
     * @param callingInstance a binder representing the identity of the calling
     *        TextToSpeech object.
     * @param duration Number of milliseconds of silence to play.
     * @param queueMode Determines what to do to requests already in the queue.
     * @param utteranceId Unique id used to identify this request in callbacks.
     */
    @Override public int playSilence(android.os.IBinder callingInstance, long duration, int queueMode, java.lang.String utteranceId) throws android.os.RemoteException
    {
      return 0;
    }
    /** Checks whether the service is currently playing some audio. */
    @Override public boolean isSpeaking() throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Interrupts the current utterance (if from the given app) and removes any utterances
     * in the queue that are from the given app.
     * 
     * @param callingInstance a binder representing the identity of the calling
     *        TextToSpeech object.
     */
    @Override public int stop(android.os.IBinder callingInstance) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Returns the language, country and variant currently being used by the TTS engine.
     * Can be called from multiple threads.
     * 
     * @return A 3-element array, containing language (ISO 3-letter code),
     *         country (ISO 3-letter code) and variant used by the engine.
     *         The country and variant may be {@code ""}. If country is empty, then variant must
     *         be empty too.
     */
    @Override public java.lang.String[] getLanguage() throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Returns a default TTS language, country and variant as set by the user.
     * 
     * Can be called from multiple threads.
     * 
     * @return A 3-element array, containing language (ISO 3-letter code),
     *         country (ISO 3-letter code) and variant used by the engine.
     *         The country and variant may be {@code ""}. If country is empty, then variant must
     *         be empty too.
     */
    @Override public java.lang.String[] getClientDefaultLanguage() throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Checks whether the engine supports a given language.
     * 
     * @param lang ISO-3 language code.
     * @param country ISO-3 country code. May be empty or null.
     * @param variant Language variant. May be empty or null.
     * @return Code indicating the support status for the locale.
     *         One of {@link TextToSpeech#LANG_AVAILABLE},
     *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
     *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
     *         {@link TextToSpeech#LANG_MISSING_DATA}
     *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
     */
    @Override public int isLanguageAvailable(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Returns a list of features available for a given language. Elements of the returned
     * string array can be passed in as keys to {@link TextToSpeech#speak} and
     * {@link TextToSpeech#synthesizeToFile} to select a given feature or features to be
     * used during synthesis.
     * 
     * @param lang ISO-3 language code.
     * @param country ISO-3 country code. May be empty or null.
     * @param variant Language variant. May be empty or null.
     * @return An array of strings containing the set of features supported for
     *         the supplied locale. The array of strings must not contain
     *         duplicates.
     */
    @Override public java.lang.String[] getFeaturesForLanguage(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Notifies the engine that it should load a speech synthesis language.
     * 
     * @param caller a binder representing the identity of the calling
     *        TextToSpeech object.
     * @param lang ISO-3 language code.
     * @param country ISO-3 country code. May be empty or null.
     * @param variant Language variant. May be empty or null.
     * @return Code indicating the support status for the locale.
     *         One of {@link TextToSpeech#LANG_AVAILABLE},
     *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
     *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
     *         {@link TextToSpeech#LANG_MISSING_DATA}
     *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
     */
    @Override public int loadLanguage(android.os.IBinder caller, java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Sets the callback that will be notified when playback of utterance from the
     * given app are completed.
     * 
     * @param caller Instance a binder representing the identity of the calling
     *        TextToSpeech object.
     * @param cb The callback.
     */
    @Override public void setCallback(android.os.IBinder caller, android.speech.tts.ITextToSpeechCallback cb) throws android.os.RemoteException
    {
    }
    /** Get the array of available voices. */
    @Override public java.util.List<android.speech.tts.Voice> getVoices() throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Notifies the engine that it should load a speech synthesis voice.
     * 
     * @param caller a binder representing the identity of the calling
     *        TextToSpeech object.
     * @param voiceName Unique voice of the name.
     * @return {@link TextToSpeech#SUCCESS} or {@link TextToSpeech#ERROR}.
     */
    @Override public int loadVoice(android.os.IBinder caller, java.lang.String voiceName) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Return a name of the default voice for a given locale.
     * 
     * This allows {@link TextToSpeech#getVoice} to return a sensible value after a client calls
     * {@link TextToSpeech#setLanguage}.
     * 
     * @param lang ISO 3-character language code.
     * @param country ISO 3-character country code. May be empty or null.
     * @param variant Language variant. May be empty or null.
     * @return Code indicating the support status for the locale.
     *         One of {@link TextToSpeech#LANG_AVAILABLE},
     *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
     *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
     *         {@link TextToSpeech#LANG_MISSING_DATA}
     *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
     */
    @Override public java.lang.String getDefaultVoiceNameFor(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
    {
      return null;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.speech.tts.ITextToSpeechService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.speech.tts.ITextToSpeechService interface,
     * generating a proxy if needed.
     */
    public static android.speech.tts.ITextToSpeechService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.speech.tts.ITextToSpeechService))) {
        return ((android.speech.tts.ITextToSpeechService)iin);
      }
      return new android.speech.tts.ITextToSpeechService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_speak:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          java.lang.CharSequence _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.text.TextUtils.CHAR_SEQUENCE_CREATOR);
          int _arg2;
          _arg2 = data.readInt();
          android.os.Bundle _arg3;
          _arg3 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          java.lang.String _arg4;
          _arg4 = data.readString();
          int _result = this.speak(_arg0, _arg1, _arg2, _arg3, _arg4);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_synthesizeToFileDescriptor:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          java.lang.CharSequence _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.text.TextUtils.CHAR_SEQUENCE_CREATOR);
          android.os.ParcelFileDescriptor _arg2;
          _arg2 = _Parcel.readTypedObject(data, android.os.ParcelFileDescriptor.CREATOR);
          android.os.Bundle _arg3;
          _arg3 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          java.lang.String _arg4;
          _arg4 = data.readString();
          int _result = this.synthesizeToFileDescriptor(_arg0, _arg1, _arg2, _arg3, _arg4);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_playAudio:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          android.net.Uri _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.net.Uri.CREATOR);
          int _arg2;
          _arg2 = data.readInt();
          android.os.Bundle _arg3;
          _arg3 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          java.lang.String _arg4;
          _arg4 = data.readString();
          int _result = this.playAudio(_arg0, _arg1, _arg2, _arg3, _arg4);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_playSilence:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          long _arg1;
          _arg1 = data.readLong();
          int _arg2;
          _arg2 = data.readInt();
          java.lang.String _arg3;
          _arg3 = data.readString();
          int _result = this.playSilence(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_isSpeaking:
        {
          boolean _result = this.isSpeaking();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_stop:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          int _result = this.stop(_arg0);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_getLanguage:
        {
          java.lang.String[] _result = this.getLanguage();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getClientDefaultLanguage:
        {
          java.lang.String[] _result = this.getClientDefaultLanguage();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_isLanguageAvailable:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          int _result = this.isLanguageAvailable(_arg0, _arg1, _arg2);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_getFeaturesForLanguage:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String[] _result = this.getFeaturesForLanguage(_arg0, _arg1, _arg2);
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_loadLanguage:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _arg3;
          _arg3 = data.readString();
          int _result = this.loadLanguage(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_setCallback:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          android.speech.tts.ITextToSpeechCallback _arg1;
          _arg1 = android.speech.tts.ITextToSpeechCallback.Stub.asInterface(data.readStrongBinder());
          this.setCallback(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_getVoices:
        {
          java.util.List<android.speech.tts.Voice> _result = this.getVoices();
          reply.writeNoException();
          _Parcel.writeTypedList(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_loadVoice:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          java.lang.String _arg1;
          _arg1 = data.readString();
          int _result = this.loadVoice(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_getDefaultVoiceNameFor:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _result = this.getDefaultVoiceNameFor(_arg0, _arg1, _arg2);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.speech.tts.ITextToSpeechService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Tells the engine to synthesize some speech and play it back.
       * 
       * @param callingInstance a binder representing the identity of the calling
       *        TextToSpeech object.
       * @param text The text to synthesize.
       * @param queueMode Determines what to do to requests already in the queue.
       * @param param Request parameters.
       * @param utteranceId Unique identifier of synthesized utterance.
       */
      @Override public int speak(android.os.IBinder callingInstance, java.lang.CharSequence text, int queueMode, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(callingInstance);
          if (text!=null) {
            _data.writeInt(1);
            android.text.TextUtils.writeToParcel(text, _data, 0);
          }
          else {
            _data.writeInt(0);
          }
          _data.writeInt(queueMode);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeString(utteranceId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_speak, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Tells the engine to synthesize some speech and write it to a file.
       * 
       * @param callingInstance a binder representing the identity of the calling
       *        TextToSpeech object.
       * @param text The text to synthesize.
       * @param fileDescriptor The file descriptor to write the synthesized audio to. Has to be
       * writable.
       * @param utteranceId Unique identifier of synthesized utterance.
       * @param param Request parameters.
       */
      @Override public int synthesizeToFileDescriptor(android.os.IBinder callingInstance, java.lang.CharSequence text, android.os.ParcelFileDescriptor fileDescriptor, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(callingInstance);
          if (text!=null) {
            _data.writeInt(1);
            android.text.TextUtils.writeToParcel(text, _data, 0);
          }
          else {
            _data.writeInt(0);
          }
          _Parcel.writeTypedObject(_data, fileDescriptor, 0);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeString(utteranceId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_synthesizeToFileDescriptor, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Plays an existing audio resource.
       * 
       * @param callingInstance a binder representing the identity of the calling
       *        TextToSpeech object.
       * @param audioUri URI for the audio resource (a file or android.resource URI)
       * @param queueMode Determines what to do to requests already in the queue.
       * @param utteranceId Unique identifier of synthesized utterance.
       * @param param Request parameters.
       */
      @Override public int playAudio(android.os.IBinder callingInstance, android.net.Uri audioUri, int queueMode, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(callingInstance);
          _Parcel.writeTypedObject(_data, audioUri, 0);
          _data.writeInt(queueMode);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeString(utteranceId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_playAudio, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Plays silence.
       * 
       * @param callingInstance a binder representing the identity of the calling
       *        TextToSpeech object.
       * @param duration Number of milliseconds of silence to play.
       * @param queueMode Determines what to do to requests already in the queue.
       * @param utteranceId Unique id used to identify this request in callbacks.
       */
      @Override public int playSilence(android.os.IBinder callingInstance, long duration, int queueMode, java.lang.String utteranceId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(callingInstance);
          _data.writeLong(duration);
          _data.writeInt(queueMode);
          _data.writeString(utteranceId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_playSilence, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Checks whether the service is currently playing some audio. */
      @Override public boolean isSpeaking() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isSpeaking, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Interrupts the current utterance (if from the given app) and removes any utterances
       * in the queue that are from the given app.
       * 
       * @param callingInstance a binder representing the identity of the calling
       *        TextToSpeech object.
       */
      @Override public int stop(android.os.IBinder callingInstance) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(callingInstance);
          boolean _status = mRemote.transact(Stub.TRANSACTION_stop, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Returns the language, country and variant currently being used by the TTS engine.
       * Can be called from multiple threads.
       * 
       * @return A 3-element array, containing language (ISO 3-letter code),
       *         country (ISO 3-letter code) and variant used by the engine.
       *         The country and variant may be {@code ""}. If country is empty, then variant must
       *         be empty too.
       */
      @Override public java.lang.String[] getLanguage() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getLanguage, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Returns a default TTS language, country and variant as set by the user.
       * 
       * Can be called from multiple threads.
       * 
       * @return A 3-element array, containing language (ISO 3-letter code),
       *         country (ISO 3-letter code) and variant used by the engine.
       *         The country and variant may be {@code ""}. If country is empty, then variant must
       *         be empty too.
       */
      @Override public java.lang.String[] getClientDefaultLanguage() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getClientDefaultLanguage, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Checks whether the engine supports a given language.
       * 
       * @param lang ISO-3 language code.
       * @param country ISO-3 country code. May be empty or null.
       * @param variant Language variant. May be empty or null.
       * @return Code indicating the support status for the locale.
       *         One of {@link TextToSpeech#LANG_AVAILABLE},
       *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
       *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
       *         {@link TextToSpeech#LANG_MISSING_DATA}
       *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
       */
      @Override public int isLanguageAvailable(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(lang);
          _data.writeString(country);
          _data.writeString(variant);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isLanguageAvailable, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Returns a list of features available for a given language. Elements of the returned
       * string array can be passed in as keys to {@link TextToSpeech#speak} and
       * {@link TextToSpeech#synthesizeToFile} to select a given feature or features to be
       * used during synthesis.
       * 
       * @param lang ISO-3 language code.
       * @param country ISO-3 country code. May be empty or null.
       * @param variant Language variant. May be empty or null.
       * @return An array of strings containing the set of features supported for
       *         the supplied locale. The array of strings must not contain
       *         duplicates.
       */
      @Override public java.lang.String[] getFeaturesForLanguage(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(lang);
          _data.writeString(country);
          _data.writeString(variant);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getFeaturesForLanguage, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Notifies the engine that it should load a speech synthesis language.
       * 
       * @param caller a binder representing the identity of the calling
       *        TextToSpeech object.
       * @param lang ISO-3 language code.
       * @param country ISO-3 country code. May be empty or null.
       * @param variant Language variant. May be empty or null.
       * @return Code indicating the support status for the locale.
       *         One of {@link TextToSpeech#LANG_AVAILABLE},
       *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
       *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
       *         {@link TextToSpeech#LANG_MISSING_DATA}
       *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
       */
      @Override public int loadLanguage(android.os.IBinder caller, java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(caller);
          _data.writeString(lang);
          _data.writeString(country);
          _data.writeString(variant);
          boolean _status = mRemote.transact(Stub.TRANSACTION_loadLanguage, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Sets the callback that will be notified when playback of utterance from the
       * given app are completed.
       * 
       * @param caller Instance a binder representing the identity of the calling
       *        TextToSpeech object.
       * @param cb The callback.
       */
      @Override public void setCallback(android.os.IBinder caller, android.speech.tts.ITextToSpeechCallback cb) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(caller);
          _data.writeStrongInterface(cb);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setCallback, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      /** Get the array of available voices. */
      @Override public java.util.List<android.speech.tts.Voice> getVoices() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.util.List<android.speech.tts.Voice> _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getVoices, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createTypedArrayList(android.speech.tts.Voice.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Notifies the engine that it should load a speech synthesis voice.
       * 
       * @param caller a binder representing the identity of the calling
       *        TextToSpeech object.
       * @param voiceName Unique voice of the name.
       * @return {@link TextToSpeech#SUCCESS} or {@link TextToSpeech#ERROR}.
       */
      @Override public int loadVoice(android.os.IBinder caller, java.lang.String voiceName) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(caller);
          _data.writeString(voiceName);
          boolean _status = mRemote.transact(Stub.TRANSACTION_loadVoice, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Return a name of the default voice for a given locale.
       * 
       * This allows {@link TextToSpeech#getVoice} to return a sensible value after a client calls
       * {@link TextToSpeech#setLanguage}.
       * 
       * @param lang ISO 3-character language code.
       * @param country ISO 3-character country code. May be empty or null.
       * @param variant Language variant. May be empty or null.
       * @return Code indicating the support status for the locale.
       *         One of {@link TextToSpeech#LANG_AVAILABLE},
       *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
       *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
       *         {@link TextToSpeech#LANG_MISSING_DATA}
       *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
       */
      @Override public java.lang.String getDefaultVoiceNameFor(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(lang);
          _data.writeString(country);
          _data.writeString(variant);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getDefaultVoiceNameFor, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    /** @hide */
    public static final java.lang.String DESCRIPTOR = "android.speech.tts.ITextToSpeechService";
    static final int TRANSACTION_speak = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_synthesizeToFileDescriptor = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_playAudio = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_playSilence = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_isSpeaking = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_stop = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_getLanguage = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_getClientDefaultLanguage = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_isLanguageAvailable = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_getFeaturesForLanguage = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_loadLanguage = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
    static final int TRANSACTION_setCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
    static final int TRANSACTION_getVoices = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
    static final int TRANSACTION_loadVoice = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
    static final int TRANSACTION_getDefaultVoiceNameFor = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
  }
  /**
   * Tells the engine to synthesize some speech and play it back.
   * 
   * @param callingInstance a binder representing the identity of the calling
   *        TextToSpeech object.
   * @param text The text to synthesize.
   * @param queueMode Determines what to do to requests already in the queue.
   * @param param Request parameters.
   * @param utteranceId Unique identifier of synthesized utterance.
   */
  public int speak(android.os.IBinder callingInstance, java.lang.CharSequence text, int queueMode, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException;
  /**
   * Tells the engine to synthesize some speech and write it to a file.
   * 
   * @param callingInstance a binder representing the identity of the calling
   *        TextToSpeech object.
   * @param text The text to synthesize.
   * @param fileDescriptor The file descriptor to write the synthesized audio to. Has to be
   * writable.
   * @param utteranceId Unique identifier of synthesized utterance.
   * @param param Request parameters.
   */
  public int synthesizeToFileDescriptor(android.os.IBinder callingInstance, java.lang.CharSequence text, android.os.ParcelFileDescriptor fileDescriptor, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException;
  /**
   * Plays an existing audio resource.
   * 
   * @param callingInstance a binder representing the identity of the calling
   *        TextToSpeech object.
   * @param audioUri URI for the audio resource (a file or android.resource URI)
   * @param queueMode Determines what to do to requests already in the queue.
   * @param utteranceId Unique identifier of synthesized utterance.
   * @param param Request parameters.
   */
  public int playAudio(android.os.IBinder callingInstance, android.net.Uri audioUri, int queueMode, android.os.Bundle params, java.lang.String utteranceId) throws android.os.RemoteException;
  /**
   * Plays silence.
   * 
   * @param callingInstance a binder representing the identity of the calling
   *        TextToSpeech object.
   * @param duration Number of milliseconds of silence to play.
   * @param queueMode Determines what to do to requests already in the queue.
   * @param utteranceId Unique id used to identify this request in callbacks.
   */
  public int playSilence(android.os.IBinder callingInstance, long duration, int queueMode, java.lang.String utteranceId) throws android.os.RemoteException;
  /** Checks whether the service is currently playing some audio. */
  public boolean isSpeaking() throws android.os.RemoteException;
  /**
   * Interrupts the current utterance (if from the given app) and removes any utterances
   * in the queue that are from the given app.
   * 
   * @param callingInstance a binder representing the identity of the calling
   *        TextToSpeech object.
   */
  public int stop(android.os.IBinder callingInstance) throws android.os.RemoteException;
  /**
   * Returns the language, country and variant currently being used by the TTS engine.
   * Can be called from multiple threads.
   * 
   * @return A 3-element array, containing language (ISO 3-letter code),
   *         country (ISO 3-letter code) and variant used by the engine.
   *         The country and variant may be {@code ""}. If country is empty, then variant must
   *         be empty too.
   */
  public java.lang.String[] getLanguage() throws android.os.RemoteException;
  /**
   * Returns a default TTS language, country and variant as set by the user.
   * 
   * Can be called from multiple threads.
   * 
   * @return A 3-element array, containing language (ISO 3-letter code),
   *         country (ISO 3-letter code) and variant used by the engine.
   *         The country and variant may be {@code ""}. If country is empty, then variant must
   *         be empty too.
   */
  public java.lang.String[] getClientDefaultLanguage() throws android.os.RemoteException;
  /**
   * Checks whether the engine supports a given language.
   * 
   * @param lang ISO-3 language code.
   * @param country ISO-3 country code. May be empty or null.
   * @param variant Language variant. May be empty or null.
   * @return Code indicating the support status for the locale.
   *         One of {@link TextToSpeech#LANG_AVAILABLE},
   *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
   *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
   *         {@link TextToSpeech#LANG_MISSING_DATA}
   *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
   */
  public int isLanguageAvailable(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException;
  /**
   * Returns a list of features available for a given language. Elements of the returned
   * string array can be passed in as keys to {@link TextToSpeech#speak} and
   * {@link TextToSpeech#synthesizeToFile} to select a given feature or features to be
   * used during synthesis.
   * 
   * @param lang ISO-3 language code.
   * @param country ISO-3 country code. May be empty or null.
   * @param variant Language variant. May be empty or null.
   * @return An array of strings containing the set of features supported for
   *         the supplied locale. The array of strings must not contain
   *         duplicates.
   */
  public java.lang.String[] getFeaturesForLanguage(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException;
  /**
   * Notifies the engine that it should load a speech synthesis language.
   * 
   * @param caller a binder representing the identity of the calling
   *        TextToSpeech object.
   * @param lang ISO-3 language code.
   * @param country ISO-3 country code. May be empty or null.
   * @param variant Language variant. May be empty or null.
   * @return Code indicating the support status for the locale.
   *         One of {@link TextToSpeech#LANG_AVAILABLE},
   *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
   *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
   *         {@link TextToSpeech#LANG_MISSING_DATA}
   *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
   */
  public int loadLanguage(android.os.IBinder caller, java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException;
  /**
   * Sets the callback that will be notified when playback of utterance from the
   * given app are completed.
   * 
   * @param caller Instance a binder representing the identity of the calling
   *        TextToSpeech object.
   * @param cb The callback.
   */
  public void setCallback(android.os.IBinder caller, android.speech.tts.ITextToSpeechCallback cb) throws android.os.RemoteException;
  /** Get the array of available voices. */
  public java.util.List<android.speech.tts.Voice> getVoices() throws android.os.RemoteException;
  /**
   * Notifies the engine that it should load a speech synthesis voice.
   * 
   * @param caller a binder representing the identity of the calling
   *        TextToSpeech object.
   * @param voiceName Unique voice of the name.
   * @return {@link TextToSpeech#SUCCESS} or {@link TextToSpeech#ERROR}.
   */
  public int loadVoice(android.os.IBinder caller, java.lang.String voiceName) throws android.os.RemoteException;
  /**
   * Return a name of the default voice for a given locale.
   * 
   * This allows {@link TextToSpeech#getVoice} to return a sensible value after a client calls
   * {@link TextToSpeech#setLanguage}.
   * 
   * @param lang ISO 3-character language code.
   * @param country ISO 3-character country code. May be empty or null.
   * @param variant Language variant. May be empty or null.
   * @return Code indicating the support status for the locale.
   *         One of {@link TextToSpeech#LANG_AVAILABLE},
   *         {@link TextToSpeech#LANG_COUNTRY_AVAILABLE},
   *         {@link TextToSpeech#LANG_COUNTRY_VAR_AVAILABLE},
   *         {@link TextToSpeech#LANG_MISSING_DATA}
   *         {@link TextToSpeech#LANG_NOT_SUPPORTED}.
   */
  public java.lang.String getDefaultVoiceNameFor(java.lang.String lang, java.lang.String country, java.lang.String variant) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedList(
        android.os.Parcel parcel, java.util.List<T> value, int parcelableFlags) {
      if (value == null) {
        parcel.writeInt(-1);
      } else {
        int N = value.size();
        int i = 0;
        parcel.writeInt(N);
        while (i < N) {
    writeTypedObject(parcel, value.get(i), parcelableFlags);
          i++;
        }
      }
    }
  }
}
