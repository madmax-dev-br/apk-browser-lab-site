/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.speech.tts;
/**
 * TextToSpeechManagerService interface. Allows opening {@link TextToSpeech} session with the
 * specified provider proxied by the system service.
 * 
 * @hide
 */
public interface ITextToSpeechManager extends android.os.IInterface
{
  /** Default implementation for ITextToSpeechManager. */
  public static class Default implements android.speech.tts.ITextToSpeechManager
  {
    @Override public void createSession(java.lang.String engine, android.speech.tts.ITextToSpeechSessionCallback managerCallback) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.speech.tts.ITextToSpeechManager
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.speech.tts.ITextToSpeechManager interface,
     * generating a proxy if needed.
     */
    public static android.speech.tts.ITextToSpeechManager asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.speech.tts.ITextToSpeechManager))) {
        return ((android.speech.tts.ITextToSpeechManager)iin);
      }
      return new android.speech.tts.ITextToSpeechManager.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_createSession:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          android.speech.tts.ITextToSpeechSessionCallback _arg1;
          _arg1 = android.speech.tts.ITextToSpeechSessionCallback.Stub.asInterface(data.readStrongBinder());
          this.createSession(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.speech.tts.ITextToSpeechManager
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void createSession(java.lang.String engine, android.speech.tts.ITextToSpeechSessionCallback managerCallback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(engine);
          _data.writeStrongInterface(managerCallback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_createSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_createSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "android.speech.tts.ITextToSpeechManager";
  public void createSession(java.lang.String engine, android.speech.tts.ITextToSpeechSessionCallback managerCallback) throws android.os.RemoteException;
}
