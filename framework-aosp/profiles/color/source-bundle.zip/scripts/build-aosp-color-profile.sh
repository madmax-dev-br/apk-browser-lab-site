#!/usr/bin/env bash
# The color profile (framework-aosp/profiles/color, BUILD.txt there): the original android-13.0.0_r1 color math of the framework, com.android.internal.graphics.ColorUtils and the
# CAM16 / HCT classes of com.android.internal.graphics.cam (Cam, CamUtils, Frame, HctSolver). ColorStateList (default framework DEX) calls ColorUtils.colorToCAM / CamUtils when an
# item of a color state list gives android:lStar (ColorStateList.modulateColor); the classes are loaded next to the default framework DEX, which has no room left under the 64K
# method-reference limit.
# FRAMEWORK_BUILD: a directory with framework-classes.jar and compile-only.jar of a default framework build (default framework-aosp/build); ANDROID_ALL: the pinned android-all jar
# (default: scripts/fetch-android-all.py, which fetches it into work/android-all when absent). Both are compile-time declarations only.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="${ANDROID_ALL:-$(python3 "$ROOT/scripts/fetch-android-all.py")}"
ANDROID_DECL="$ANDROID_ALL:$ANDROID_JAR"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="${FRAMEWORK_BUILD:-$ROOT/framework-aosp/build}"
PROFILE="$ROOT/framework-aosp/profiles/color"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" || { echo 'Build the default framework first (or set FRAMEWORK_BUILD).' >&2; exit 1; }
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/color'
rows=json.loads((base/'upstream-sources.json').read_text())
names=[p for p in (base/'color-sources.txt').read_text().splitlines() if p]
for name in names:   # every original is compiled unchanged: no source transform
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
(profile/'build/sources.list').write_text('\n'.join('"'+str(base/'upstream'/p)+'"' for p in names)+'\n')
PY
# The lab's framework classes first (what the default DEX defines: android.graphics.Color, android.util.MathUtils), then the android-all declarations (the annotations).
mkdir -p "$BUILD/boot" && (cd "$BUILD/boot" && jar xf "$BASE/framework-classes.jar")
BOOT="$BUILD/boot:$BASE/compile-only.jar:$ANDROID_DECL"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -nowarn -bootclasspath "$BOOT" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 24 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
mkdir -p "$PROFILE" && cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/color';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
names={p for p in (base/'color-sources.txt').read_text().splitlines() if p}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
COLOR=('Lcom/android/internal/graphics/ColorUtils','Lcom/android/internal/graphics/cam/')
assert classes and all(c.startswith(COLOR) for c in classes),'unexpected class in the color profile: '+', '.join(c for c in classes if not c.startswith(COLOR))
default=json.loads((base/'framework-provenance.json').read_text())
assert default['sha256']==hashlib.sha256((base/'framework.dex').read_bytes()).hexdigest(),'framework-provenance.json does not describe framework-aosp/framework.dex'
clash=[c for c in classes if c in set(default['classes'])]
assert not clash,'classes in the default DEX and in the profile: '+', '.join(clash[:5])
manifest={'schemaVersion':1,'profile':'color','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':[],
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'Original color math (ColorUtils, CAM16 and HCT): ColorStateList.modulateColor of the default DEX applies android:lStar with it, as on Android 13',
 'activationPolicy':'a color state list of the APK (a res/color*/ XML, or any XML the resource table types as a color) gives android:lStar, or a companion package is installed (its resources are not scanned at load), or explicit loader option','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]
sources=[p for p in sources if p.is_file()]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'color-sources.txt',root/'scripts/build-aosp-color-profile.sh']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP color profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
rm -rf "$BUILD"
