#!/usr/bin/env bash
# The invoke profile (framework-aosp/profiles/invoke, BUILD.txt there): the libcore java.lang.invoke originals of android-13.0.0_r1 (MethodHandles and Lookup, MethodHandle,
# MethodHandleImpl, MethodType, Transformers, the VarHandle classes, CallSite ...), sun.invoke.util and dalvik.system.EmulatedStackFrame, compiled unchanged, loaded next to the
# default framework DEX when an installed package's DEX references java.lang.invoke. D8 writes it with --min-api 26: the originals call MethodHandle.invoke / invokeExact, which
# only exist as invoke-polymorphic (DEX 038). The runtime's part (invoke-polymorphic, invokeExactWithFrame, getMemberInternal ...) is src/method-handles.js.
# FRAMEWORK_BUILD: a directory of a default framework build (framework-classes.jar, compile-only.jar, javatime-stubs, javatime-originals; default framework-aosp/build);
# ANDROID_ALL: the pinned android-all jar (default: scripts/fetch-android-all.py). Both are compile-time declarations only, as the profile's support/ declarations.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="${ANDROID_ALL:-$(python3 "$ROOT/scripts/fetch-android-all.py")}"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="${FRAMEWORK_BUILD:-$ROOT/framework-aosp/build}"
PROFILE="$ROOT/framework-aosp/profiles/invoke"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" -a -d "$BASE/javatime-stubs" -a -d "$BASE/javatime-originals" || { echo 'Build the default framework first (or set FRAMEWORK_BUILD).' >&2; exit 1; }
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex" "$BUILD/support"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/invoke'
rows=json.loads((base/'upstream-sources.json').read_text())
names=[p for p in (base/'invoke-sources.txt').read_text().splitlines() if p]
for name in names:   # every original is compiled unchanged: no source transform
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
(profile/'build/sources.list').write_text('\n'.join('"'+str(base/'upstream'/p)+'"' for p in names)+'\n')
(profile/'build/support.list').write_text('\n'.join('"'+str(p)+'"' for p in sorted((profile/'support').rglob('*.java')))+'\n')
PY
# The profile's compile-only declarations first (support/: the java.time group's declarations of Class, Executable and Field plus the hidden getInstanceMethod, getArtMethod
# and getArtField the originals call; never D8 inputs), then as the java.time group: the libcore hidden-member declarations and the java8 originals (without the original
# java.util.Arrays subset) on the boot class path, the android-all and android.jar declarations (java.* comes from android.jar); the default DEX's classes on the class path.
javac -source 8 -target 8 -Xlint:-options -proc:none -nowarn -bootclasspath "$BASE/javatime-stubs:$ANDROID_ALL:$ANDROID_JAR" -d "$BUILD/support" @"$BUILD/support.list"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -nowarn -bootclasspath "$BUILD/support:$BASE/javatime-stubs:$BASE/javatime-originals:$ANDROID_ALL:$ANDROID_JAR" -classpath "$BASE/framework-classes.jar:$BASE/compile-only.jar" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 26 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/invoke';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
names={p for p in (base/'invoke-sources.txt').read_text().splitlines() if p}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
OWN=('Ljava/lang/invoke/','Lsun/invoke/util/','Ldalvik/system/EmulatedStackFrame')
assert classes and all(c.startswith(OWN) for c in classes),'unexpected class in the invoke profile: '+', '.join(c for c in classes if not c.startswith(OWN))
support=sorted(str(p.relative_to(root)) for p in (profile/'support').rglob('*.java'))
assert not {'L'+s.split('/support/',1)[1].removesuffix('.java')+';' for s in support} & set(classes),'a compile-only declaration is in the invoke profile'
default=json.loads((base/'framework-provenance.json').read_text())
assert default['sha256']==hashlib.sha256((base/'framework.dex').read_bytes()).hexdigest(),'framework-provenance.json does not describe framework-aosp/framework.dex'
clash=[c for c in classes if c in set(default['classes'])]
assert not clash,'classes in the default DEX and in the profile: '+', '.join(clash[:5])
manifest={'schemaVersion':1,'profile':'invoke','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':[],'minApi':26,'compileOnlyDeclarations':support,
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'Original libcore java.lang.invoke (MethodHandles.Lookup, MethodHandle, MethodHandleImpl, MethodType, Transformers, VarHandle classes), sun.invoke.util and EmulatedStackFrame; the runtime part (invoke-polymorphic, invokeExactWithFrame, getMemberInternal, getArtMethod / getArtField / getInstanceMethod) is src/method-handles.js; VarHandle access modes are not provided',
 'activationPolicy':'an installed package DEX references a java.lang.invoke type (or explicit loader option)','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]
sources=[p for p in sources if p.is_file()]+[root/s for s in support]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'invoke-sources.txt',root/'scripts/build-aosp-invoke-profile.sh',root/'src/method-handles.js']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP invoke profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
rm -rf "$BUILD"
