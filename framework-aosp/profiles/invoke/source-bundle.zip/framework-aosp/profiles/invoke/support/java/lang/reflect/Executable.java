// Compile-only declaration of java.lang.reflect.Executable (the java.time group's, support-javatime) plus the hidden getArtMethod() of android-13.0.0_r1 libcore (called by the
// pinned MethodHandles.Lookup and Transformers); excluded from the invoke profile DEX. The runtime serves Executable as a host contract.
package java.lang.reflect; import java.lang.annotation.Annotation;
public abstract class Executable extends AccessibleObject implements Member, GenericDeclaration { Executable(){}
 public abstract Class<?> getDeclaringClass(); public abstract String getName(); public abstract int getModifiers(); public abstract TypeVariable<?>[] getTypeParameters();
 public abstract Class<?>[] getParameterTypes(); public int getParameterCount(){throw new AssertionError();} public Type[] getGenericParameterTypes(){throw new AssertionError();}
 Type[] getAllGenericParameterTypes(){throw new AssertionError();} public Parameter[] getParameters(){throw new AssertionError();} boolean hasRealParameterData(){throw new AssertionError();}
 public abstract Class<?>[] getExceptionTypes(); public Type[] getGenericExceptionTypes(){throw new AssertionError();} public abstract String toGenericString();
 public boolean isVarArgs(){throw new AssertionError();} public boolean isSynthetic(){throw new AssertionError();} public abstract Annotation[][] getParameterAnnotations();
 public <T extends Annotation> T getAnnotation(Class<T> annotationClass){throw new AssertionError();} public <T extends Annotation> T[] getAnnotationsByType(Class<T> annotationClass){throw new AssertionError();}
 public Annotation[] getDeclaredAnnotations(){throw new AssertionError();} public final long getArtMethod(){throw new AssertionError();} }
