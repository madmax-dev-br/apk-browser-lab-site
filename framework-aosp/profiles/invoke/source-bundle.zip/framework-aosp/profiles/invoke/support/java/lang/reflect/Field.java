// Compile-only subset of java.lang.reflect.Field (the java.time group's, support-javatime) plus the hidden getArtField() of android-13.0.0_r1 libcore (called by the pinned
// MethodHandles.Lookup and FieldVarHandle); excluded from the invoke profile DEX.
package java.lang.reflect; public final class Field extends AccessibleObject implements Member { public int getModifiers(){throw new AssertionError();} public int getOffset(){throw new AssertionError();}
 public String getName(){throw new AssertionError();} public Class<?> getDeclaringClass(){throw new AssertionError();} public Class<?> getType(){throw new AssertionError();}
 public boolean isSynthetic(){throw new AssertionError();} public Object get(Object o) throws IllegalAccessException {throw new AssertionError();} public void set(Object o,Object v) throws IllegalAccessException {throw new AssertionError();}
 public void setBoolean(Object o,boolean v) throws IllegalAccessException {throw new AssertionError();} public long getArtField(){throw new AssertionError();} }
