#!/usr/bin/env bash
# The media profile (framework-aosp/profiles/media, BUILD.txt there): the original android-13.0.0_r1 android.media.session.PlaybackState, android.media.MediaMetadata,
# android.media.MediaDescription and android.media.Rating (the state a MediaSession publishes), and the media route provider side of MediaRouter2 (MediaRoute2ProviderService with
# its AIDL interfaces, MediaRoute2Info, RoutingSessionInfo, MediaRoute2ProviderInfo, MediaRouter2Utils and the MediaRouter2 callback base classes), loaded next to the default framework
# DEX when an installed package's DEX references one of them (the default DEX has no room left under the 64K method-reference limit). MediaSession, MediaController and
# MediaSessionManager are the lab's host classes (src/peripheral-services-host.js); these classes are the originals.
# FRAMEWORK_BUILD: a directory with framework-classes.jar and compile-only.jar of a default framework build (default framework-aosp/build); ANDROID_ALL: the pinned android-all jar
# (default: scripts/fetch-android-all.py, which fetches it into work/android-all when absent). Both are compile-time declarations only.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="${ANDROID_ALL:-$(python3 "$ROOT/scripts/fetch-android-all.py")}"
ANDROID_DECL="$ANDROID_ALL:$ANDROID_JAR"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="${FRAMEWORK_BUILD:-$ROOT/framework-aosp/build}"
PROFILE="$ROOT/framework-aosp/profiles/media"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" || { echo 'Build the default framework first (or set FRAMEWORK_BUILD).' >&2; exit 1; }
# IMediaRoute2ProviderService and IMediaRoute2ProviderServiceCallback: the Java the SDK aidl compiler writes (no Refusing bases: no lab service implements them; the binder a provider
# service returns is the original MediaRoute2ProviderServiceStub)
python3 "$ROOT/scripts/generate-service-aidl.py" --sources media-aidl-sources.txt --out profiles/media/generated --no-refusals
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex" "$BUILD/src"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/media'
rows=json.loads((base/'upstream-sources.json').read_text())
names=[p for p in (base/'media-sources.txt').read_text().splitlines() if p]
for name in names+[p for p in (base/'media-aidl-sources.txt').read_text().splitlines() if p]:
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
transforms=[];files=[]
for name in names:
 path=base/'upstream'/name;text=path.read_text();out=text
 if name=='android/media/MediaRoute2ProviderService.java':
  # com.android.internal.util.function.pooled.PooledLambda (a pool of reusable Message callbacks, not in the lab's framework) -> the same call posted to the same Handler as a lambda:
  # mHandler.sendMessage(obtainMessage(MediaRoute2ProviderService::m, MediaRoute2ProviderService.this, a, b)) runs this.m(a, b) on mHandler's Looper, as the lambda does.
  pattern=re.compile(r'mHandler\.sendMessage\(obtainMessage\(\s*MediaRoute2ProviderService::(\w+),\s*MediaRoute2ProviderService\.this((?:,\s*\w+)*)\)\);')
  out,count=pattern.subn(lambda m:'mHandler.post(() -> MediaRoute2ProviderService.this.%s(%s));'%(m.group(1),', '.join(a.strip() for a in m.group(2).split(',') if a.strip())),text)
  out=out.replace('import static com.android.internal.util.function.pooled.PooledLambda.obtainMessage;\n','',1)
  assert count==9 and 'obtainMessage' not in out and 'PooledLambda' not in out,(count,[l for l in out.splitlines() if 'obtainMessage' in l][:3])
  transforms.append(dict(path=name,kind='pooled-lambda-message-to-posted-lambda',note='9 binder callbacks of MediaRoute2ProviderServiceStub post the same method call to the same Handler as a lambda instead of a pooled Message (PooledLambda is not in the lab framework)',inputSha256=hashlib.sha256(text.encode()).hexdigest(),outputSha256=hashlib.sha256(out.encode()).hexdigest()))
 dest=profile/'build/src'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(out);files.append(dest)
(profile/'build/transforms.json').write_text(json.dumps(transforms,indent=2)+'\n')
(profile/'build/sources.list').write_text('\n'.join('"'+str(p)+'"' for p in files+sorted((profile/'generated').rglob('*.java')))+'\n')
PY
# The compile-only declarations first (the complete java.util.Arrays declaration: the default DEX holds a subset of the original, the other overloads are host bridges at run time, as
# for the default build's nested classes), the lab's framework classes (what the default DEX defines), then the android-all declarations (android.app.Service, a host class of the
# lab, is declared there).
mkdir -p "$BUILD/boot" && (cd "$BUILD/boot" && jar xf "$BASE/framework-classes.jar")
BOOT="$BASE/compile-only.jar:$BUILD/boot:$ANDROID_DECL"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -nowarn -bootclasspath "$BOOT" -d "$BUILD/classes" @"$BUILD/sources.list"
# MediaRouter2 itself is not part of the profile (the virtual device has no media router service, IMediaRouterService): the pinned source is compiled whole and only its callback base
# classes (abstract static classes and an interface, no state and no call into the outer class) are kept, so an app's subclass of them is constructed from the original.
python3 - "$BUILD/classes" <<'PY'
from pathlib import Path
import sys
classes=Path(sys.argv[1])/'android/media';keep={'MediaRouter2$RouteCallback.class','MediaRouter2$TransferCallback.class','MediaRouter2$ControllerCallback.class','MediaRouter2$OnGetControllerHintsListener.class'}
found={p.name for p in classes.glob('MediaRouter2$*.class')}|({'MediaRouter2.class'} if (classes/'MediaRouter2.class').exists() else set())
assert keep<=found,keep-found
for name in sorted(found-keep):(classes/name).unlink()
print('MediaRouter2 callback bases kept:',', '.join(sorted(keep)),'; dropped:',len(found-keep),'class files')
PY
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 24 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/media';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
names={p for f in ['media-sources.txt','media-aidl-sources.txt'] for p in (base/f).read_text().splitlines() if p}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
MEDIA=('Landroid/media/session/PlaybackState','Landroid/media/MediaMetadata','Landroid/media/MediaDescription','Landroid/media/Rating','Landroid/media/MediaRoute2ProviderService','Landroid/media/MediaRoute2Info',
 'Landroid/media/RoutingSessionInfo','Landroid/media/MediaRoute2ProviderInfo','Landroid/media/MediaRouter2Utils','Landroid/media/IMediaRoute2ProviderService','Landroid/media/MediaRouter2$RouteCallback;',
 'Landroid/media/MediaRouter2$TransferCallback;','Landroid/media/MediaRouter2$ControllerCallback;','Landroid/media/MediaRouter2$OnGetControllerHintsListener;')
assert classes and all(c.startswith(MEDIA) for c in classes),'unexpected class in the media profile: '+', '.join(c for c in classes if not c.startswith(MEDIA))
assert 'Landroid/media/MediaRouter2;' not in classes,'MediaRouter2 itself is not part of the media profile'
default=json.loads((base/'framework-provenance.json').read_text())
assert default['sha256']==hashlib.sha256((base/'framework.dex').read_bytes()).hexdigest(),'framework-provenance.json does not describe framework-aosp/framework.dex'
clash=[c for c in classes if c in set(default['classes'])]
assert not clash,'classes in the default DEX and in the profile: '+', '.join(clash[:5])
generated=json.loads((profile/'generated/provenance.json').read_text())
manifest={'schemaVersion':1,'profile':'media','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':json.loads((profile/'build/transforms.json').read_text()),
 'partialSources':[{'path':'android/media/MediaRouter2.java','kept':['Landroid/media/MediaRouter2$RouteCallback;','Landroid/media/MediaRouter2$TransferCallback;','Landroid/media/MediaRouter2$ControllerCallback;','Landroid/media/MediaRouter2$OnGetControllerHintsListener;'],
   'note':'compiled whole and unchanged; only the callback base classes are D8 inputs. MediaRouter2 (getInstance, RoutingController) is not provided: the virtual device has no media router service, and a call to it fails as an unsupported API naming it'}],
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'generatedSources':{'tool':generated['tool'],'interfaces':generated['interfaces'],'files':[{'localPath':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((profile/'generated').rglob('*.java'))]},
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'Original media data classes (PlaybackState, MediaMetadata, MediaDescription, Rating) that the lab\'s MediaSession and MediaController host classes pass through unchanged, and the original route provider side of MediaRouter2 (MediaRoute2ProviderService and its binder, route and session data classes, the MediaRouter2 callback bases); no media router service: no system routes, no provider is bound by the device',
 'activationPolicy':'an installed package DEX references android.media.session.PlaybackState, android.media.MediaMetadata, android.media.MediaDescription, android.media.Rating, android.media.MediaRoute2ProviderService, MediaRoute2Info, RoutingSessionInfo, MediaRoute2ProviderInfo or a MediaRouter2 callback base (or explicit loader option)','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]+sorted((profile/'generated').rglob('*'))
sources=[p for p in sources if p.is_file()]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'media-sources.txt',base/'media-aidl-sources.txt',root/'scripts/build-aosp-media-profile.sh',root/'scripts/generate-service-aidl.py']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP media profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
rm -rf "$BUILD"
