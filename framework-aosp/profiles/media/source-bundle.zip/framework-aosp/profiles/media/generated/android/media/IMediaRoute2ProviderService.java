/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.media;
/** {@hide} */
public interface IMediaRoute2ProviderService extends android.os.IInterface
{
  /** Default implementation for IMediaRoute2ProviderService. */
  public static class Default implements android.media.IMediaRoute2ProviderService
  {
    // Note: When changing this file, match the order of methods below with
    // MediaRoute2ProviderService#MediaRoute2ProviderServiceStub for readability.
    @Override public void setCallback(android.media.IMediaRoute2ProviderServiceCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void updateDiscoveryPreference(android.media.RouteDiscoveryPreference discoveryPreference) throws android.os.RemoteException
    {
    }
    @Override public void setRouteVolume(long requestId, java.lang.String routeId, int volume) throws android.os.RemoteException
    {
    }
    @Override public void requestCreateSession(long requestId, java.lang.String packageName, java.lang.String routeId, android.os.Bundle sessionHints) throws android.os.RemoteException
    {
    }
    @Override public void selectRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException
    {
    }
    @Override public void deselectRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException
    {
    }
    @Override public void transferToRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException
    {
    }
    @Override public void setSessionVolume(long requestId, java.lang.String sessionId, int volume) throws android.os.RemoteException
    {
    }
    @Override public void releaseSession(long requestId, java.lang.String sessionId) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.media.IMediaRoute2ProviderService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.media.IMediaRoute2ProviderService interface,
     * generating a proxy if needed.
     */
    public static android.media.IMediaRoute2ProviderService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.media.IMediaRoute2ProviderService))) {
        return ((android.media.IMediaRoute2ProviderService)iin);
      }
      return new android.media.IMediaRoute2ProviderService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_setCallback:
        {
          android.media.IMediaRoute2ProviderServiceCallback _arg0;
          _arg0 = android.media.IMediaRoute2ProviderServiceCallback.Stub.asInterface(data.readStrongBinder());
          this.setCallback(_arg0);
          break;
        }
        case TRANSACTION_updateDiscoveryPreference:
        {
          android.media.RouteDiscoveryPreference _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.media.RouteDiscoveryPreference.CREATOR);
          this.updateDiscoveryPreference(_arg0);
          break;
        }
        case TRANSACTION_setRouteVolume:
        {
          long _arg0;
          _arg0 = data.readLong();
          java.lang.String _arg1;
          _arg1 = data.readString();
          int _arg2;
          _arg2 = data.readInt();
          this.setRouteVolume(_arg0, _arg1, _arg2);
          break;
        }
        case TRANSACTION_requestCreateSession:
        {
          long _arg0;
          _arg0 = data.readLong();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          android.os.Bundle _arg3;
          _arg3 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          this.requestCreateSession(_arg0, _arg1, _arg2, _arg3);
          break;
        }
        case TRANSACTION_selectRoute:
        {
          long _arg0;
          _arg0 = data.readLong();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          this.selectRoute(_arg0, _arg1, _arg2);
          break;
        }
        case TRANSACTION_deselectRoute:
        {
          long _arg0;
          _arg0 = data.readLong();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          this.deselectRoute(_arg0, _arg1, _arg2);
          break;
        }
        case TRANSACTION_transferToRoute:
        {
          long _arg0;
          _arg0 = data.readLong();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          this.transferToRoute(_arg0, _arg1, _arg2);
          break;
        }
        case TRANSACTION_setSessionVolume:
        {
          long _arg0;
          _arg0 = data.readLong();
          java.lang.String _arg1;
          _arg1 = data.readString();
          int _arg2;
          _arg2 = data.readInt();
          this.setSessionVolume(_arg0, _arg1, _arg2);
          break;
        }
        case TRANSACTION_releaseSession:
        {
          long _arg0;
          _arg0 = data.readLong();
          java.lang.String _arg1;
          _arg1 = data.readString();
          this.releaseSession(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.media.IMediaRoute2ProviderService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      // Note: When changing this file, match the order of methods below with
      // MediaRoute2ProviderService#MediaRoute2ProviderServiceStub for readability.
      @Override public void setCallback(android.media.IMediaRoute2ProviderServiceCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setCallback, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void updateDiscoveryPreference(android.media.RouteDiscoveryPreference discoveryPreference) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, discoveryPreference, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateDiscoveryPreference, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void setRouteVolume(long requestId, java.lang.String routeId, int volume) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeString(routeId);
          _data.writeInt(volume);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setRouteVolume, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void requestCreateSession(long requestId, java.lang.String packageName, java.lang.String routeId, android.os.Bundle sessionHints) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeString(packageName);
          _data.writeString(routeId);
          _Parcel.writeTypedObject(_data, sessionHints, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_requestCreateSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void selectRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeString(sessionId);
          _data.writeString(routeId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_selectRoute, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void deselectRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeString(sessionId);
          _data.writeString(routeId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_deselectRoute, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void transferToRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeString(sessionId);
          _data.writeString(routeId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_transferToRoute, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void setSessionVolume(long requestId, java.lang.String sessionId, int volume) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeString(sessionId);
          _data.writeInt(volume);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setSessionVolume, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void releaseSession(long requestId, java.lang.String sessionId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeString(sessionId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_releaseSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_setCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_updateDiscoveryPreference = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_setRouteVolume = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_requestCreateSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_selectRoute = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_deselectRoute = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_transferToRoute = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_setSessionVolume = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_releaseSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "android.media.IMediaRoute2ProviderService";
  // Note: When changing this file, match the order of methods below with
  // MediaRoute2ProviderService#MediaRoute2ProviderServiceStub for readability.
  public void setCallback(android.media.IMediaRoute2ProviderServiceCallback callback) throws android.os.RemoteException;
  public void updateDiscoveryPreference(android.media.RouteDiscoveryPreference discoveryPreference) throws android.os.RemoteException;
  public void setRouteVolume(long requestId, java.lang.String routeId, int volume) throws android.os.RemoteException;
  public void requestCreateSession(long requestId, java.lang.String packageName, java.lang.String routeId, android.os.Bundle sessionHints) throws android.os.RemoteException;
  public void selectRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException;
  public void deselectRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException;
  public void transferToRoute(long requestId, java.lang.String sessionId, java.lang.String routeId) throws android.os.RemoteException;
  public void setSessionVolume(long requestId, java.lang.String sessionId, int volume) throws android.os.RemoteException;
  public void releaseSession(long requestId, java.lang.String sessionId) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
