/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package android.media;
/** @hide */
public interface IMediaRoute2ProviderServiceCallback extends android.os.IInterface
{
  /** Default implementation for IMediaRoute2ProviderServiceCallback. */
  public static class Default implements android.media.IMediaRoute2ProviderServiceCallback
  {
    // TODO: Change it to updateRoutes?
    @Override public void notifyProviderUpdated(android.media.MediaRoute2ProviderInfo providerInfo) throws android.os.RemoteException
    {
    }
    @Override public void notifySessionCreated(long requestId, android.media.RoutingSessionInfo sessionInfo) throws android.os.RemoteException
    {
    }
    @Override public void notifySessionsUpdated(java.util.List<android.media.RoutingSessionInfo> sessionInfo) throws android.os.RemoteException
    {
    }
    @Override public void notifySessionReleased(android.media.RoutingSessionInfo sessionInfo) throws android.os.RemoteException
    {
    }
    @Override public void notifyRequestFailed(long requestId, int reason) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements android.media.IMediaRoute2ProviderServiceCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an android.media.IMediaRoute2ProviderServiceCallback interface,
     * generating a proxy if needed.
     */
    public static android.media.IMediaRoute2ProviderServiceCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof android.media.IMediaRoute2ProviderServiceCallback))) {
        return ((android.media.IMediaRoute2ProviderServiceCallback)iin);
      }
      return new android.media.IMediaRoute2ProviderServiceCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_notifyProviderUpdated:
        {
          android.media.MediaRoute2ProviderInfo _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.media.MediaRoute2ProviderInfo.CREATOR);
          this.notifyProviderUpdated(_arg0);
          break;
        }
        case TRANSACTION_notifySessionCreated:
        {
          long _arg0;
          _arg0 = data.readLong();
          android.media.RoutingSessionInfo _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.media.RoutingSessionInfo.CREATOR);
          this.notifySessionCreated(_arg0, _arg1);
          break;
        }
        case TRANSACTION_notifySessionsUpdated:
        {
          java.util.List<android.media.RoutingSessionInfo> _arg0;
          _arg0 = data.createTypedArrayList(android.media.RoutingSessionInfo.CREATOR);
          this.notifySessionsUpdated(_arg0);
          break;
        }
        case TRANSACTION_notifySessionReleased:
        {
          android.media.RoutingSessionInfo _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.media.RoutingSessionInfo.CREATOR);
          this.notifySessionReleased(_arg0);
          break;
        }
        case TRANSACTION_notifyRequestFailed:
        {
          long _arg0;
          _arg0 = data.readLong();
          int _arg1;
          _arg1 = data.readInt();
          this.notifyRequestFailed(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements android.media.IMediaRoute2ProviderServiceCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      // TODO: Change it to updateRoutes?
      @Override public void notifyProviderUpdated(android.media.MediaRoute2ProviderInfo providerInfo) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, providerInfo, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_notifyProviderUpdated, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void notifySessionCreated(long requestId, android.media.RoutingSessionInfo sessionInfo) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _Parcel.writeTypedObject(_data, sessionInfo, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_notifySessionCreated, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void notifySessionsUpdated(java.util.List<android.media.RoutingSessionInfo> sessionInfo) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedList(_data, sessionInfo, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_notifySessionsUpdated, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void notifySessionReleased(android.media.RoutingSessionInfo sessionInfo) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, sessionInfo, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_notifySessionReleased, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void notifyRequestFailed(long requestId, int reason) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(requestId);
          _data.writeInt(reason);
          boolean _status = mRemote.transact(Stub.TRANSACTION_notifyRequestFailed, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_notifyProviderUpdated = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_notifySessionCreated = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_notifySessionsUpdated = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_notifySessionReleased = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_notifyRequestFailed = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "android.media.IMediaRoute2ProviderServiceCallback";
  // TODO: Change it to updateRoutes?
  public void notifyProviderUpdated(android.media.MediaRoute2ProviderInfo providerInfo) throws android.os.RemoteException;
  public void notifySessionCreated(long requestId, android.media.RoutingSessionInfo sessionInfo) throws android.os.RemoteException;
  public void notifySessionsUpdated(java.util.List<android.media.RoutingSessionInfo> sessionInfo) throws android.os.RemoteException;
  public void notifySessionReleased(android.media.RoutingSessionInfo sessionInfo) throws android.os.RemoteException;
  public void notifyRequestFailed(long requestId, int reason) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedList(
        android.os.Parcel parcel, java.util.List<T> value, int parcelableFlags) {
      if (value == null) {
        parcel.writeInt(-1);
      } else {
        int N = value.size();
        int i = 0;
        parcel.writeInt(N);
        while (i < N) {
    writeTypedObject(parcel, value.get(i), parcelableFlags);
          i++;
        }
      }
    }
  }
}
