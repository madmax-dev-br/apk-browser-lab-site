#!/usr/bin/env bash
# The telephony profile (framework-aosp/profiles/telephony, BUILD.txt there): the original android-13.0.0_r1 classes that decode a received SMS (android.telephony.SmsMessage, the 3GPP
# com.android.internal.telephony.gsm.SmsMessage and its parser classes, PhoneNumberUtils, android.provider.Telephony with Sms.Intents.getMessagesFromIntent), loaded next to the
# default framework DEX when an installed package's DEX references them (the default DEX has no room left under the 64K method-reference limit).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="$(python3 "$ROOT/scripts/fetch-android-all.py")"   # AOSP-built android-all jar: compile-time declarations only (framework-aosp/android-all.json)
ANDROID_DECL="$ANDROID_ALL:$ANDROID_JAR"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="$ROOT/framework-aosp/build"
PROFILE="$ROOT/framework-aosp/profiles/telephony"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" || { echo 'Build the default framework first.' >&2; exit 1; }
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/telephony'
rows=json.loads((base/'upstream-sources.json').read_text())
names=[p for p in (base/'telephony-sources.txt').read_text().splitlines() if p]
for name in names:   # every original is compiled unchanged: no source transform
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
(profile/'build/sources.list').write_text('\n'.join('"'+str(base/'upstream'/p)+'"' for p in names)+'\n')
PY
# The lab's framework classes first (what the default DEX defines), then the android-all declarations for everything the originals name that the device does not have
# (com.android.internal.R, the CDMA classes, libphonenumber): references only, resolved at run time when executed (and refused explicitly when absent).
# The default DEX carries only part of java.util.Arrays (the libcore members it needs); the originals here call Arrays.toString/equals/hashCode on byte[], which the VM provides
# (libcore bridge), so java.util.Arrays is declared by android.jar for this compile.
mkdir -p "$BUILD/boot" "$BUILD/compile-only" && (cd "$BUILD/boot" && jar xf "$BASE/framework-classes.jar" && rm -f java/util/Arrays.class java/util/Arrays\$*.class) && cp -R "$BASE/compile-only/." "$BUILD/compile-only/" && rm -f "$BUILD/compile-only/java/util/Arrays.class" "$BUILD/compile-only/java/util/Arrays\$"*.class
BOOT="$BUILD/boot:$BUILD/compile-only:$ANDROID_DECL"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -nowarn -bootclasspath "$BOOT" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 24 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/telephony';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
names={p for p in (base/'telephony-sources.txt').read_text().splitlines() if p}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
assert classes and all(c.startswith(('Landroid/telephony/','Lcom/android/internal/telephony/','Lcom/android/telephony/','Landroid/provider/Telephony')) for c in classes),'unexpected class in the telephony profile'
default=json.loads((base/'framework-provenance.json').read_text())
clash=[c for c in classes if c in set(default['classes'])]
assert not clash,'classes in the default DEX and in the profile: '+', '.join(clash[:5])
manifest={'schemaVersion':1,'profile':'telephony','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':[],
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'Original SMS decoding classes (3GPP); a received SMS is delivered by the virtual device as SMS_RECEIVED with its PDUs (src/telephony-sms.js). The 3GPP2 (CDMA) classes and GsmAlphabet are not in the profile: a 3GPP2 PDU or a GSM 7-bit message body fails with NoClassDefFoundError naming the class',
 'activationPolicy':'an installed package DEX references android.telephony.SmsMessage or android.provider.Telephony (or explicit loader option)','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]
sources=[p for p in sources if p.is_file()]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'telephony-sources.txt',root/'scripts/build-aosp-telephony-profile.sh']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP telephony profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
