#!/usr/bin/env bash
# The concurrent profile (framework-aosp/profiles/concurrent, BUILD.txt there): libcore java.util.concurrent originals of android-13.0.0_r1 that the default framework DEX has no room
# for under the 64K method-reference limit (TransferQueue, LinkedTransferQueue, BrokenBarrierException, Flow), loaded next to it when an installed package's DEX references one of
# them (or CyclicBarrier, which throws BrokenBarrierException). Compiled like the java.time group of the default build: the one recorded transform is the VarHandle-to-field-updater
# rewrite of scripts/varhandle_updaters.py (javac -source 8 has no VarHandle), the same function the default build applies to Phaser, Exchanger or CompletableFuture.
# FRAMEWORK_BUILD: a directory of a default framework build (framework-classes.jar, compile-only.jar, javatime-stubs; default framework-aosp/build); ANDROID_ALL: the pinned android-all
# jar (default: scripts/fetch-android-all.py). Both are compile-time declarations only.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="${ANDROID_ALL:-$(python3 "$ROOT/scripts/fetch-android-all.py")}"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="${FRAMEWORK_BUILD:-$ROOT/framework-aosp/build}"
PROFILE="$ROOT/framework-aosp/profiles/concurrent"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" -a -d "$BASE/javatime-stubs" || { echo 'Build the default framework first (or set FRAMEWORK_BUILD).' >&2; exit 1; }
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex" "$BUILD/src"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/concurrent'
sys.path.insert(0,str(root/'scripts'));from varhandle_updaters import varhandles_to_updaters
rows=json.loads((base/'upstream-sources.json').read_text())
names=[p for p in (base/'concurrent-sources.txt').read_text().splitlines() if p]
transforms=[];files=[]
for name in names:
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 text=path.read_text();assert hashlib.sha256(text.encode()).hexdigest()==row['sha256'],'Modified original: '+name
 out=text
 if 'VarHandle' in text:   # the java.time group's transform, unchanged (VarHandle fields -> Atomic*FieldUpdater of the same field, same call shapes)
  out=varhandles_to_updaters(name,text)
  assert 'findVarHandle' not in out and 'MethodHandles' not in out and 'VarHandle ' not in out,name
  transforms.append(dict(path=name,kind='varhandle-to-field-updaters',inputSha256=hashlib.sha256(text.encode()).hexdigest(),outputSha256=hashlib.sha256(out.encode()).hexdigest()))
 dest=profile/'build/src'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(out);files.append(dest)
(profile/'build/sources.list').write_text('\n'.join('"'+str(p)+'"' for p in files)+'\n')
(profile/'build/transforms.json').write_text(json.dumps(transforms,indent=2)+'\n')
PY
# As the java.time group: the libcore hidden-member declarations and the java8 originals (without the original java.util.Arrays subset, so that android.jar's complete declaration
# resolves) on the boot class path, then the android-all and android.jar declarations (java.* comes from android.jar); the default DEX's classes (java.util.concurrent.Helpers,
# dev.apkweb.util.Fences) on the class path.
test -d "$BASE/javatime-originals" || { echo 'The default framework build has no javatime-originals (rebuild it).' >&2; exit 1; }
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -nowarn -bootclasspath "$BASE/javatime-stubs:$BASE/javatime-originals:$ANDROID_ALL:$ANDROID_JAR" -classpath "$BASE/framework-classes.jar:$BASE/compile-only.jar" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 24 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/concurrent';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
names={p for p in (base/'concurrent-sources.txt').read_text().splitlines() if p}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
OWN=tuple('L'+n.removesuffix('.java') for n in names)
assert classes and all(c.startswith(OWN) for c in classes),'unexpected class in the concurrent profile: '+', '.join(c for c in classes if not c.startswith(OWN))
default=json.loads((base/'framework-provenance.json').read_text())
assert default['sha256']==hashlib.sha256((base/'framework.dex').read_bytes()).hexdigest(),'framework-provenance.json does not describe framework-aosp/framework.dex'
clash=[c for c in classes if c in set(default['classes'])]
assert not clash,'classes in the default DEX and in the profile: '+', '.join(clash[:5])
manifest={'schemaVersion':1,'profile':'concurrent','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':json.loads((profile/'build/transforms.json').read_text()),
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'Original libcore java.util.concurrent classes (TransferQueue, LinkedTransferQueue, BrokenBarrierException, Flow) over the default DEX\'s AbstractQueue, LockSupport, field updaters and Helpers',
 'activationPolicy':'an installed package DEX references java.util.concurrent.TransferQueue, LinkedTransferQueue, BrokenBarrierException, CyclicBarrier or a java.util.concurrent.Flow type (or explicit loader option)','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]
sources=[p for p in sources if p.is_file()]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'concurrent-sources.txt',root/'scripts/build-aosp-concurrent-profile.sh',root/'scripts/varhandle_updaters.py']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP concurrent profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
rm -rf "$BUILD"
