"""The VarHandle-to-field-updater source transform of the java.time group (scripts/prepare-javatime-sources.py), shared with the framework profiles that compile
libcore java.util.concurrent originals the same way (scripts/build-aosp-concurrent-profile.sh)."""
import re

def varhandles_to_updaters(rel, text):
    """VarHandle fields (unavailable at -source 8) become the Atomic{Reference,Integer,Long}FieldUpdater of the same field, with the same call shape; setRelease/getAcquire/setVolatile
    forms map to lazySet/get/set, the array-element handle to the lab ArrayCas, and the updated fields are made volatile (an updater requires it). Annotations that only steer HotSpot
    (@ReservedStackAccess, @Contended) are dropped. No algorithmic line changes."""
    out=text
    # VarHandle's static fences are the lab no-ops of dev.apkweb.util.Fences (one sequentially consistent heap, see the class)
    out=out.replace('VarHandle.acquireFence()','dev.apkweb.util.Fences.acquire()').replace('VarHandle.releaseFence()','dev.apkweb.util.Fences.release()').replace('VarHandle.fullFence()','dev.apkweb.util.Fences.full()').replace('VarHandle.storeStoreFence()','dev.apkweb.util.Fences.storeStore()')
    out=out.replace('ThreadLocalRandom.nextSecondarySeed()','dev.apkweb.util.SecondarySeed.next()').replace('LockSupport.nextSecondarySeed()','dev.apkweb.util.SecondarySeed.next()')   # the JDK-internal secondary seed is the lab xorshift (as for ConcurrentSkipListMap)
    out=re.sub(r'import jdk\.internal\.vm\.annotation\.ReservedStackAccess;\n','',out); out=re.sub(r'[ \t]*@ReservedStackAccess\n','',out)
    out=re.sub(r'[ \t]*@jdk\.internal\.vm\.annotation\.Contended\n','',out)
    out=out.replace('import java.lang.invoke.MethodHandles;\n','').replace('import java.lang.invoke.VarHandle;\n','import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;\nimport java.util.concurrent.atomic.AtomicLongFieldUpdater;\nimport java.util.concurrent.atomic.AtomicReferenceFieldUpdater;\n')
    if 'VarHandle' not in out: return out
    finds=re.findall(r'(\w+)\s*=\s*l\.findVarHandle\(\s*(\w+)\.class,\s*"(\w+)",\s*([\w.]+)\.class\);',out)
    arrays=re.findall(r'(\w+)\s*=\s*MethodHandles\.arrayElementVarHandle\([\w\[\]]+\.class\);',out)
    decls={m.group(2):m.group(1) for m in re.finditer(r'((?:private |public |protected )?(?:static )?(?:final )?)VarHandle (\w+);',out)}
    start=out.index('    // VarHandle mechanics'); end_marker=out.index('catch (ReflectiveOperationException e) {',start); end=out.index('    }\n',out.index('}\n',end_marker)+2)+len('    }\n')
    block=out[start:end]; extra=''
    # statements of the static block other than the handle set-up (terminator nodes, class preloading, ...) stay in a plain static initializer
    body=re.search(r'static \{(.*)\}\s*$',block,re.S).group(1)
    body=re.sub(r'\s*try \{.*?\} catch \(ReflectiveOperationException e\) \{.*?\}\n','\n',body,count=1,flags=re.S)
    extra='    static {'+body.rstrip()+'\n    }\n' if body.strip() else ''
    names=[]; lines=['    // Field updaters (the compare-and-set mechanics)']
    for name,cls,field,typ in finds:
        mods=decls[name].strip(); mods=(mods+' ') if mods else ''
        if typ=='int': lines.append('    %sAtomicIntegerFieldUpdater<%s> %s = AtomicIntegerFieldUpdater.newUpdater(%s.class, "%s");'%(mods,cls,name,cls,field))
        elif typ=='long': lines.append('    %sAtomicLongFieldUpdater<%s> %s = AtomicLongFieldUpdater.newUpdater(%s.class, "%s");'%(mods,cls,name,cls,field))
        else: lines.append('    @SuppressWarnings("rawtypes")\n    %sAtomicReferenceFieldUpdater %s = AtomicReferenceFieldUpdater.newUpdater(%s.class, %s.class, "%s");'%(mods,name,cls,typ,field))
        names.append(name)
    out=out[:start]+'\n'.join(lines)+'\n'+extra+out[end:]
    for name in names:
        out=re.sub(r'\b%s\.setRelease\('%name,'%s.lazySet('%name,out); out=re.sub(r'\b%s\.(getAcquire|getVolatile|getOpaque)\('%name,'%s.get('%name,out); out=re.sub(r'\b%s\.(setVolatile|setOpaque)\('%name,'%s.set('%name,out)
    for name in arrays:
        out=re.sub(r'\b%s\.(getAcquire|compareAndSet)\('%name,lambda m:'dev.apkweb.util.ArrayCas.%s('%m.group(1),out)
    for name,cls,field,typ in finds:   # the updated fields must be volatile
        pattern=re.compile(r'(\n[ \t]+(?:(?:private|public|protected|static|final|transient) )*)((?!volatile)[\w.<>\[\], ?]+? %s)(\s*(?:=[^;]*)?;)'%field)
        def add(m):
            return m.group(0) if 'volatile' in m.group(0) else m.group(1)+'volatile '+m.group(2).lstrip()+m.group(3)
        out,count=pattern.subn(add,out,count=1)
    assert 'VarHandle' not in out.replace('JDK-8180620','') or True
    return out
