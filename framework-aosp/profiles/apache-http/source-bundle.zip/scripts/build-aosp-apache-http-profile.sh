#!/usr/bin/env bash
# The Apache HTTP legacy profile (framework-aosp/profiles/apache-http, BUILD.txt there): the original android-13.0.0_r1 sources of the org.apache.http.legacy shared library
# (platform/external/apache-http: org.apache.http, org.apache.commons.codec / logging, com.android.internal.http.multipart, android.net.http, android.net.compatibility),
# loaded next to the default framework DEX for a package that uses that library: <uses-library android:name="org.apache.http.legacy"> in its manifest, or a targetSdkVersion
# below 28, for which PackageManager adds the library on its own (it left the boot class path in API 28). Classes the default DEX already defines are left out: on a device the
# boot class path is searched first, so those copies of the library are never the ones loaded.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="$(python3 "$ROOT/scripts/fetch-android-all.py")"   # AOSP-built android-all jar: compile-time declarations only (framework-aosp/android-all.json)
ANDROID_DECL="$ANDROID_ALL:$ANDROID_JAR"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="$ROOT/framework-aosp/build"
PROFILE="$ROOT/framework-aosp/profiles/apache-http"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" || { echo 'Build the default framework first.' >&2; exit 1; }
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/apache-http'
rows=json.loads((base/'upstream-sources.json').read_text())
default=set(json.loads((base/'framework-provenance.json').read_text())['classes'])
descriptor=lambda p:'L'+p.removeprefix('android/src/').removesuffix('.java')+';'
allnames=[p for p in (base/'apache-http-sources.txt').read_text().splitlines() if p]
names=[p for p in allnames if descriptor(p) not in default]   # what the boot class path already defines is not the library's to load
(profile/'build/excluded.txt').write_text('\n'.join(p for p in allnames if p not in names)+'\n')
for name in names:   # every original is compiled unchanged: no source transform
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
(profile/'build/sources.list').write_text('\n'.join('"'+str(base/'upstream'/p)+'"' for p in names)+'\n')
PY
# The lab's framework classes first (what the default DEX defines), then the android-all declarations for everything the originals name that the device does not have
# : references only, resolved at run time when executed (and refused explicitly when absent).
# The default DEX carries only part of java.util.Arrays (the libcore members it needs); the originals here call Arrays.toString/equals/hashCode on byte[], which the VM provides
# (libcore bridge), so java.util.Arrays is declared by android.jar for this compile.
mkdir -p "$BUILD/boot" "$BUILD/compile-only" && (cd "$BUILD/boot" && jar xf "$BASE/framework-classes.jar" && rm -f java/util/Arrays.class java/util/Arrays\$*.class) && cp -R "$BASE/compile-only/." "$BUILD/compile-only/" && rm -f "$BUILD/compile-only/java/util/Arrays.class" "$BUILD/compile-only/java/util/Arrays\$"*.class
BOOT="$BUILD/boot:$BUILD/compile-only:$ANDROID_DECL"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -nowarn -bootclasspath "$BOOT" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 24 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/apache-http';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
default_classes=set(json.loads((base/'framework-provenance.json').read_text())['classes'])
names={p for p in (base/'apache-http-sources.txt').read_text().splitlines() if p and 'L'+p.removeprefix('android/src/').removesuffix('.java')+';' not in default_classes}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
assert classes and all(c.startswith(('Lorg/apache/http/','Lorg/apache/commons/codec/','Lorg/apache/commons/logging/','Lcom/android/internal/http/multipart/','Landroid/net/http/','Landroid/net/compatibility/')) for c in classes),'unexpected class in the apache-http profile'
default=json.loads((base/'framework-provenance.json').read_text())
clash=[c for c in classes if c in set(default['classes'])]
assert not clash,'classes in the default DEX and in the profile: '+', '.join(clash[:5])
manifest={'schemaVersion':1,'profile':'apache-http','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':[],
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'The original org.apache.http.legacy library (Apache HttpClient 4.0 as Android ships it, commons-codec and commons-logging, AndroidHttpClient): its network I/O goes through the lab\'s java.net sockets like any other socket code',
 'activationPolicy':'the package declares <uses-library android:name="org.apache.http.legacy"> (required or not), or its targetSdkVersion is below 28 (or explicit loader option)','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]
sources=[p for p in sources if p.is_file()]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'apache-http-sources.txt',root/'scripts/build-aosp-apache-http-profile.sh']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP apache-http profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
