#!/usr/bin/env python3
"""Generates the Java side of the framework AIDL interfaces the in-process system_server (framework-aosp/lab-java-services) implements, with the Android SDK's `aidl` compiler.

Inputs   framework-aosp/service-aidl-sources.txt   the pinned .aidl originals of android-13.0.0_r1 (scripts/pin-aosp-sources.py --group service-aidl-sources.txt): the service interfaces
                                                    (IPowerManager, IAlarmManager, ...) and the one-line `parcelable X;` declarations aidl needs to resolve the types they mention
Output   framework-aosp/generated-services/**.java committed, with framework-aosp/generated-services/provenance.json (input SHA-256s, tool, outputs)
           <package>/I<Name>.java                    the unstructured AIDL Java (interface, Stub, Proxy) exactly as the SDK tool writes it, minus the line that records the builder's directories
           dev/apkweb/services/refusals/Refusing<Name>.java
                                                    an abstract Stub for each interface that implements EVERY method by throwing an UnsupportedOperationException naming "<Interface>.<method>": a lab service extends it and
                                                    overrides exactly the methods the virtual device honours, so a method nobody implemented fails explicitly (UnsupportedOperationException naming the API)
                                                    (no `Default` no-op returns: those would be invented success)

Binder is local in the VM, so a manager's IPowerManager.Stub.asInterface(binder) is the service object itself and the generated Proxy never runs; it is generated and compiled anyway because
it is part of the original interface and an app can reach it through reflection.

Another group (a framework profile) runs it with  --sources <list under framework-aosp> --out <dir under framework-aosp> [--no-refusals]: the same aidl run over that list into that
directory; --no-refusals leaves out the Refusing<Name> bases when no lab service implements the interfaces (the speech profile: the virtual device has no text-to-speech engine and no
TextToSpeechManagerService, so nothing serves them and the original client code never reaches a binder)."""
import sys
import hashlib, json, os, re, shutil, subprocess
args = sys.argv[1:]
def option(name, default):
    if name in args: i = args.index(name); value = args[i + 1]; del args[i:i + 2]; return value
    return default
sources_list, out_dir = option('--sources', 'service-aidl-sources.txt'), option('--out', 'generated-services')
refusals = '--no-refusals' not in args
from pathlib import Path
root = Path(__file__).resolve().parent.parent; base = root / 'framework-aosp'
sdk = Path(os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT') or Path.home() / 'Library/Android/sdk')
tools = sdk / 'build-tools' / os.environ.get('BUILD_TOOLS_VERSION', '36.1.0')
aidl = tools / 'aidl'
up = base / 'upstream'
files = [p for p in (base / sources_list).read_text().splitlines() if p]
# the interfaces, and the structured parcelables (`parcelable X { fields }`, e.g. AttributionSourceState) whose Java aidl also generates; one-line `parcelable X;` declarations only resolve types
interfaces = [p for p in files if re.search(r'(?m)^\s*(oneway\s+)?interface\s', (up / p).read_text()) or re.search(r'(?m)^\s*parcelable\s+\w+\s*\{', (up / p).read_text())]
out = base / out_dir; tmp = base / 'build' / ('service-aidl-out' if out_dir == 'generated-services' else out_dir.replace('/', '-') + '-aidl-out')
shutil.rmtree(out, ignore_errors=True); shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir(parents=True)
subprocess.check_call([str(aidl), '--lang=java', f'-I{up}', '-o', str(tmp), *[str(up / p) for p in interfaces]])
shutil.copytree(tmp, out)
# Two builder-local spellings are dropped: the invocation line of the header and the `overrideSourcePosition="<path>"` attribute aidl adds to @UnsupportedAppUsage (the builder's absolute
# path of the .aidl, and an attribute the android-all annotation does not declare).
for path in sorted(out.rglob('*.java')):
    text = path.read_text()
    result = re.sub(r'(?m)^ \* Using: .*$', " * Using: aidl --lang=java (Android SDK build-tools; the invocation line, with the builder's directories, is dropped)", text)
    result = re.sub(r',\s*overrideSourcePosition="[^"]*"', '', result)
    result = re.sub(r'\(overrideSourcePosition="[^"]*"\)', '', result)
    assert 'overrideSourcePosition' not in result and str(root) not in result, path
    path.write_text(result)
refused = []
DECL = re.compile(r'^  public (?P<ret>[\w.<>\[\], ]+?) (?P<name>\w+)\((?P<args>[^)]*)\) throws android\.os\.RemoteException;$')
for path in sorted(out.rglob('I*.java')) if refusals else []:
    text = path.read_text(); pkg = re.search(r'^package ([\w.]+);', text, re.M).group(1); name = path.stem
    # the abstract methods of the interface itself (the nested Default / Stub / Proxy declare theirs with @Override or a body, not as `...;` at two spaces)
    methods = [m for m in (DECL.match(line) for line in text.splitlines()) if m]
    body = [f'/* Generated by scripts/generate-service-aidl.py from {pkg}.{name}: every method refuses explicitly. */', 'package dev.apkweb.services.refusals;', '',
            f'public abstract class Refusing{name[1:]} extends {pkg}.{name}.Stub {{']
    for m in methods:
        body += [f'  @Override public {m["ret"]} {m["name"]}({m["args"]}) throws android.os.RemoteException {{', f'    throw new java.lang.UnsupportedOperationException("{name}.{m["name"]} is not provided by the virtual device\'s in-process system_server (framework-aosp/lab-java-services)");', '  }']
    body.append('}')
    dest = out / 'dev/apkweb/services/refusals' / f'Refusing{name[1:]}.java'; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_text('\n'.join(body) + '\n')
    refused.append(dict(interface=f'{pkg}.{name}', methods=len(methods)))
inputs = [dict(path=p, sha256=hashlib.sha256((up / p).read_bytes()).hexdigest()) for p in files]
(out / 'provenance.json').write_text(json.dumps(dict(schemaVersion=1, tool='Android SDK build-tools ' + tools.name + ' aidl --lang=java', tag='android-13.0.0_r1', inputs=inputs, interfaces=interfaces, refusals=refused,
    files=len(list(out.rglob('*.java')))), indent=1) + '\n')
print(f'generated {len(list(out.rglob("*.java")))} Java files from {len(interfaces)} interfaces ({len(files)} AIDL inputs); refusal bases: ' + ', '.join(f"{r['interface']}={r['methods']}" for r in refused))
