#!/usr/bin/env bash
# The accounts profile (framework-aosp/profiles/accounts, BUILD.txt there): the original android-13.0.0_r1 account authenticator classes -- android.accounts.AbstractAccountAuthenticator,
# AccountAuthenticatorResponse, AccountAuthenticatorActivity and the AIDL interfaces IAccountAuthenticator / IAccountAuthenticatorResponse they speak, AuthenticatorDescription, and the
# system's account chooser (ChooseTypeAndAccountActivity, ChooseAccountTypeActivity: Activities of the "android" package) -- loaded next to the default framework
# DEX when an installed package's DEX references them (the default DEX has no room left under the 64K method-reference limit). The other side of the protocol, AccountManagerService, is
# the lab's (src/account-sessions.js): it binds the authenticator's service and calls it through the generated IAccountAuthenticator Proxy, as the system does.
# FRAMEWORK_BUILD: a directory with framework-classes.jar and compile-only.jar of a default framework build (default framework-aosp/build); ANDROID_ALL: the pinned android-all jar
# (default: scripts/fetch-android-all.py, which fetches it into work/android-all when absent). Both are compile-time declarations only.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="${ANDROID_ALL:-$(python3 "$ROOT/scripts/fetch-android-all.py")}"
ANDROID_DECL="$ANDROID_ALL:$ANDROID_JAR"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="${FRAMEWORK_BUILD:-$ROOT/framework-aosp/build}"
PROFILE="$ROOT/framework-aosp/profiles/accounts"
BUILD="$PROFILE/build"
test -f "$BASE/framework-classes.jar" || { echo 'Build the default framework first (or set FRAMEWORK_BUILD).' >&2; exit 1; }
python3 "$ROOT/scripts/generate-service-aidl.py" --sources accounts-aidl-sources.txt --out profiles/accounts/generated --no-refusals
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/accounts'
rows=json.loads((base/'upstream-sources.json').read_text())
names=[p for f in ['accounts-sources.txt','accounts-aidl-sources.txt'] for p in (base/f).read_text().splitlines() if p]
for name in names:   # every original is compiled (or, for .aidl, generated) unchanged: no source transform
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
java=[base/'upstream'/p for p in (base/'accounts-sources.txt').read_text().splitlines() if p]+sorted((profile/'generated').rglob('*.java'))
(profile/'build/sources.list').write_text('\n'.join('"'+str(p)+'"' for p in java)+'\n')
PY
# The lab's framework classes first (what the default DEX defines), then the android-all declarations (android.accounts.AccountManager, a host class of the lab, is declared there).
mkdir -p "$BUILD/boot" && (cd "$BUILD/boot" && jar xf "$BASE/framework-classes.jar")
# java.util.Arrays of the default DEX is the libcore subset the lab compiles; the rest (Arrays.toString(Object[]), which the original's verbose logging names) is answered by the runtime
# (src/apk-runtime.js). javac takes one declaration per class, so the android-all one declares it here; the DEX only records the method reference either way.
rm -f "$BUILD/boot/java/util/Arrays.class"
BOOT="$BUILD/boot:$BASE/compile-only.jar:$ANDROID_DECL"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -proc:none -nowarn -bootclasspath "$BOOT" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --release --min-api 24 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
test ! -e "$BUILD/dex/classes2.dex"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,struct,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/accounts';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text())
names={p for f in ['accounts-sources.txt','accounts-aidl-sources.txt'] for p in (base/f).read_text().splitlines() if p}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
expected=('Landroid/accounts/AbstractAccountAuthenticator','Landroid/accounts/AccountAuthenticatorResponse','Landroid/accounts/AccountAuthenticatorActivity','Landroid/accounts/IAccountAuthenticator',
 'Landroid/accounts/ChooseTypeAndAccountActivity','Landroid/accounts/ChooseAccountTypeActivity','Landroid/accounts/AuthenticatorDescription')
assert classes and all(c.startswith(expected) for c in classes),'unexpected class in the accounts profile: '+', '.join(c for c in classes if not c.startswith(expected))
default=json.loads((base/'framework-provenance.json').read_text())
assert default['sha256']==hashlib.sha256((base/'framework.dex').read_bytes()).hexdigest(),'framework-provenance.json does not describe framework-aosp/framework.dex'
clash=[c for c in classes if c in set(default['classes'])]
assert not clash,'classes in the default DEX and in the profile: '+', '.join(clash[:5])
generated=json.loads((profile/'generated/provenance.json').read_text()) if (profile/'generated/provenance.json').exists() else {'tool':'aidl --lang=java (Android SDK build-tools)','interfaces':[]}
manifest={'schemaVersion':1,'profile':'accounts','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),
 'methods':struct.unpack_from('<I',data,0x58)[0],'classes':classes,'classCount':len(classes),'algorithmPatches':[],'sourceTransforms':[],
 'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],
 'generatedSources':{'tool':generated.get('tool'),'interfaces':generated.get('interfaces'),'files':[{'localPath':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((profile/'generated').rglob('*.java'))]},
 'requiresDefaultFrameworkSha256':default['sha256'],'compileOnlyDeclarationsPackaged':False,
 'integrationStatus':'Original account authenticator classes (the authenticator side of IAccountAuthenticator), AuthenticatorDescription and the system account chooser Activities (ChooseTypeAndAccountActivity, ChooseAccountTypeActivity; started by AccountManager.newChooseAccountIntent, run as Activities of the android package: src/system-activities.js); AccountManagerService is the lab\'s (src/account-sessions.js): it binds the authenticator\'s service as the system and calls it through the generated Proxy',
 'activationPolicy':'an installed package DEX references android.accounts.AbstractAccountAuthenticator, AccountAuthenticatorResponse or AccountAuthenticatorActivity (or a companion package is installed, or explicit loader option)','correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]+sorted((profile/'generated').rglob('*'))
sources=[p for p in sources if p.is_file()]+[profile/'framework-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',base/'accounts-sources.txt',base/'accounts-aidl-sources.txt',root/'scripts/build-aosp-accounts-profile.sh',root/'scripts/generate-service-aidl.py']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP accounts profile:',len(classes),'classes,',manifest['methods'],'method references,',len(data),'bytes, SHA256',manifest['sha256'])
PY
rm -rf "$BUILD"
