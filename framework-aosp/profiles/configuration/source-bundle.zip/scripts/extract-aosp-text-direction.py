#!/usr/bin/env python3
"""Exact original TextUtils locale-direction algorithm for the configuration profile."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent.parent;BASE=ROOT/'framework-aosp';src=BASE/'upstream/android/text/TextUtils.java';raw=src.read_bytes();text=raw.decode();row=next(r for r in json.loads((BASE/'upstream-sources.json').read_text()) if r['localPath']==str(src.relative_to(ROOT)));assert hashlib.sha256(raw).hexdigest()==row['sha256']
def declaration(text,pattern,name,row):
 m=re.search(pattern,text,re.M);assert m,name
 start=m.start();begin=text.index('{',start);i=begin;level=0;state='code'
 while i<len(text):
  c=text[i];n=text[i+1] if i+1<len(text) else ''
  if state=='line':
   if c=='\n':state='code'
  elif state=='block':
   if c=='*' and n=='/':state='code';i+=1
  elif state in ['string','char']:
   if c=='\\':i+=1
   elif c==('"' if state=='string' else "'"):state='code'
  elif c=='/' and n=='/':state='line';i+=1
  elif c=='/' and n=='*':state='block';i+=1
  elif c=='"':state='string'
  elif c=="'":state='char'
  elif c=='{':level+=1
  elif c=='}':
   level-=1
   if level==0:break
  i+=1
 assert level==0;end=i+1;block=text[start:end]
 return block,{'name':name,'originalSourcePath':row['localPath'],'originalStartByte':len(text[:start].encode()),'originalEndByte':len(text[:end].encode()),'originalStartLine':text.count('\n',0,start)+1,'bytes':len(block.encode()),'sha256':hashlib.sha256(block.encode()).hexdigest()}
blocks=[];decls=[]
for name,pattern in [('getCapsMode',r'^    public static int getCapsMode\(CharSequence cs,'),('getChars',r'^    public static void getChars\(CharSequence s,'),('obtain',r'^    /\* package \*/ static char\[\] obtain\(int len\)'),('recycle',r'^    /\* package \*/ static void recycle\(char\[\] temp\)'),('constructor',r'^    private TextUtils\(\)'),('getLayoutDirectionFromLocale',r'^    public static int getLayoutDirectionFromLocale\(Locale locale\)')]:
 block,info=declaration(text,pattern,name,row);blocks.append(block);decls.append(info)
fields='\n'.join(re.findall(r'^    private static (?:Object sLock|char\[\] sTemp) = [^;]+;',text,re.M));assert fields.count(';')==2
fields+='\n'+'\n'.join(re.findall(r'^    public static final int CAP_MODE_\w+\s*=\s*InputType.TYPE_TEXT_FLAG_CAP_\w+;',text,re.M))
for field in re.findall(r'^    (?:private static (?:Object sLock|char\[\] sTemp)|public static final int CAP_MODE_\w+)\s*=\s*[^;]+;',fields,re.M):
 start=text.index(field);decls.append({'name':field.split('=')[0].split()[-1],'originalSourcePath':row['localPath'],'originalStartByte':len(text[:start].encode()),'originalEndByte':len(text[:start+len(field)].encode()),'bytes':len(field.encode()),'sha256':hashlib.sha256(field.encode()).hexdigest()})
for name,pattern in [('doesNotNeedBidi',r'^    static boolean doesNotNeedBidi\(char\[\] text, int start, int len\)'),('getEllipsisString',r'^    public static String getEllipsisString\('),('trimNoCopySpans',r'^    public static CharSequence trimNoCopySpans\('),('TruncateAt',r'^    public enum TruncateAt'),('EllipsizeCallback',r'^    public interface EllipsizeCallback'),('couldAffectRtl',r'^    static boolean couldAffectRtl\(char c\)'),('indexOfChar',r'^    public static int indexOf\(CharSequence s, char ch\)'),('indexOfStart',r'^    public static int indexOf\(CharSequence s, char ch, int start\)'),('indexOfRange',r'^    public static int indexOf\(CharSequence s, char ch, int start, int end\)'),('equals',r'^    public static boolean equals\(CharSequence a, CharSequence b\)'),('getOffsetBefore',r'^    public static int getOffsetBefore\(CharSequence text, int offset\)'),('getOffsetAfter',r'^    public static int getOffsetAfter\(CharSequence text, int offset\)'),('copySpansFrom',r'^    public static void copySpansFrom\(Spanned source,'),('removeEmptySpans',r'^    public static <T> T\[\] removeEmptySpans\('),('packRangeInLong',r'^    public static long packRangeInLong\('),('unpackRangeStartFromLong',r'^    public static int unpackRangeStartFromLong\('),('unpackRangeEndFromLong',r'^    public static int unpackRangeEndFromLong\(')]:
 block,info=declaration(text,pattern,name,row);blocks.append(block);decls.append(info)
for name in ['ELLIPSIS_FILLER','ALIGNMENT_SPAN','LEADING_MARGIN_SPAN','LINE_BACKGROUND_SPAN','LINE_HEIGHT_SPAN','ELLIPSIS_NORMAL','ELLIPSIS_TWO_DOTS']:
 m=re.search(r'^    (?:/\* package \*/ static final char|public static final int|private static final String) '+name+r'\s*=\s*[^;]+;',text,re.M);assert m,name
 field=m.group();fields+='\n'+field;start=m.start();decls.append({'name':name,'originalSourcePath':row['localPath'],'originalStartByte':len(text[:start].encode()),'originalEndByte':len(text[:m.end()].encode()),'bytes':len(field.encode()),'sha256':hashlib.sha256(field.encode()).hexdigest()})
out=BASE/'extracted/text-direction';folder=out/'src/android/text';folder.mkdir(parents=True,exist_ok=True);dest=folder/'TextUtils.java';dest.write_text(text[:text.index('package ')]+"package android.text;\nimport java.util.Locale;\nimport android.annotation.NonNull;\nimport android.annotation.Nullable;\nimport java.lang.reflect.Array;\nimport android.text.style.ReplacementSpan;\nimport android.compat.annotation.UnsupportedAppUsage;\nimport android.icu.util.ULocale;\nimport android.sysprop.DisplayProperties;\nimport android.view.View;\nimport com.android.internal.util.ArrayUtils;\npublic class TextUtils {\n"+'\n'.join(blocks)+'\n'+fields+'\n}\n')
manifest={'schemaVersion':1,'tag':row['tag'],'originalSource':row,'declarations':decls,'extractedSourcePath':str(dest.relative_to(ROOT)),'extractedSourceSha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'algorithmPatches':[],'structuralAdaptations':['Original private constructor and complete original locale-direction method copied byte-for-byte under their original TextUtils owner.','Original getChars/obtain/recycle helpers and their original sLock/sTemp fields are also retained. Original text direction, UTF16 offsets, span copying/filtering, text equality, index/range helpers, TruncateAt enum and EllipsizeCallback interface are also retained. Other methods remain explicit external boundaries.','ULocale.forLocale/isRightToLeft use the declared ICU/CLDR platform backend. DisplayProperties.debug_force_rtl is a virtual system-property boundary returning the original Optional type.'],'shellPackaged':False,'runtimeClasses':['Landroid/text/TextUtils;','Landroid/text/TextUtils$TruncateAt;','Landroid/text/TextUtils$EllipsizeCallback;'],'profile':'default'}
(out/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Extracted original TextUtils locale direction')
