#!/usr/bin/env python3
"""Generate compile-only proto field IDs from pinned schemas and original ProtoStream flags."""
from pathlib import Path
import hashlib,json,re
root=Path(__file__).resolve().parent.parent;base=root/'framework-aosp';rows=json.loads((base/'upstream-sources.json').read_text());out=base/'profiles/configuration/support'
def read(rel):
 path=base/'upstream'/rel;data=path.read_bytes();row=next(r for r in rows if r['localPath']==str(path.relative_to(root)));assert hashlib.sha256(data).hexdigest()==row['sha256'];return data.decode(),row
stream,srow=read('android/util/proto/ProtoStream.java')
typeShift=int(re.search(r'FIELD_TYPE_SHIFT = (\d+)',stream)[1]);countShift=int(re.search(r'FIELD_COUNT_SHIFT = (\d+)',stream)[1]);types={name.lower():int(value)<<typeShift for name,value in re.findall(r'public static final long FIELD_TYPE_(\w+) = (\d+)L << FIELD_TYPE_SHIFT;',stream)}
counts={name.lower():int(value)<<countShift for name,value in re.findall(r'public static final long FIELD_COUNT_(\w+) = (\d+)L << FIELD_COUNT_SHIFT;',stream)}
generated=[];inputs=[srow]
for rel in ['android/content/configuration.proto','android/content/locale.proto','android/app/window_configuration.proto']:
 text,row=read(rel);inputs.append(row);package=re.search(r'^package (\w+(?:\.\w+)*);',text,re.M)[1]
 for name,body in re.findall(r'message (\w+)\s*\{(.*?)^\}',text,re.M|re.S):
  fields=[]
  for count,typ,field,num in re.findall(r'\b(optional|required|repeated)\s+([\w.]+)\s+(\w+)\s*=\s*(\d+)',body):
   ident=(counts['repeated'] if count=='repeated' else counts['single'])|types.get(typ,types['message'])|int(num);fields.append((field.upper(),ident))
  path=out/Path(package.replace('.','/'))/(name+'.java');path.parent.mkdir(parents=True,exist_ok=True);path.write_text('// Generated compile-only proto IDs from pinned Android13 schemas; excluded from D8.\npackage '+package+'; public final class '+name+' {\n'+''.join('public static final long '+key+' = '+str(value)+'L;\n' for key,value in fields)+'}\n');generated.append({'path':str(path.relative_to(root)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'fields':len(fields)})
(base/'profiles/configuration/proto-metadata-provenance.json').write_text(json.dumps({'inputs':inputs,'generated':generated,'packaged':False,'rule':'Original schema field number | original ProtoStream field-type flags | original field-count flags'},indent=2)+'\n')
