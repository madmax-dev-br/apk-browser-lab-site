#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_JAR="$SDK/platforms/${ANDROID_PLATFORM:-android-36}/android.jar"
ANDROID_ALL="$(python3 "$ROOT/scripts/fetch-android-all.py")"   # AOSP-built android-all jar: compile-time declarations only (framework-aosp/android-all.json)
ANDROID_DECL="$ANDROID_ALL:$ANDROID_JAR"
TOOLS="$SDK/build-tools/${BUILD_TOOLS_VERSION:-36.1.0}"
BASE="$ROOT/framework-aosp/build"
PROFILE="$ROOT/framework-aosp/profiles/configuration"
BUILD="$PROFILE/build"
python3 "$ROOT/scripts/build-configuration-proto-metadata.py"
test -f "$BASE/framework-classes.jar" || { echo 'Build the default framework first.' >&2; exit 1; }
mkdir -p "$BUILD/compile-only" "$BUILD/classes" "$BUILD/dex"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/configuration'
for directory in ['classes','compile-only']:
 for file in (profile/'build'/directory).rglob('*.class'):file.unlink()
names=['android/content/res/Configuration.java','android/app/WindowConfiguration.java','android/os/LocaleList.java']
rows=json.loads((base/'upstream-sources.json').read_text())
for name in names:
 path=base/'upstream'/name;row=next(r for r in rows if r['localPath']==str(path.relative_to(root)))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Modified original: '+name
(profile/'build/sources.list').write_text('\n'.join('"'+str(base/'upstream'/name)+'"' for name in names if not name.startswith('java/'))+'\n')
(profile/'build/support.list').write_text('\n'.join('"'+str(p)+'"' for p in sorted((profile/'support').rglob('*.java')))+'\n')
PY
BOOT="$BUILD/compile-only:$BASE/framework-classes.jar:$BASE/compile-only:$ANDROID_DECL"
javac -source 8 -target 8 -Xlint:-options -bootclasspath "$BOOT" -d "$BUILD/compile-only" @"$BUILD/support.list"
javac -source 8 -target 8 -Xmaxerrs 200 -Xlint:-options -bootclasspath "$BOOT" -d "$BUILD/classes" @"$BUILD/sources.list"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .
jar --create --file "$BUILD/compile-only.jar" -C "$BUILD/compile-only" .
"$TOOLS/d8" --release --min-api 23 --lib "$ANDROID_JAR" --classpath "$ANDROID_ALL" --classpath "$BASE/framework-classes.jar" --classpath "$BASE/compile-only.jar" --classpath "$BUILD/compile-only.jar" --output "$BUILD/dex" "$BUILD/classes.jar"
cp "$BUILD/dex/classes.dex" "$PROFILE/framework.dex"
"$TOOLS/dexdump" -d "$PROFILE/framework.dex" > "$BUILD/framework.dexdump.txt"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib,json,re,sys,zipfile
root=Path(sys.argv[1]);base=root/'framework-aosp';profile=base/'profiles/configuration';data=(profile/'framework.dex').read_bytes()
rows=json.loads((base/'upstream-sources.json').read_text());names={'android/content/res/Configuration.java','android/app/WindowConfiguration.java','android/os/LocaleList.java'}
classes=re.findall(r"Class descriptor\s*: '([^']+)'",(profile/'build/framework.dexdump.txt').read_text(errors='replace'))
manifest={'schemaVersion':1,'profile':'configuration','enabledByDefault':False,'artifact':'framework.dex','tag':'android-13.0.0_r1','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'classes':classes,'classCount':len(classes),'algorithmPatches':[],'compiledSources':[r for r in rows if r['localPath'].removeprefix('framework-aosp/upstream/') in names],'requiresDefaultFrameworkSha256':json.loads((base/'framework-provenance.json').read_text())['sha256'],'compileOnlyDeclarationsPackaged':False,'sourceExtractions':[],'integrationStatus':'Validated source configuration and locale-direction profile; loaded by actual APK Configuration references','activationPolicy':'APK DEX references android.content.res.Configuration (or explicit loader option)','protoMetadata':json.loads((profile/'proto-metadata-provenance.json').read_text()),'correspondingSource':'source-bundle.zip','licenses':['../../LICENSE','../../NOTICE']}
(profile/'framework-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources=[root/r['localPath'] for r in manifest['compiledSources']]+[root/r['localPath'] for r in manifest['protoMetadata']['inputs']]
sources += [p for p in (base/'extracted/text-direction').rglob('*') if p.is_file()]+[base/'upstream/android/text/TextUtils.java',root/'scripts/extract-aosp-text-direction.py']
sources += [p for p in (profile/'support').rglob('*.java')]+[profile/'framework-provenance.json',profile/'proto-metadata-provenance.json',profile/'BUILD.txt',base/'LICENSE',base/'NOTICE',root/'scripts/build-aosp-configuration-profile.sh',root/'scripts/build-configuration-proto-metadata.py',profile/'proof.mjs']
with zipfile.ZipFile(profile/'source-bundle.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(set(sources)):
  info=zipfile.ZipInfo(str(path.relative_to(root)),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,path.read_bytes())
print('Original AOSP Configuration profile:',len(classes),'classes,',len(data),'bytes, SHA256',manifest['sha256'])
PY
