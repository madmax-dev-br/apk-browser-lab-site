// Compile-only declaration; excluded from profile D8.
package android.os; public class Build { public static class VERSION { public static int RESOURCES_SDK_INT; } public static class VERSION_CODES { public static final int R=30; } }
