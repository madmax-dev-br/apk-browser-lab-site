// Compile-only declaration; excluded from profile D8.
package android.view; public class DisplayInfo {}
