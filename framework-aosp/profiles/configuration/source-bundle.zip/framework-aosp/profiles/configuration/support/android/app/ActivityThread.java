// Compile-only declaration; excluded from profile D8.
package android.app; public class ActivityThread { public static native boolean isSystem(); }
