// Generated compile-only proto IDs from pinned Android13 schemas; excluded from D8.
package android.content; public final class GlobalConfigurationProto {
public static final long RESOURCES = 1146756268033L;
public static final long DEVICE = 1146756268034L;
}
