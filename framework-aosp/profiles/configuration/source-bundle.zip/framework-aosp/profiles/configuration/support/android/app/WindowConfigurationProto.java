// Generated compile-only proto IDs from pinned Android13 schemas; excluded from D8.
package android.app; public final class WindowConfigurationProto {
public static final long APP_BOUNDS = 1146756268033L;
public static final long WINDOWING_MODE = 1120986464258L;
public static final long ACTIVITY_TYPE = 1120986464259L;
public static final long BOUNDS = 1146756268036L;
public static final long MAX_BOUNDS = 1146756268037L;
}
