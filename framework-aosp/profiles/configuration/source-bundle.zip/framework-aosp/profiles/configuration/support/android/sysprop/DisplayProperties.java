// Compile-only generated-sysprop API contract. This class is not an implementation or D8 input.
package android.sysprop; public class DisplayProperties { public static native java.util.Optional<Boolean> debug_force_rtl(); }
