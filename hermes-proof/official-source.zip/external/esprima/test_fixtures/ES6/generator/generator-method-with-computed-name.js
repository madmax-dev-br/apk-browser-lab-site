(function*() {
    { *[yield iter]() {} }
})
