a: function *g() {}
