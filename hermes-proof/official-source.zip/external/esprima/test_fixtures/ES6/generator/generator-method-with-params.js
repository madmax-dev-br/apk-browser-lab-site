({ *foo(x, y, z) {} })
