(function*() { yield* })
