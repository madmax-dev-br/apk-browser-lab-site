export var foo = function () {};
