export {foo as bar};
