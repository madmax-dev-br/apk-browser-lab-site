export default from "foo"
