export {try as bar};
