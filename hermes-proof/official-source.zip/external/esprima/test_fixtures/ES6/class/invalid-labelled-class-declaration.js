a: class B {}
