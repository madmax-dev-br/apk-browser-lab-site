let [...a,] = 0
