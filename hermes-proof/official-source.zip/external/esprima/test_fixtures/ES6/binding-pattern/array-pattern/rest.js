let [...a] = 0;
