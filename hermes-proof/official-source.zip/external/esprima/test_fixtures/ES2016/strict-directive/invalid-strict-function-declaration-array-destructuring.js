function f([]){ "use strict"; }
